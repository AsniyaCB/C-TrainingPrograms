﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WeeklyTst1
{
    class Q2
    {


        public static void Main(string[] args)
        {
            SBAccount b1 = new SBAccount();
            SBAccount b2 = new SBAccount();
            Console.WriteLine("SAVINGS BANK ACCOUNT");
            b1.ReadData();
            b1.CalculateInterest();
            b1.Display();
            b2.ReadData();
            b2.CalculateInterest();
            b2.Display();

            Console.ReadKey();

        }
    }
    abstract class Account
    {
        public readonly int ID;         // for generating unique ID
        public string name;
        static int count = 100;               //to initialize ID
        public abstract void CalculateInterest();
        public Account() {
            ID = count;                      
            count++;                    //increment ID by 1
        }

        public void ReadData()
        {
            //Console.WriteLine("Enter the ID:");
            //ID = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the name:");
            name = Console.ReadLine();
        }



    }
    class SBAccount : Account
    {
        double interest, deposit, rate, time;

        public override void CalculateInterest()
        {

            Console.WriteLine("Enter the amount:");
            deposit = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the interest rate:");
            rate = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the time period:");
            time = Convert.ToInt32(Console.ReadLine());

            interest = deposit * (1 + (rate / 100) * time);            //interest formula
        }
        public void Display()
        {
            Console.WriteLine("ID:" + ID);
            Console.WriteLine("The interest rate is " + interest);
        }
    }
}
  


