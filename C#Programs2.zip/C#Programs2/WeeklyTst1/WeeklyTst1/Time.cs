﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WeeklyTst1
{
    class Time
    {

            int hours, minutes,seconds;
            public Time()
            {

            }
            public Time(int hours, int minutes,int seconds)
            {
                this.hours = hours;
                this.minutes = minutes;
                this.seconds = seconds;
            }
            public void DisplayTime()
            {
                Console.WriteLine("hours:{0} Minutes:{1} seconds:{2}", hours, minutes,seconds);
            }
            public void ReadTime()
            {
                Console.WriteLine("Enter the value of hours:");
                hours = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter the value of minutes:");
                minutes = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter the value of seconds:");
                seconds = Convert.ToInt32(Console.ReadLine());
            }
            
            public static void Main()
            {
                 Time Time1 = new Time();
                 Time Time2 = new Time();
                 Time Time3;

                 Console.WriteLine("Enter the value of Time 1:");
                 Time1.ReadTime();
                 Console.WriteLine("Enter the value of Time 2:");
                 Time2.ReadTime();

                 Console.WriteLine(" Time 1:");
                Console.WriteLine(" -------------");

                Time1.DisplayTime();
                 Console.WriteLine(" Time 2:");
                Console.WriteLine(" -------------");
                Time2.DisplayTime();

                 Time3 = Time1 + Time2;
                 Console.WriteLine(" SUM");
                 Console.WriteLine(" -------------");
                Time3.DisplayTime();

                 Time time4;
                 time4 = Time1 - Time2;
                 Console.WriteLine(" DIFFERENCE");
                Console.WriteLine(" -------------");
                 time4.DisplayTime();

                 Console.ReadKey();


            }
            public static Time operator +(Time t1, Time t2)
            {
            Time t = new Time();
            t.hours = t1.hours + t2.hours;
            t.minutes = t1.minutes + t2.minutes;
            t.seconds = t1.seconds + t2.seconds;
            if (t.seconds >= 60)
            {
                t.minutes++;
                t.seconds %= 60;
            }
            if (t.minutes >= 60)
            {
                t.hours++;
                t.minutes %= 60;
            }


            return t;
        }

        public static Time operator -(Time t1, Time t2)
        {
            Time p = new Time();
            int tim1, tim2, tim4;
            tim1 = (t1.hours * 3600) + (t1.minutes*60)+ t1.seconds;
            tim2 = (t2.hours * 3600) + (t2.minutes * 60) + t2.seconds;
            //if (tim1 >= tim2)
            //{
            //    tim4 = tim1 - tim2;

            //}
            //else
            //{
            //    tim4 = tim2 - tim1;
            //}
            tim4 = Math.Abs(tim1 - tim2);
            p.hours = tim4 / 3600;
            p.minutes = tim4 / 60;
            p.seconds = tim4 % 60;


            if (p.seconds >= 60)
            {
                p.minutes++;
                p.seconds %= 60;
            }
            if (p.minutes >= 60)
            {
                p.hours++;
                p.minutes %= 60;
            }

            return p;
        }
    }
    }

