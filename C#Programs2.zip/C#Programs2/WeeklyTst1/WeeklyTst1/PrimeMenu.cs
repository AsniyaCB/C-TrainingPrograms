﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WeeklyTst1
{
    class PrimeMenu
    {

        public static void Main(string[] args)
        {
            do
            {
                int option;
                Console.WriteLine("1.CHECK PRIME \n 2.GENERATE PRIME BETWEEN 2 INTERVALS\n 3.GENERATE N PRIME NUMBERS\n 4.EXIT\n Enter your Option:");
                option = Convert.ToInt32(Console.ReadLine());

                switch (option)
                {
                    case 1:
                        PrimeCheck p1 = new PrimeCheck();
                        p1.ReadData1();
                        p1.CheckPrime();
                        p1.Display1();
                        break;
                    case 2:
                        PrimeInterval p2 = new PrimeInterval();
                        p2.ReadData2();
                        p2.Interval();
                        break;
                    case 3:
                        PrimeN p3 = new PrimeN();
                        p3.ReadData3();
                        p3.PrimeDigit();
                        break;
                    case 4:
                        System.Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("INVALID OPTION");
                        break;
                }
            } while (true);
        }
            
        class PrimeCheck
        {
            int number;
            string result;
            public void ReadData1()
            {
                Console.WriteLine("Enter the number to be checked:");
                number = Convert.ToInt32(Console.ReadLine());
            }

            public void CheckPrime()
            {
                bool flag = true;
                for (int i = 2; i < number; i++)
                {

                    if (number % i == 0)
                    {
                        flag = false;
                        break;
                    }
                }
                if (flag)
                {
                    result = "PRIME";
                }
                else
                {
                    result = "NOT PRIME";
                }
            }
            public void Display1()
            {
                Console.WriteLine(result);
            }

        }
        class PrimeInterval
        {
            int high, low;
            public void ReadData2()
            {
                Console.WriteLine("Enter the lower limit:");
                low = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter the upper limit:");
                high = Convert.ToInt32(Console.ReadLine());
            }
            public void Interval()
            {

                for (int i = low; i < high; i++)
                {
                    bool flag = true;
                    for (int j = 2; j < i; j++)
                    {
                        if (i % j == 0)
                        {

                            flag = false;
                            break;
                        }
                    }
                    if (flag)
                    {
                        Console.WriteLine(i);
                    }

                }
            }

        }
        class PrimeN
        {
            int digit;
            public void ReadData3()
            {
                Console.WriteLine("Enter the limit:");
                digit = Convert.ToInt32(Console.ReadLine());
            }
            public void PrimeDigit()
            {
                Console.WriteLine("Prime numbers are:");
                int i, j = 2, count = digit;
                while (count != 0)
                {

                    for (i = 1; i <= count; i++)
                    {
                        bool flag = true;

                        for (int num = 2; num < j; num++)
                        {
                            if (j % num == 0)
                            {
                                flag = false;
                                break;
                            }
                        }


                        if (flag)
                        {
                            count--;
                            Console.WriteLine(j);
                        }
                        j++;
                    }
                }
            }
        }
    }
    }





