﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
namespace TestApp3
{
    class StreamDemo
    {
        public static void Main(string[] args)
        {
            FileStream dataInFile = new FileStream("D:\\asniya\\TestApp3\\streamData.txt", FileMode.OpenOrCreate);
            for(int ii = 65; ii <= 90; ii++)
            {
                dataInFile.WriteByte((byte)ii);
               
            }
            dataInFile.Close();
            Console.WriteLine("File created successfully");
            Console.WriteLine("FILE READ OPERATION\n********************");
            FileStream dataOutFile = new FileStream("D:\\asniya\\TestApp3\\streamData.txt", FileMode.OpenOrCreate);
            int i = 0;
            while ((i = dataOutFile.ReadByte()) != -1)
            {
                Console.Write((char)i);
            }
            dataOutFile.Close();
            Console.ReadKey();
        }
    }
}
