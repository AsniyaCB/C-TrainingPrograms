﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace TestApp3
{
    class SerializeDemo
    {
        public static void Main(string[] args)
        {
            FileStream stream = new FileStream("D:\\asniya\\TestApp3\\account.txt", FileMode.OpenOrCreate);
            BinaryFormatter formatter = new BinaryFormatter();
            Account account = new Account(101, 240);
            formatter.Serialize(stream, account);
            stream.Close();
            Console.WriteLine("The object has been serialized ");
            Console.WriteLine("The object has been deserialized");
            Deserialized();
            Console.ReadKey();
        }
        public static void Deserialized()
        {
            FileStream stream = new FileStream("D:\\asniya\\TestApp3\\account.txt", FileMode.OpenOrCreate);
            BinaryFormatter formatter = new BinaryFormatter();
            Account account = (Account)formatter.Deserialize(stream);
            account.Display();
            stream.Close();
        }
    }
    [Serializable]
    class Account
    {
        public int ID { get; set; }
        public int Balance { get; set; }
        public Account(int id,int balance)
        {
            ID = id;
            Balance = balance;
        }
        public void Display()
        {
            Console.WriteLine("ID:" + ID);
            Console.WriteLine("BALANCE:" + Balance);
        }
    }
}
