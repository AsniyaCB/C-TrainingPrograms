﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestApp3
{
    public delegate bool IsPromotableDelegate(EmployeePro employee);
    class EmployeeCallBack
    {
        public static void Main()
        {
            List<EmployeePro> emp = new List<EmployeePro>();
            emp.Add(new EmployeePro { ID = 101, Name = "Gopu", Salary = 4000, Experience = 4 });
            emp.Add(new EmployeePro { ID = 102, Name = "Meenu", Salary = 6000, Experience = 5 });
            emp.Add(new EmployeePro { ID = 103, Name = "Malu", Salary = 7000, Experience = 6 });
            emp.Add(new EmployeePro { ID = 104, Name = "Priya", Salary = 10000, Experience = 8 });
            emp.Add(new EmployeePro { ID = 105, Name = "Sharath", Salary = 3000, Experience = 2 });
            emp.Add(new EmployeePro { ID = 106, Name = "Prashanth", Salary = 9000, Experience = 1 });
            Console.WriteLine("LIST OF EMPLOYEES ELIGIBLE FOR PROMOTION ARE:");
            IsPromotableDelegate isPromodelegate = new IsPromotableDelegate(IsPromotable);
            EmployeePro.GetPromotedList(emp, isPromodelegate);
            Console.ReadKey();
        }
        public static bool IsPromotable(EmployeePro employee)
        {
            bool eligible = false;
            if (employee.Experience >= 4 && employee.Salary < 5000)
            {
                eligible = true;
            }
            return eligible;
        }
    }
    public class EmployeePro
    {
        public int ID
        {
            get; set;
        }
        public string Name
        {
            get; set;
        }
        public int Experience
        {
            get; set;
        }
        public int Salary
        {
            get; set;
        }
        //public static void GetPromotedList(List<EmployeePro> employees)     //employees -list name
        //{
        //    foreach (EmployeePro employee in employees)     //employee-index value
        //    {
        //        if (employee.Experience >= 5)
        //        {
        //            Console.WriteLine("Employee ID :" + employee.ID);
        //            Console.WriteLine("Employee Name :" + employee.Name);
        //            Console.WriteLine("Employee Experience :" + employee.Experience);
        //            Console.WriteLine("Employee Salary :" + employee.Salary);
        //        }
        //    }
        //}
        public static void GetPromotedList(List<EmployeePro> employees, IsPromotableDelegate isPromodelegate)     //employees -list name
        {
            foreach (EmployeePro employee in employees)     //employee-index value
            {
                if (isPromodelegate(employee))
                {
                    Console.WriteLine("Employee ID :" + employee.ID);
                    Console.WriteLine("Employee Name :" + employee.Name);
                    Console.WriteLine("Employee Experience :" + employee.Experience);
                    Console.WriteLine("Employee Salary :" + employee.Salary);
                }
            }
        }
    }
}

