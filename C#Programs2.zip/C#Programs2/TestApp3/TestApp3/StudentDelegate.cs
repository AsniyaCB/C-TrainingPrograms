﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestApp3
{
    public delegate bool PromotableDelegate(Student studentIndex);
    class StudentDelegate
    {
        public static void Main()
        {
            List<Student> stu = new List<Student>();
            stu.Add(new Student { ID = 101, Name = "GOPU", Mark = 40, Attendance = 74 });
            stu.Add(new Student { ID = 102, Name = "MEENU", Mark = 60, Attendance = 75 });
            stu.Add(new Student { ID = 103, Name = "MALU", Mark = 70, Attendance = 76 });
            stu.Add(new Student { ID = 104, Name = "PRIYA", Mark = 30, Attendance = 78 });
            stu.Add(new Student { ID = 105, Name = "SHARATH", Mark = 90, Attendance = 82 });
            stu.Add(new Student { ID = 106, Name = "PRASHANTH", Mark = 10, Attendance = 61 });
            Console.WriteLine("LIST OF STUDENTS ELIGIBLE FOR PROMOTION ARE:");
            PromotableDelegate delegateObject = new PromotableDelegate(PromotableStudentMethod);
            Student.GetPromotedList(stu, delegateObject);
            Console.ReadKey();
        }
        public static bool PromotableStudentMethod(Student studentIndex)
        {
            bool eligible = false;
            if (studentIndex.Mark >= 45 && studentIndex.Attendance >= 75)
            {
                eligible = true;
            }
            return eligible;
        }
    }

    public class Student
    {
        public int ID
        {
            get; set;
        }
        public string Name
        {
            get; set;
        }
        public int Mark
        {
            get; set;
        }
        public int Attendance
        {
            get; set;
        }

        public static void GetPromotedList(List<Student> studentsList, PromotableDelegate delegateObject)     //students -list name
        {
            foreach (Student studentIndex in studentsList)     //student-index value
            {
                if (delegateObject(studentIndex))
                {
                    Console.WriteLine("Student ID :" + studentIndex.ID);
                    Console.WriteLine("Student Name :" + studentIndex.Name);
                    Console.WriteLine("Student Mark :" + studentIndex.Mark);
                    Console.WriteLine("Student Attendance :" + studentIndex.Attendance);
                }
            }
        }
    }

}