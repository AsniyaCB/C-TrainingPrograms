﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestApp3
{
    class DelegateEmployeePromotion
    {
        public static void Main()
        {
            List<Employee> emp = new List<Employee>();
            emp.Add(new Employee { ID = 101, Name = "Gopu", Salary = 4000, Experience = 4 });
            emp.Add(new Employee { ID = 102, Name = "Meenu", Salary = 6000, Experience = 5 });
            emp.Add(new Employee { ID = 103, Name = "Malu", Salary = 7000, Experience = 6});
            emp.Add(new Employee { ID = 104, Name = "Priya", Salary = 10000, Experience = 8 });
            emp.Add(new Employee { ID = 105, Name = "Sharath", Salary = 3000, Experience = 2 });
            emp.Add(new Employee { ID = 106, Name = "Prashanth", Salary = 9000, Experience = 1 });
            Console.WriteLine("LIST OF EMPLOYEES ELIGIBLE FOR PROMOTION ARE:");
            Employee.GetPromotedList(emp);
            Console.ReadKey();
        }
    }
    class Employee
    {
        public int ID
        {
            get;set;
        }
        public string Name
        {
            get; set;
        }
        public int Experience
        {
            get; set;
        }
        public int Salary
        {
            get; set;
        }
        public static void GetPromotedList(List<Employee> employees)     //employees -list name
        {
            foreach(Employee employee in employees)     //employee-index value
            {
                if (employee.Experience >= 5)
                {
                    Console.WriteLine("Employee ID :" + employee.ID);
                    Console.WriteLine("Employee Name :" + employee.Name);
                    Console.WriteLine("Employee Experience :" + employee.Experience);
                    Console.WriteLine("Employee Salary :" + employee.Salary);
                }
            }
        }
    }
}
