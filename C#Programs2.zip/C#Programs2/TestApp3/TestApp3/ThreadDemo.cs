﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace TestApp3
{
    class ThreadDemo
    {
        public static void Main()
        {
            GenerateTable table = new GenerateTable(5,100);
            Thread table5 = new Thread(table.Table);
            Thread table6 = new Thread(table.Table);
            table5.Start();
            table6.Start();
            //GenerateTable table1 = new GenerateTable(10,100);
            //Thread table10 = new Thread(table1.Table);
            //table10.Start();
            Console.ReadKey();
        }
    }
    class GenerateTable
    {
        private int _number;
        private int _sleep;
        public GenerateTable(int target, int sleep)
        {
            _number = target;
            _sleep = sleep;
        }
        public void Table()
        {
            lock (this)
            {
                for (int iteration = 1; iteration <= 10; iteration++)

                {
                    Thread.Sleep(_sleep);
                    Console.WriteLine("{0} * {1} = {2}", iteration, _number, (iteration * _number));

                }
            }
        }
    }
}
