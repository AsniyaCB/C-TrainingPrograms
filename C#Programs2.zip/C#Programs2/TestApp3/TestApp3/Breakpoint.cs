﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestApp3
{
    class Breakpoint
    {
            int number, i, sum, c = 0;
            public void ReadData()
            {

                Console.WriteLine("Enter the number:");
                number = Convert.ToInt32(Console.ReadLine());
            }
            public void FindEven()
            {
                i = 0;
                int j = 0;
                while (c < number)
                {
                    sum += i;
                    i = i + 2;
                    c++;
                j += 2;
                Console.WriteLine("Even:" + j);
                }
            }
            public void Display()
            {
                Console.WriteLine("Sum of {0} even numbers are :{1}", number, sum);
            }
            public static void Main(string[] args)
            {
            Breakpoint obj = new Breakpoint();
                obj.ReadData();
                obj.FindEven();
                obj.Display();
                Console.ReadKey();
            }

        }
}
