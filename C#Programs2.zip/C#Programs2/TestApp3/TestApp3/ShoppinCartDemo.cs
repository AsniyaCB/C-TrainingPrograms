﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cs_week3.collections
{
    class ShoppingCartDemo
    {


        public static void Main()
        {
            Hashtable products = new Hashtable();
            Hashtable cart = null;
            int option;
            int total=0;
            products.Add(101, new Product { ProductId = 101, ProductName = "Dove", UnitPrice = 10, Quantity = 0, Amount = 0 });
            products.Add(102, new Product { ProductId = 102, ProductName = "Cutie", UnitPrice = 20, Quantity = 0, Amount = 0 });
            products.Add(103, new Product { ProductId = 103, ProductName = "Pears", UnitPrice = 30, Quantity = 0, Amount = 0 });
            products.Add(104, new Product { ProductId = 104, ProductName = "Fiama", UnitPrice = 40, Quantity = 0, Amount = 0 });
            products.Add(105, new Product { ProductId = 105, ProductName = "Lux", UnitPrice = 50, Quantity = 0, Amount = 0 });


            do
            {

               
                Console.WriteLine("============================");
                Console.WriteLine("1.ADD CART ");
                Console.WriteLine("2.VIEW CART ");
                Console.WriteLine("3.CHECKOUT CART ");
                Console.WriteLine("4.EXIT ");
                Console.WriteLine("============================");
               
                Console.WriteLine("Enter the option (1-4) ? ");
                Console.WriteLine("============================");

                option = Convert.ToInt32(Console.ReadLine());


                switch (option)
                {

                    case 1:
                        Console.WriteLine("============================================================");
                        Console.WriteLine("            \t     PRODUCT DETAILS ");
                        Console.WriteLine("============================================================");
                        Console.WriteLine("Product ID \t\t| Product Name \t\t| Unit Price ");
                        Console.WriteLine("============================================================");
                        Product product;
                        if (products != null)
                        {
                            ICollection key = products.Keys;
                            foreach (int k in key)
                            {
                                product = ((Product)products[k]);
                                Console.WriteLine(product.ProductId + "\t\t\t| " + product.ProductName + "\t\t\t| " + product.UnitPrice);

                            }
                        }
                        else
                        {
                            Console.WriteLine("No Product available in the cart");
                        }

                        Console.WriteLine("============================================================");

                        Console.WriteLine("Enter the Product ID ");
                        int product_id = Convert.ToInt32(Console.ReadLine());
             
                        Console.WriteLine("Enter the Qty ");
                        int quantity = Convert.ToInt32(Console.ReadLine());

                        if (cart == null)
                        {
                            cart = new Hashtable();

                        }
                        product = (Product)products[product_id];
                        product.Quantity = quantity;
                        product.Amount = product.UnitPrice * product.Quantity;
                        cart.Add(product_id, product);
                        Console.WriteLine("Product Successfully added to the cart");
                        Console.ReadKey();


                        Console.ReadKey();


                        break;
                    case 2:
                        
                        if (cart != null)
                        {
                            Console.WriteLine("===============================================================================");
                            Console.WriteLine("                     \t        ITEMS IN YOUR CART ");
                            Console.WriteLine("===============================================================================");
                            Console.WriteLine("Product ID      | Product Name  | Unit Price    | Quantity       | Amount");
                            Console.WriteLine("===============================================================================");
                            ICollection key = cart.Keys;
                            foreach (int k in key)
                            {
                                product = ((Product)cart[k]);
                                Console.WriteLine(product.ProductId + "      \t| " + product.ProductName + "       \t| " + product.UnitPrice + "       \t| " + product.Quantity + "        \t | " + product.Amount);

                            }
                            Console.WriteLine("===============================================================================");
                        }
                        else
                        {
                            Console.WriteLine("NO PRODUCTS AVAILABLE IN THE CART");
                        }

                        break;
                    case 3:
                        if (cart == null)
                        {
                            Console.WriteLine("NO PRODUCTS AVAILABLE IN THE CART");
                        }
                        else
                        {
                            Console.WriteLine("=====================================================================================");
                            Console.WriteLine("                     \t \t        CHECK OUT ");
                            Console.WriteLine("=====================================================================================");
                            Console.WriteLine("Product ID      | Product Name   | Unit Price   | Quantity      | Amount     | TOTAL");
                            Console.WriteLine("=====================================================================================");
                            ICollection key = cart.Keys;
                           
                           
                            foreach (int k in key)
                            {
                                product = ((Product)cart[k]);
                           
                                total += product.Amount;
                                
                                Console.WriteLine(product.ProductId + "\t\t| " + product.ProductName + "\t\t | " + product.UnitPrice + " \t\t| " + product.Quantity + " \t\t| " + product.Amount);

                            }
                            

                            Console.WriteLine("-------------------------------------------------------------------------------------");
                            Console.WriteLine("\t\t\t\t\t\t\t\t             |  "+total);
                            Console.WriteLine("-------------------------------------------------------------------------------------");
                        }
                        break;
                    case 4:
                        System.Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("Invalid option");
                        break;
                }





            } while (true);







        }





        class Product
        {


            public int ProductId { get; set; }
            public String ProductName { get; set; }
            public int UnitPrice { get; set; }
            public int Quantity { get; set; }
            public int Amount { get; set; }





        }
    }
}




