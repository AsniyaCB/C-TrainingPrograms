﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace TestApp3
{
    class BookManager
    {
        public static void Main(string[] args)
        {
            Books book = new Books();
            ArrayList books = new ArrayList();
            books.Add(book.BookID, book.BookName, book.Author, book.PublishedDate, book.Price);
            FileStream stream = new FileStream("D:\\asniya\\TestApp3\\BookManager.txt", FileMode.OpenOrCreate);
            BinaryFormatter formatter = new BinaryFormatter();
            //Books book = new Books();//(101, "ALCHEMIST", "PAULO KOILO", "10-2-1996",75);

            formatter.Serialize(stream, book);
            stream.Close();
            Console.WriteLine("The object has been serialized ");
            Console.WriteLine("The object has been deserialized");
            Deserialized();
            Console.ReadKey();
        }
        public static void Deserialized()
        {
            FileStream stream = new FileStream("D:\\asniya\\TestApp3\\BookManager.txt", FileMode.OpenOrCreate);
            BinaryFormatter formatter = new BinaryFormatter();
            Books book = (Books)formatter.Deserialize(stream);
            book.Display();
            stream.Close();
        }
    }
    [Serializable]
    class Books
    {


        public int BookID { get; set; }
        public string BookName { get; set; }
        public string PublishedDate { get; set; }
        public string Author { get; set; }
        public int Price { get; set; }
        //public Books(int bookId, string bookName, string author, string publishedDate, int price)
        //{
        //    BookID = bookId;
        //    BookName = bookName;
        //    Author = author;
        //    PublishedDate = publishedDate;
        //    Price = price;
        //}

        public void Display()
        {
            Console.WriteLine("----------------------------------------------------------------------------------------");
            Console.WriteLine("ID:" + BookID + "   BOOK NAME:" + BookName + "   AUTHOR:" + Author + "   PUBLISHED DATE:" + PublishedDate + "   PRICE:" + Price);
            Console.WriteLine("----------------------------------------------------------------------------------------");


        }

    }
}
