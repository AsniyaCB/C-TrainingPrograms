﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace TestApp3
{
    class HashtableD
    {

        public static void Main()
        {
            HashTableDemo();
            Console.ReadKey();
        }
      
        public static void HashTableDemo()
        {

            Hashtable ht = new Hashtable();
            ht.Add("001", "Sara");
            ht.Add("002", "Ali");
            ht.Add("003", "Zoya");
            ht.Add("004", "Farhan");
            ht.Add("006", "Ritesh");
            if (ht.ContainsValue("Nuha Ali"))
            {
                Console.WriteLine("The name already exists");
            }
            else
            {
                ht.Add("005", "Nuha Ali");
            }
            ICollection key = ht.Keys;
            foreach (string k in key)
            {
                Console.WriteLine(k + ":" + ht[k]);
            }
        }
    }
}
