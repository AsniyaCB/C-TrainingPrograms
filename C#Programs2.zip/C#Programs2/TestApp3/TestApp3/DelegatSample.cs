﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestApp3
{
    class DelegatSample
    {
        public delegate void Calculate(int val1, int val2);
        public static void Main()
        {
            Calculate calc = new Calculate(Calculator.Sum);
            Calculator calc1 = new Calculator();
            calc += Calculator2.Diff;
            calc += calc1.Mul;
            calc -= Calculator.Sum;
            calc(10, 20);
            Console.ReadLine();
        }
    }
    class Calculator
    {
        public static void Sum(int value1, int value2)
        {
            Console.WriteLine("SUM = " + (value1 + value2));
        }
        public void Mul(int value1, int value2)
        {
            Console.WriteLine("PRODUCT = " + (value1 * value2));
        }
    }
    class Calculator2
        {
            public static void Diff(int value1, int value2)
        {
            Console.WriteLine("DIFFERENCE = " + (value1 - value2));
        }
    }
}
