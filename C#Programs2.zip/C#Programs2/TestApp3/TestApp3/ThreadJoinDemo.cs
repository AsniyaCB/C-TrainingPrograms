﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace TestApp3
{
    class ThreadJoinDemo
    {
        public static void Main()
        {
            Thread thread1 = Thread.CurrentThread;
            thread1.Name = "Main Thread";

            Console.WriteLine("Main Method:" + thread1.Name);

            ThreadStart threadStart = new ThreadStart(ChildThread1);               //another method for initializing thread for childthread1     
            Thread subthread1 = new Thread(threadStart);
           // Thread subthread1 = new Thread(ChildThread1);         
            Thread subthread2 = new Thread(ChildThread2);

            subthread1.Start();
            subthread2.Start();

            subthread2.Join();

            Console.WriteLine("MAIN METHOD COMPLETED");
            Console.WriteLine();
            Console.ReadKey();
        }
            public static void ChildThread1()
        {
            Console.WriteLine("FROM CHILD THREAD 1");
            for(int index = 0; index < 10; index++)
            {
                Console.WriteLine(index+"  ");
            }
            Console.WriteLine("CHILD THREAD 1 COMPLETED");
        }
        public static void ChildThread2()
        {
            Thread.Sleep(1000);
                
            Console.WriteLine("FROM CHILD THREAD 1");
            for (int index = 0; index < 25; index++)
            {
                Console.WriteLine(index + "  ");
            }
            Console.WriteLine("CHILD THREAD 2 COMPLETED");
        }
    }
}
