﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestApp3
{
    public delegate void Print(int value);
    class AnonymousMethod
    {
        public static void PrintHelperMethod(Print printDel,int val)
        {
            val+= 10;
            printDel(val);
        }

        static void Main()
        {
            PrintHelperMethod(delegate (int val)
            {
                Console.WriteLine("inside anonymous method.Value={0}", val);
            },100);
           
            Console.ReadKey();
        }
    }
}
