﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace TestApp3
{
    class MerfeFiles
    {
        
        public static void Main(string[] args)
        {
            FileStream dataInFile1 = new FileStream("D:\\asniya\\TestApp3\\File6.txt", FileMode.OpenOrCreate);
            for (int index = 1; index <= 10; index++)
            {
                dataInFile1.WriteByte((byte)index);
            }
            dataInFile1.Close();
            FileStream dataInFile2 = new FileStream("D:\\asniya\\TestApp3\\File7.txt", FileMode.OpenOrCreate);
            for (int index = 90; index <= 100; index++)
            {
                dataInFile2.WriteByte((byte)index);
            }
            dataInFile2.Close();
            
            using (StreamWriter writer = File.CreateText("D:\\asniya\\TestApp3\\OutputFile1.txt"))
            {

                using (StreamReader reader = File.OpenText("D:\\asniya\\TestApp3\\File6.txt"))
                {
                    writer.Write(reader.ReadToEnd());
                }

                using (StreamReader reader = File.OpenText("D:\\asniya\\TestApp3\\File7.txt"))
                {
                    writer.Write(reader.ReadToEnd());
                }
            }
            FileStream dataOutFile = new FileStream("D:\\asniya\\TestApp3\\OutputFile1.txt", FileMode.OpenOrCreate);
            int i = 0;
            while ((i = dataOutFile.ReadByte()) != -1)
            {
                Console.Write(" "+i);
            }
            dataOutFile.Close();
            Console.ReadKey();
        }
    } }
