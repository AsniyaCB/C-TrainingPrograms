﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WeeklyTest_
{
    class Salary
    {
        public static void Main()
        {
            Employee objEmployee = new Employee();

            int option;
            int EmployeeCount= objEmployee.ReadData();

          
            do
            {
                Console.WriteLine("\n1. READ THE DETAILS\n2. DISPLAY ALL EMPLOYEE DETAILS\n3. PARTICULAR EMPLOYEE DETAIL\n4. EXIT\n----------------\nENTER YOUR OPTION :\n---------------");
            
                option = Convert.ToInt32(Console.ReadLine());
                switch (option)
                {
                    case 1:
                        for (int index = 0; index < EmployeeCount; index++)
                        {
                         
                            Console.Write("Enter the Salary of Employee {0} : ",index+1);
                            objEmployee[index] = Convert.ToInt32(Console.ReadLine());
                        }

                        break;

                    case 2:
                        Console.WriteLine("\nEMPLOYEE DETAILS\n------------------");
                        for (int index = 0; index < EmployeeCount; index++)
                        {
                            Console.WriteLine("\n Salary of Employee {0} ", index + 1);
                            Console.Write( objEmployee[index]);
                           
                        }
                        break;
                    case 3:
                        int indexer;
                        Console.Write("\nEnter the Index of the particular Employee : ");
                        indexer = Convert.ToInt32(Console.ReadLine());
                        if (indexer > EmployeeCount)
                        {
                            Console.WriteLine("INVALID COUNT OF EMPLOYEE!!");
                        }

                            for (int index = 0; index < EmployeeCount; index++)
                            {
                                if (index == indexer)
                                {
                                    Console.Write("Salary : " + objEmployee[index]);
                                   
                                }

                            }
                        
                        break;

                    case 4:
                        System.Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("Invalid operation");
                        break;
                }
            } while (true);

           
        }
    }
    class Employee
    {
        public int number;
        public int[] salary;

        public int ReadData()
        {
            Console.WriteLine("Enter the No Of Employees ");
            number = Convert.ToInt32(Console.ReadLine());
            salary = new int[number];

            return number;
        }
        public int this[int index]
        {
            get
            { return salary[index]; }
            set
            {  salary[index] = value; }
        }


    }
}