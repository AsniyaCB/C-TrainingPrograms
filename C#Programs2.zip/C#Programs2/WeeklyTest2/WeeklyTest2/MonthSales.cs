﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WeeklyTest_
{
    class MonthSales
    {
        int months;
        int[] sales;
        int[] unsorted;
        public void ReadData()
        {
           // bool flag = true;
            do
            {
            try
            {                                                                           
                    //flag = false;
                    Console.WriteLine("Enter the number of months:");
                    months = Convert.ToInt32(Console.ReadLine());
                    try
                    {                                                                               //enter only if first try is false
                       
                        sales = new int[months];
                        Console.WriteLine("Enter the sales amount:");
                        for (int i = 0; i < months; i++)
                        {
                            sales[i] = Convert.ToInt32(Console.ReadLine());
                        }
                        break;                                                                          //breaks loop after reading valid values
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine("WRONG VALUE \n Enter a Valid integer:" + e.Message.ToString());
                    }
                }
            
            catch (Exception e)
            {
                Console.WriteLine("WRONG VALUE \n Enter a Valid integer:" + e.Message.ToString());
            }
                     
              
                  
        } while (true);    
    }
        public void SortSales()
        {
            int temp;
            unsorted = new int[sales.Length];
            for (int i = 0; i < sales.Length; i++)
            {
                unsorted[i] = sales[i];
            }

            for (int i = 0; i < sales.Length; i++)
            {
                for(int j = i + 1; j < sales.Length; j++)
                {
                    if (sales[i] > sales[j])
                    {
                        temp = sales[i];                                        //sorting
                        sales[i] = sales[j];
                        sales[j] = temp;
                    }
                }
            }
        }
       
         public void Display()
        {
            Console.WriteLine(" INPUT SALES REPORT");
            foreach (int i in unsorted)
            {

                Console.WriteLine(i);
            }

            //for (int i = 0; i < sales.Length; i++)
            //{
            //    Console.WriteLine(sales[i]);
            //}
            Console.WriteLine("SORTED SALES REPORT OF {0} MONTHS",months);
            foreach (int j in sales)
            {
                
                Console.WriteLine(j);
            }
        }
        static void Main(string[] args)
        {
            MonthSales obj = new MonthSales();
           
            obj.ReadData();
            obj.SortSales();
            obj.Display();
            Console.ReadKey();
        }
    }
}
