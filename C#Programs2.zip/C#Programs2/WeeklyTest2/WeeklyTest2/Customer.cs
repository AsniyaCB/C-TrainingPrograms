﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WeeklyTest_
{

    class CustomerDetails
    {
        public static void Main(string[] args)
        {
            Customer obj = new Customer();
            int number = obj.ReadData();
            Customer[] customerArray = new Customer[number];
            
            for (int index = 0; index < number; index++)
            {
                Console.WriteLine("-------------------------------\nEnter the details of Customer {0}\n-------------------------------", index + 1);
                customerArray[index] = new Customer();
                customerArray[index].ReadData1();

            }

            Console.WriteLine("----------------\nCUSTOMER DETAILS\n----------------");
            for (int index = 0; index < number; index++)
            {
                Console.WriteLine("\nDetails of customer {0}\n---------------------", index + 1);
              
                customerArray[index].DisplayData();

            }



            Console.ReadKey();
        }
    }
    enum userType
    {
        retail,
        wholesale
    };

    class Customer
    {
        private int ID;
        private string Name;
        int number, CustomerType;

        public int CustomerID
        {
            get
            {
                return ID;
            }
            set
            {
                ID = value;
            }
        }
        public string CustomerName
        {
            get
            {
                return Name;
            }
            set
            {
                Name = value;
            }
        }
        public int Type
        {
            get { return CustomerType; }
            set
            {
                if (CustomerType == 1)
                {
                    CustomerType = value;
                }
                else
                {
                    CustomerType = value;
                }
            }
        }

        public int ReadData()
        {
            Console.WriteLine("Enter the No Of Customers :");
            number = Convert.ToInt32(Console.ReadLine());
            return number;
        }
        public void ReadData1()
        {
            Console.Write("\n Customer ID : ");
            ID = Convert.ToInt32(Console.ReadLine());
            Console.Write("\n Customer Name : ");
            Name = Console.ReadLine();
            Console.Write("\n1:Retail \n2:Wholesale\nUser Type : ");
            CustomerType = Convert.ToInt32(Console.ReadLine());
        }
        public void DisplayData()
        {
            Console.Write("Customer ID : " + ID);
            Console.Write("\nCustomer Name : " + Name);
            if (CustomerType == 1)
            {
                Console.Write("\nUser Type : ");
                Console.Write((int)userType.retail + "-"+Enum.GetName(typeof(userType), 0));
            }
            else if(CustomerType == 2)
            {
                Console.Write("\nUser Type : ");
                Console.Write((int)userType.wholesale + "-" + Enum.GetName(typeof(userType), 1));
            }
            else
            {
                Console.Write("\nUser Type : ");
                Console.WriteLine("!!No User Type in the specified  category!!");
            }
        }
    }
   
}



