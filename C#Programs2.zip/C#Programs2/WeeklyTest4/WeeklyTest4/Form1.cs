﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace WeeklyTest4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        string employeeID, employeeName, emailID,department;
        double mobileNumber;
        string value = "";
        string hobbies = "";
        int flag = 0;
        private void button1_Click(object sender, EventArgs e)
        {


            //MessageBox.Show(hobbies);

            //display personal details
            if (flag == 1) { 
                rtbView.Text = "\t\tEMPLOYEE DETAILS";
                rtbView.Text += "\n\nEMPLOYEE ID           :  " + employeeID;
                rtbView.Text += "\n\nEMPLOYEE NAME    :  " + employeeName;
                rtbView.Text += "\n\nDEPARTMENT          :  " + department;
                rtbView.Text += "\n\nEMAIL ID                    :  " + emailID;
                rtbView.Text += "\n\nMOBILE NUMBER     :  " + mobileNumber.ToString();
                rtbView.Text += "\n\nGENDER                    :  " + value;
                rtbView.Text += "\n\nDATE OF BIRTH        :  " + dtpDOB.Text;
                rtbView.Text += "\n\nHOBBIES                    :  " + hobbies;
                }

            
            //ctch (Exception )
            //{
            //    string msg = "Enter all the details";
                
            //    MessageBox.Show(msg);
                
            //}
          
        }

        private void toolStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 100; i++)
            {
                toolStripProgressBar1.Value = i;
            }
            //try
            //{
            employeeID = txtID.Text;

            employeeName = txtName.Text;
            emailID = txtEmail.Text;
            //try
            //{
                
            //}
            //catch(FormatException ex)
            //{
            //    ex.Message.ToString();
            //}
           
            //Department-Combo box
            try
            {
                department = cmbDepartment.Items[cmbDepartment.SelectedIndex].ToString();
                //MessageBox.Show(department);
            }
            catch(Exception ee)
            {
                ee.Message.ToString();
            }

            //DOB-date time picker
            dtpDOB.MaxDate = DateTime.Today;
            // rtbView.Text += dtpDOB.Value.ToString();

            //Hobbies-check box
            hobbies = "";
            if (ckbDraw.Checked)
            {
                hobbies += ckbDraw.Text + ",";

            }
            if (ckbWrite.Checked)
            {
                hobbies += ckbWrite.Text + ",";


            }
            if (ckbPlay.Checked)
            {
                hobbies += ckbPlay.Text + ",";

            }
            if (ckbRead.Checked)
            {
                hobbies += ckbRead.Text + ",";

            }
            if (ckbSing.Checked)
            {
                hobbies += ckbSing.Text + ",";

            }
            if (ckbDance.Checked)
            {
                hobbies += ckbDance.Text;

            }

            //Gender-radio button

            bool isChecked = rdbMale.Checked;
            if (isChecked)
            {
                value = rdbMale.Text;
            }
            else
            {
                value = rdbFemale.Text;
            }
            // MessageBox.Show(value);
            try
            {
                mobileNumber = Convert.ToInt64(txtMobile.Text.ToString());
            }
            catch (FormatException)
            {

            }
            
            Regex phonenumber = new Regex(@"\[6-9]{2}\s+[0-9]{5}\s+[0-9]{3}");
            if (phonenumber.IsMatch(txtMobile.Text) || txtMobile.Text !="10")
            {
                MessageBox.Show("valid number");

            }
            else if (txtID.TextLength == 0)
            {
                MessageBox.Show("ID cannot be empty");

            }
            else if (txtName.TextLength == 0 )
            {
                MessageBox.Show("Name cannot be empty");

            }
           
           
           
               
            


            else if (txtID.TextLength == 0)
            {
                MessageBox.Show("ID cannot be empty");

            }
            else if (txtEmail.TextLength == 0)
            {
                MessageBox.Show("Email cannot be empty");

            }
            //else if (txtEmail.Text != "^([\\w\\.\\-]+)@([\\w\\-]+)((\\.(\\w){2,3})+)$")
            //{
            //    MessageBox.Show("Enter a valid email");
            //}
            else if (cmbDepartment.SelectedItem == null)
            {
                MessageBox.Show("Select an item for department");
            }

            else
            {
                flag = 1;
                lblMessage.Text = "Details saved successfully";
            }
        }

        private void btnEMI_Click(object sender, EventArgs e)
        {
            double basicSalary, loanAmount, rateOfInterest,DA,grossPay,EMI,netPay, tenure, interestRate;
          
            try
            {
                basicSalary = Convert.ToInt32(txtBasicSalary.Text);
                loanAmount = Convert.ToInt32(txtLoanAmount.Text);
                interestRate = Convert.ToInt32(txtRateOfInterest.Text);
                tenure = Convert.ToInt32(txtTenure.Text);

                if (txtBasicSalary.TextLength == 0)
                {
                    MessageBox.Show("Enter the basic salary");
                }
                if (txtLoanAmount.TextLength == 0)
                {
                    MessageBox.Show("Enter the loan amount");
                }
                if (txtRateOfInterest.TextLength == 0)
                {
                    MessageBox.Show("Enter the Interest rate");
                }
                if (txtTenure.TextLength == 0)
                {
                    MessageBox.Show("Enter the loan tenure");
                }
                //calculate rate of interest
                rateOfInterest = interestRate / (12 * 100);

                //calculate da
                DA = basicSalary * 0.3;

                //calculate grosspay
                grossPay = basicSalary + DA;

                //calculate emi
                EMI = (loanAmount * rateOfInterest * (Math.Pow((1 * rateOfInterest), tenure))) / (Math.Pow((1 + rateOfInterest), tenure));

                //calculate netPay
                netPay = grossPay - EMI;

                for (int i = 0; i < 100; i++)
                {
                    toolStripProgressBar2.Value = i;
                }
                //display salary details

                rtbEMI.Text = "\n\nBASIC SALARY         :  " + basicSalary.ToString();
                rtbEMI.Text += "\n\nLOAN AMOUNT        :  " + loanAmount.ToString();
                rtbEMI.Text += "\n\nINTEREST RATE      :  " + interestRate.ToString() + "%";
                rtbEMI.Text += "\n\nLOAN TENURE          :  " + tenure.ToString();
                rtbEMI.Text += "\n\nDA                               :  " + DA.ToString();
                rtbEMI.Text += "\n\nGROSS PAY               :  " + grossPay.ToString();
                rtbEMI.Text += "\n\nEMI                              :  " + EMI.ToString();
                rtbEMI.Text += "\n\nNET PAY                     :  " + netPay.ToString();
            }
           
            catch (Exception)
            {
                string msg = "Enter all the details";
                
                MessageBox.Show(msg);
            }
           

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
