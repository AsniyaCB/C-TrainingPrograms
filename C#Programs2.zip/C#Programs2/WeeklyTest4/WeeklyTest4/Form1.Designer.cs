﻿namespace WeeklyTest4
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tbPersonal = new System.Windows.Forms.TabPage();
            this.lblMessage = new System.Windows.Forms.Label();
            this.btnSave = new System.Windows.Forms.Button();
            this.rtbView = new System.Windows.Forms.RichTextBox();
            this.ckbDance = new System.Windows.Forms.CheckBox();
            this.ckbSing = new System.Windows.Forms.CheckBox();
            this.ckbRead = new System.Windows.Forms.CheckBox();
            this.ckbPlay = new System.Windows.Forms.CheckBox();
            this.ckbWrite = new System.Windows.Forms.CheckBox();
            this.ckbDraw = new System.Windows.Forms.CheckBox();
            this.button1 = new System.Windows.Forms.Button();
            this.cmbDepartment = new System.Windows.Forms.ComboBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.txtName = new System.Windows.Forms.TextBox();
            this.txtID = new System.Windows.Forms.TextBox();
            this.txtMobile = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rdbFemale = new System.Windows.Forms.RadioButton();
            this.rdbMale = new System.Windows.Forms.RadioButton();
            this.dtpDOB = new System.Windows.Forms.DateTimePicker();
            this.lblHobby = new System.Windows.Forms.Label();
            this.lblDob = new System.Windows.Forms.Label();
            this.lblGender = new System.Windows.Forms.Label();
            this.lblMobile = new System.Windows.Forms.Label();
            this.lblEmail = new System.Windows.Forms.Label();
            this.lblDepartment = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.lblID = new System.Windows.Forms.Label();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripProgressBar1 = new System.Windows.Forms.ToolStripProgressBar();
            this.tbSalary = new System.Windows.Forms.TabPage();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStrip2 = new System.Windows.Forms.ToolStrip();
            this.rtbEMI = new System.Windows.Forms.RichTextBox();
            this.txtTenure = new System.Windows.Forms.TextBox();
            this.lblTenure = new System.Windows.Forms.Label();
            this.txtRateOfInterest = new System.Windows.Forms.TextBox();
            this.txtLoanAmount = new System.Windows.Forms.TextBox();
            this.txtBasicSalary = new System.Windows.Forms.TextBox();
            this.btnEMI = new System.Windows.Forms.Button();
            this.lblRate = new System.Windows.Forms.Label();
            this.lblLoan = new System.Windows.Forms.Label();
            this.lblSalary = new System.Windows.Forms.Label();
            this.toolStripProgressBar2 = new System.Windows.Forms.ToolStripProgressBar();
            this.tabControl1.SuspendLayout();
            this.tbPersonal.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.tbSalary.SuspendLayout();
            this.toolStrip2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tbPersonal);
            this.tabControl1.Controls.Add(this.tbSalary);
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1003, 584);
            this.tabControl1.TabIndex = 0;
            // 
            // tbPersonal
            // 
            this.tbPersonal.BackColor = System.Drawing.Color.GhostWhite;
            this.tbPersonal.Controls.Add(this.lblMessage);
            this.tbPersonal.Controls.Add(this.btnSave);
            this.tbPersonal.Controls.Add(this.rtbView);
            this.tbPersonal.Controls.Add(this.ckbDance);
            this.tbPersonal.Controls.Add(this.ckbSing);
            this.tbPersonal.Controls.Add(this.ckbRead);
            this.tbPersonal.Controls.Add(this.ckbPlay);
            this.tbPersonal.Controls.Add(this.ckbWrite);
            this.tbPersonal.Controls.Add(this.ckbDraw);
            this.tbPersonal.Controls.Add(this.button1);
            this.tbPersonal.Controls.Add(this.cmbDepartment);
            this.tbPersonal.Controls.Add(this.txtEmail);
            this.tbPersonal.Controls.Add(this.txtName);
            this.tbPersonal.Controls.Add(this.txtID);
            this.tbPersonal.Controls.Add(this.txtMobile);
            this.tbPersonal.Controls.Add(this.groupBox1);
            this.tbPersonal.Controls.Add(this.dtpDOB);
            this.tbPersonal.Controls.Add(this.lblHobby);
            this.tbPersonal.Controls.Add(this.lblDob);
            this.tbPersonal.Controls.Add(this.lblGender);
            this.tbPersonal.Controls.Add(this.lblMobile);
            this.tbPersonal.Controls.Add(this.lblEmail);
            this.tbPersonal.Controls.Add(this.lblDepartment);
            this.tbPersonal.Controls.Add(this.lblName);
            this.tbPersonal.Controls.Add(this.lblID);
            this.tbPersonal.Controls.Add(this.toolStrip1);
            this.tbPersonal.ForeColor = System.Drawing.SystemColors.ControlText;
            this.tbPersonal.Location = new System.Drawing.Point(4, 22);
            this.tbPersonal.Name = "tbPersonal";
            this.tbPersonal.Padding = new System.Windows.Forms.Padding(3);
            this.tbPersonal.Size = new System.Drawing.Size(995, 558);
            this.tbPersonal.TabIndex = 0;
            this.tbPersonal.Text = "Personal Details";
            // 
            // lblMessage
            // 
            this.lblMessage.AutoSize = true;
            this.lblMessage.Location = new System.Drawing.Point(244, 48);
            this.lblMessage.Name = "lblMessage";
            this.lblMessage.Size = new System.Drawing.Size(0, 13);
            this.lblMessage.TabIndex = 42;
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.btnSave.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.ForeColor = System.Drawing.Color.White;
            this.btnSave.Location = new System.Drawing.Point(313, 484);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(163, 52);
            this.btnSave.TabIndex = 41;
            this.btnSave.Text = "SAVE";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // rtbView
            // 
            this.rtbView.Location = new System.Drawing.Point(621, 64);
            this.rtbView.Name = "rtbView";
            this.rtbView.Size = new System.Drawing.Size(295, 457);
            this.rtbView.TabIndex = 40;
            this.rtbView.Text = "";
            // 
            // ckbDance
            // 
            this.ckbDance.AutoSize = true;
            this.ckbDance.Location = new System.Drawing.Point(429, 442);
            this.ckbDance.Name = "ckbDance";
            this.ckbDance.Size = new System.Drawing.Size(66, 17);
            this.ckbDance.TabIndex = 39;
            this.ckbDance.Text = "Dancing";
            this.ckbDance.UseVisualStyleBackColor = true;
            // 
            // ckbSing
            // 
            this.ckbSing.AutoSize = true;
            this.ckbSing.Location = new System.Drawing.Point(333, 442);
            this.ckbSing.Name = "ckbSing";
            this.ckbSing.Size = new System.Drawing.Size(61, 17);
            this.ckbSing.TabIndex = 38;
            this.ckbSing.Text = "Singing";
            this.ckbSing.UseVisualStyleBackColor = true;
            // 
            // ckbRead
            // 
            this.ckbRead.AutoSize = true;
            this.ckbRead.Location = new System.Drawing.Point(247, 442);
            this.ckbRead.Name = "ckbRead";
            this.ckbRead.Size = new System.Drawing.Size(66, 17);
            this.ckbRead.TabIndex = 37;
            this.ckbRead.Text = "Reading";
            this.ckbRead.UseVisualStyleBackColor = true;
            // 
            // ckbPlay
            // 
            this.ckbPlay.AutoSize = true;
            this.ckbPlay.Location = new System.Drawing.Point(429, 403);
            this.ckbPlay.Name = "ckbPlay";
            this.ckbPlay.Size = new System.Drawing.Size(60, 17);
            this.ckbPlay.TabIndex = 36;
            this.ckbPlay.Text = "Playing";
            this.ckbPlay.UseVisualStyleBackColor = true;
            // 
            // ckbWrite
            // 
            this.ckbWrite.AutoSize = true;
            this.ckbWrite.Location = new System.Drawing.Point(333, 403);
            this.ckbWrite.Name = "ckbWrite";
            this.ckbWrite.Size = new System.Drawing.Size(59, 17);
            this.ckbWrite.TabIndex = 35;
            this.ckbWrite.Text = "Writing";
            this.ckbWrite.UseVisualStyleBackColor = true;
            // 
            // ckbDraw
            // 
            this.ckbDraw.AutoSize = true;
            this.ckbDraw.Location = new System.Drawing.Point(247, 403);
            this.ckbDraw.Name = "ckbDraw";
            this.ckbDraw.Size = new System.Drawing.Size(65, 17);
            this.ckbDraw.TabIndex = 34;
            this.ckbDraw.Text = "Drawing";
            this.ckbDraw.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.button1.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(84, 484);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(163, 52);
            this.button1.TabIndex = 33;
            this.button1.Text = "VIEW DETAILS";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // cmbDepartment
            // 
            this.cmbDepartment.FormattingEnabled = true;
            this.cmbDepartment.Items.AddRange(new object[] {
            "Sales Department",
            "Human Resource Department",
            "Trainees",
            "Software Development",
            "Associate Engineers"});
            this.cmbDepartment.Location = new System.Drawing.Point(247, 167);
            this.cmbDepartment.Name = "cmbDepartment";
            this.cmbDepartment.Size = new System.Drawing.Size(211, 21);
            this.cmbDepartment.TabIndex = 32;
            this.cmbDepartment.Text = "(not selected)";
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(247, 207);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(211, 20);
            this.txtEmail.TabIndex = 31;
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(247, 127);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(211, 20);
            this.txtName.TabIndex = 30;
            // 
            // txtID
            // 
            this.txtID.Location = new System.Drawing.Point(247, 87);
            this.txtID.Name = "txtID";
            this.txtID.Size = new System.Drawing.Size(211, 20);
            this.txtID.TabIndex = 29;
            // 
            // txtMobile
            // 
            this.txtMobile.Location = new System.Drawing.Point(247, 251);
            this.txtMobile.Name = "txtMobile";
            this.txtMobile.Size = new System.Drawing.Size(211, 20);
            this.txtMobile.TabIndex = 28;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rdbFemale);
            this.groupBox1.Controls.Add(this.rdbMale);
            this.groupBox1.Location = new System.Drawing.Point(237, 277);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(221, 67);
            this.groupBox1.TabIndex = 27;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "groupBox1";
            // 
            // rdbFemale
            // 
            this.rdbFemale.AutoSize = true;
            this.rdbFemale.Location = new System.Drawing.Point(111, 26);
            this.rdbFemale.Name = "rdbFemale";
            this.rdbFemale.Size = new System.Drawing.Size(59, 17);
            this.rdbFemale.TabIndex = 1;
            this.rdbFemale.Text = "Female";
            this.rdbFemale.UseVisualStyleBackColor = true;
            // 
            // rdbMale
            // 
            this.rdbMale.AutoSize = true;
            this.rdbMale.Checked = true;
            this.rdbMale.Location = new System.Drawing.Point(10, 26);
            this.rdbMale.Name = "rdbMale";
            this.rdbMale.Size = new System.Drawing.Size(48, 17);
            this.rdbMale.TabIndex = 0;
            this.rdbMale.TabStop = true;
            this.rdbMale.Text = "Male";
            this.rdbMale.UseVisualStyleBackColor = true;
            // 
            // dtpDOB
            // 
            this.dtpDOB.Location = new System.Drawing.Point(247, 350);
            this.dtpDOB.Name = "dtpDOB";
            this.dtpDOB.Size = new System.Drawing.Size(211, 20);
            this.dtpDOB.TabIndex = 26;
            // 
            // lblHobby
            // 
            this.lblHobby.AutoSize = true;
            this.lblHobby.Font = new System.Drawing.Font("Modern No. 20", 8.999999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHobby.Location = new System.Drawing.Point(60, 403);
            this.lblHobby.Name = "lblHobby";
            this.lblHobby.Size = new System.Drawing.Size(128, 15);
            this.lblHobby.TabIndex = 8;
            this.lblHobby.Text = "HOBBIES                     :";
            // 
            // lblDob
            // 
            this.lblDob.AutoSize = true;
            this.lblDob.Font = new System.Drawing.Font("Modern No. 20", 8.999999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDob.Location = new System.Drawing.Point(60, 350);
            this.lblDob.Name = "lblDob";
            this.lblDob.Size = new System.Drawing.Size(129, 15);
            this.lblDob.TabIndex = 7;
            this.lblDob.Text = "DOB                               :";
            // 
            // lblGender
            // 
            this.lblGender.AutoSize = true;
            this.lblGender.Font = new System.Drawing.Font("Modern No. 20", 8.999999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGender.Location = new System.Drawing.Point(60, 305);
            this.lblGender.Name = "lblGender";
            this.lblGender.Size = new System.Drawing.Size(128, 15);
            this.lblGender.TabIndex = 6;
            this.lblGender.Text = "GENDER                       :";
            // 
            // lblMobile
            // 
            this.lblMobile.AutoSize = true;
            this.lblMobile.Font = new System.Drawing.Font("Modern No. 20", 8.999999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMobile.Location = new System.Drawing.Point(60, 257);
            this.lblMobile.Name = "lblMobile";
            this.lblMobile.Size = new System.Drawing.Size(130, 15);
            this.lblMobile.TabIndex = 5;
            this.lblMobile.Text = "MOBILE NUMBER      :";
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.Font = new System.Drawing.Font("Modern No. 20", 8.999999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmail.Location = new System.Drawing.Point(60, 209);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(129, 15);
            this.lblEmail.TabIndex = 4;
            this.lblEmail.Text = "EMAIL ID                     :";
            // 
            // lblDepartment
            // 
            this.lblDepartment.AutoSize = true;
            this.lblDepartment.Font = new System.Drawing.Font("Modern No. 20", 8.999999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDepartment.Location = new System.Drawing.Point(60, 167);
            this.lblDepartment.Name = "lblDepartment";
            this.lblDepartment.Size = new System.Drawing.Size(130, 15);
            this.lblDepartment.TabIndex = 3;
            this.lblDepartment.Text = "DEPARTMENT             :";
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Font = new System.Drawing.Font("Modern No. 20", 8.999999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblName.Location = new System.Drawing.Point(60, 127);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(128, 15);
            this.lblName.TabIndex = 2;
            this.lblName.Text = "NAME                            :";
            // 
            // lblID
            // 
            this.lblID.AutoSize = true;
            this.lblID.Font = new System.Drawing.Font("Modern No. 20", 8.999999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblID.Location = new System.Drawing.Point(60, 87);
            this.lblID.Name = "lblID";
            this.lblID.Size = new System.Drawing.Size(130, 15);
            this.lblID.TabIndex = 1;
            this.lblID.Text = "EMPLOYEE ID            :";
            // 
            // toolStrip1
            // 
            this.toolStrip1.BackColor = System.Drawing.Color.Turquoise;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripProgressBar1});
            this.toolStrip1.Location = new System.Drawing.Point(3, 3);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(989, 25);
            this.toolStrip1.TabIndex = 0;
            this.toolStrip1.Text = "toolStrip1";
            this.toolStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.toolStrip1_ItemClicked);
            // 
            // toolStripProgressBar1
            // 
            this.toolStripProgressBar1.Name = "toolStripProgressBar1";
            this.toolStripProgressBar1.Size = new System.Drawing.Size(100, 22);
            // 
            // tbSalary
            // 
            this.tbSalary.BackColor = System.Drawing.Color.GhostWhite;
            this.tbSalary.Controls.Add(this.statusStrip1);
            this.tbSalary.Controls.Add(this.toolStrip2);
            this.tbSalary.Controls.Add(this.rtbEMI);
            this.tbSalary.Controls.Add(this.txtTenure);
            this.tbSalary.Controls.Add(this.lblTenure);
            this.tbSalary.Controls.Add(this.txtRateOfInterest);
            this.tbSalary.Controls.Add(this.txtLoanAmount);
            this.tbSalary.Controls.Add(this.txtBasicSalary);
            this.tbSalary.Controls.Add(this.btnEMI);
            this.tbSalary.Controls.Add(this.lblRate);
            this.tbSalary.Controls.Add(this.lblLoan);
            this.tbSalary.Controls.Add(this.lblSalary);
            this.tbSalary.Location = new System.Drawing.Point(4, 22);
            this.tbSalary.Name = "tbSalary";
            this.tbSalary.Padding = new System.Windows.Forms.Padding(3);
            this.tbSalary.Size = new System.Drawing.Size(995, 558);
            this.tbSalary.TabIndex = 1;
            this.tbSalary.Text = "Salary Details";
            // 
            // statusStrip1
            // 
            this.statusStrip1.Location = new System.Drawing.Point(3, 533);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(989, 22);
            this.statusStrip1.TabIndex = 12;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStrip2
            // 
            this.toolStrip2.BackColor = System.Drawing.Color.Turquoise;
            this.toolStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripProgressBar2});
            this.toolStrip2.Location = new System.Drawing.Point(3, 3);
            this.toolStrip2.Name = "toolStrip2";
            this.toolStrip2.Size = new System.Drawing.Size(989, 25);
            this.toolStrip2.TabIndex = 11;
            this.toolStrip2.Text = "toolStrip2";
            // 
            // rtbEMI
            // 
            this.rtbEMI.Location = new System.Drawing.Point(690, 85);
            this.rtbEMI.Name = "rtbEMI";
            this.rtbEMI.Size = new System.Drawing.Size(247, 404);
            this.rtbEMI.TabIndex = 10;
            this.rtbEMI.Text = "";
            // 
            // txtTenure
            // 
            this.txtTenure.Location = new System.Drawing.Point(359, 259);
            this.txtTenure.Multiline = true;
            this.txtTenure.Name = "txtTenure";
            this.txtTenure.Size = new System.Drawing.Size(225, 29);
            this.txtTenure.TabIndex = 9;
            this.txtTenure.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblTenure
            // 
            this.lblTenure.AutoSize = true;
            this.lblTenure.Font = new System.Drawing.Font("Modern No. 20", 8.999999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTenure.Location = new System.Drawing.Point(60, 261);
            this.lblTenure.Name = "lblTenure";
            this.lblTenure.Size = new System.Drawing.Size(242, 15);
            this.lblTenure.TabIndex = 8;
            this.lblTenure.Text = "LOAN TENURE                                                  :";
            // 
            // txtRateOfInterest
            // 
            this.txtRateOfInterest.Location = new System.Drawing.Point(359, 196);
            this.txtRateOfInterest.Multiline = true;
            this.txtRateOfInterest.Name = "txtRateOfInterest";
            this.txtRateOfInterest.Size = new System.Drawing.Size(225, 29);
            this.txtRateOfInterest.TabIndex = 7;
            // 
            // txtLoanAmount
            // 
            this.txtLoanAmount.Location = new System.Drawing.Point(359, 142);
            this.txtLoanAmount.Multiline = true;
            this.txtLoanAmount.Name = "txtLoanAmount";
            this.txtLoanAmount.Size = new System.Drawing.Size(225, 29);
            this.txtLoanAmount.TabIndex = 6;
            // 
            // txtBasicSalary
            // 
            this.txtBasicSalary.Location = new System.Drawing.Point(359, 85);
            this.txtBasicSalary.Multiline = true;
            this.txtBasicSalary.Name = "txtBasicSalary";
            this.txtBasicSalary.Size = new System.Drawing.Size(225, 29);
            this.txtBasicSalary.TabIndex = 5;
            // 
            // btnEMI
            // 
            this.btnEMI.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.btnEMI.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEMI.ForeColor = System.Drawing.Color.White;
            this.btnEMI.Location = new System.Drawing.Point(64, 369);
            this.btnEMI.Name = "btnEMI";
            this.btnEMI.Size = new System.Drawing.Size(205, 74);
            this.btnEMI.TabIndex = 4;
            this.btnEMI.Text = "CALCULATE EMI";
            this.btnEMI.UseVisualStyleBackColor = false;
            this.btnEMI.Click += new System.EventHandler(this.btnEMI_Click);
            // 
            // lblRate
            // 
            this.lblRate.AutoSize = true;
            this.lblRate.Font = new System.Drawing.Font("Modern No. 20", 8.999999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRate.Location = new System.Drawing.Point(60, 198);
            this.lblRate.Name = "lblRate";
            this.lblRate.Size = new System.Drawing.Size(242, 15);
            this.lblRate.TabIndex = 3;
            this.lblRate.Text = "INTEREST  RATE (In %)                                    :";
            // 
            // lblLoan
            // 
            this.lblLoan.AutoSize = true;
            this.lblLoan.Font = new System.Drawing.Font("Modern No. 20", 8.999999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLoan.Location = new System.Drawing.Point(61, 144);
            this.lblLoan.Name = "lblLoan";
            this.lblLoan.Size = new System.Drawing.Size(241, 15);
            this.lblLoan.TabIndex = 2;
            this.lblLoan.Text = "LOAN AMOUNT                                                 :";
            // 
            // lblSalary
            // 
            this.lblSalary.AutoSize = true;
            this.lblSalary.Font = new System.Drawing.Font("Modern No. 20", 8.999999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalary.Location = new System.Drawing.Point(61, 85);
            this.lblSalary.Name = "lblSalary";
            this.lblSalary.Size = new System.Drawing.Size(242, 15);
            this.lblSalary.TabIndex = 1;
            this.lblSalary.Text = "BASIC SALARY                                                 :";
            // 
            // toolStripProgressBar2
            // 
            this.toolStripProgressBar2.Name = "toolStripProgressBar2";
            this.toolStripProgressBar2.Size = new System.Drawing.Size(100, 22);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLight;
            this.ClientSize = new System.Drawing.Size(1030, 595);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControl1.ResumeLayout(false);
            this.tbPersonal.ResumeLayout(false);
            this.tbPersonal.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.tbSalary.ResumeLayout(false);
            this.tbSalary.PerformLayout();
            this.toolStrip2.ResumeLayout(false);
            this.toolStrip2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tbPersonal;
        private System.Windows.Forms.TabPage tbSalary;
        private System.Windows.Forms.ComboBox cmbDepartment;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.TextBox txtID;
        private System.Windows.Forms.TextBox txtMobile;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rdbFemale;
        private System.Windows.Forms.RadioButton rdbMale;
        private System.Windows.Forms.DateTimePicker dtpDOB;
        private System.Windows.Forms.Label lblHobby;
        private System.Windows.Forms.Label lblDob;
        private System.Windows.Forms.Label lblGender;
        private System.Windows.Forms.Label lblMobile;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.Label lblDepartment;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label lblID;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txtRateOfInterest;
        private System.Windows.Forms.TextBox txtLoanAmount;
        private System.Windows.Forms.TextBox txtBasicSalary;
        private System.Windows.Forms.Button btnEMI;
        private System.Windows.Forms.Label lblRate;
        private System.Windows.Forms.Label lblLoan;
        private System.Windows.Forms.Label lblSalary;
        private System.Windows.Forms.CheckBox ckbDance;
        private System.Windows.Forms.CheckBox ckbSing;
        private System.Windows.Forms.CheckBox ckbRead;
        private System.Windows.Forms.CheckBox ckbPlay;
        private System.Windows.Forms.CheckBox ckbWrite;
        private System.Windows.Forms.CheckBox ckbDraw;
        private System.Windows.Forms.RichTextBox rtbView;
        private System.Windows.Forms.TextBox txtTenure;
        private System.Windows.Forms.Label lblTenure;
        private System.Windows.Forms.RichTextBox rtbEMI;
        private System.Windows.Forms.ToolStrip toolStrip2;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripProgressBar toolStripProgressBar1;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Label lblMessage;
        private System.Windows.Forms.ToolStripProgressBar toolStripProgressBar2;
    }
}

