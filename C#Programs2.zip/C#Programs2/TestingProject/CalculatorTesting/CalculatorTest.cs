﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using TestingProject;


namespace CalculatorTesting
{
    [TestClass]
    public class CalculatorTest
    {
        [TestMethod]
        public void TestADDMethod()
        {
            Calculator p1 = new Calculator();
            Assert.AreEqual(31, p1.Add(20, 11));
        }
        [TestMethod]
        public void TestSUBMethod()
        {
            Calculator p1 = new Calculator();
            Assert.AreEqual(9, p1.Sub(20, 11));
        }
    }
}
