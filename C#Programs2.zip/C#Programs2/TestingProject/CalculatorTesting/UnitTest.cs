﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using TestingProject;

namespace CalculatorTesting
{
    [TestFixture]
    class UnitTest
    {
        [TestCase]
        public void Add()
        {
            Calculator p1 = new Calculator();
            Assert.AreEqual(1, p1.Add(20, 11));
        }

        [TestCase]
        public void Sub()
        {
            Calculator p1 = new Calculator();
            Assert.AreEqual(0, p1.Sub(20, 11));
        }
    }
}
