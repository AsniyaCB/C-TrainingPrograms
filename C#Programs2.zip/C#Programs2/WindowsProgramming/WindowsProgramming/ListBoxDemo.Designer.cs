﻿namespace WindowsProgramming
{
    partial class ListBoxDemo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lstDays = new System.Windows.Forms.ListBox();
            this.btnShow1 = new System.Windows.Forms.Button();
            this.btnShow2 = new System.Windows.Forms.Button();
            this.lstMonths = new System.Windows.Forms.ListBox();
            this.btnLoadMonths = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lstDays
            // 
            this.lstDays.FormattingEnabled = true;
            this.lstDays.Location = new System.Drawing.Point(103, 52);
            this.lstDays.Name = "lstDays";
            this.lstDays.Size = new System.Drawing.Size(178, 186);
            this.lstDays.TabIndex = 0;
            this.lstDays.SelectedIndexChanged += new System.EventHandler(this.lstDays_SelectedIndexChanged);
            // 
            // btnShow1
            // 
            this.btnShow1.Location = new System.Drawing.Point(153, 280);
            this.btnShow1.Name = "btnShow1";
            this.btnShow1.Size = new System.Drawing.Size(75, 23);
            this.btnShow1.TabIndex = 1;
            this.btnShow1.Text = "Show days1";
            this.btnShow1.UseVisualStyleBackColor = true;
            this.btnShow1.Click += new System.EventHandler(this.btnShow1_Click);
            // 
            // btnShow2
            // 
            this.btnShow2.Location = new System.Drawing.Point(153, 340);
            this.btnShow2.Name = "btnShow2";
            this.btnShow2.Size = new System.Drawing.Size(75, 23);
            this.btnShow2.TabIndex = 2;
            this.btnShow2.Text = "Show days2";
            this.btnShow2.UseVisualStyleBackColor = true;
            this.btnShow2.Click += new System.EventHandler(this.btnShow2_Click);
            // 
            // lstMonths
            // 
            this.lstMonths.FormattingEnabled = true;
            this.lstMonths.Location = new System.Drawing.Point(536, 52);
            this.lstMonths.Name = "lstMonths";
            this.lstMonths.Size = new System.Drawing.Size(178, 186);
            this.lstMonths.TabIndex = 3;
            // 
            // btnLoadMonths
            // 
            this.btnLoadMonths.Location = new System.Drawing.Point(574, 279);
            this.btnLoadMonths.Name = "btnLoadMonths";
            this.btnLoadMonths.Size = new System.Drawing.Size(118, 39);
            this.btnLoadMonths.TabIndex = 4;
            this.btnLoadMonths.Text = "Load Months";
            this.btnLoadMonths.UseVisualStyleBackColor = true;
            this.btnLoadMonths.Click += new System.EventHandler(this.btnLoadMonths_Click);
            // 
            // ListBoxDemo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnLoadMonths);
            this.Controls.Add(this.lstMonths);
            this.Controls.Add(this.btnShow2);
            this.Controls.Add(this.btnShow1);
            this.Controls.Add(this.lstDays);
            this.Name = "ListBoxDemo";
            this.Text = "ListBoxDemo";
            this.Load += new System.EventHandler(this.ListBoxDemo_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox lstDays;
        private System.Windows.Forms.Button btnShow1;
        private System.Windows.Forms.Button btnShow2;
        private System.Windows.Forms.ListBox lstMonths;
        private System.Windows.Forms.Button btnLoadMonths;
    }
}