﻿namespace WindowsProgramming
{
    partial class MessageBoxDemo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnClick1 = new System.Windows.Forms.Button();
            this.btnClick2 = new System.Windows.Forms.Button();
            this.btnClick4 = new System.Windows.Forms.Button();
            this.btnClick3 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnClick1
            // 
            this.btnClick1.Location = new System.Drawing.Point(85, 173);
            this.btnClick1.Name = "btnClick1";
            this.btnClick1.Size = new System.Drawing.Size(84, 59);
            this.btnClick1.TabIndex = 0;
            this.btnClick1.Text = "button1";
            this.btnClick1.UseVisualStyleBackColor = true;
            this.btnClick1.Click += new System.EventHandler(this.btnClick1_Click);
            // 
            // btnClick2
            // 
            this.btnClick2.Location = new System.Drawing.Point(249, 173);
            this.btnClick2.Name = "btnClick2";
            this.btnClick2.Size = new System.Drawing.Size(84, 59);
            this.btnClick2.TabIndex = 1;
            this.btnClick2.Text = "button2";
            this.btnClick2.UseVisualStyleBackColor = true;
            this.btnClick2.Click += new System.EventHandler(this.btnClick2_Click);
            // 
            // btnClick4
            // 
            this.btnClick4.Location = new System.Drawing.Point(445, 173);
            this.btnClick4.Name = "btnClick4";
            this.btnClick4.Size = new System.Drawing.Size(84, 59);
            this.btnClick4.TabIndex = 2;
            this.btnClick4.Text = "button3";
            this.btnClick4.UseVisualStyleBackColor = true;
            // 
            // btnClick3
            // 
            this.btnClick3.Location = new System.Drawing.Point(631, 173);
            this.btnClick3.Name = "btnClick3";
            this.btnClick3.Size = new System.Drawing.Size(84, 59);
            this.btnClick3.TabIndex = 3;
            this.btnClick3.Text = "button4";
            this.btnClick3.UseVisualStyleBackColor = true;
            // 
            // MessageBoxDemo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnClick3);
            this.Controls.Add(this.btnClick4);
            this.Controls.Add(this.btnClick2);
            this.Controls.Add(this.btnClick1);
            this.Name = "MessageBoxDemo";
            this.Text = "MessageBoxDemo";
            this.Load += new System.EventHandler(this.MessageBoxDemo_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnClick1;
        private System.Windows.Forms.Button btnClick2;
        private System.Windows.Forms.Button btnClick4;
        private System.Windows.Forms.Button btnClick3;
    }
}