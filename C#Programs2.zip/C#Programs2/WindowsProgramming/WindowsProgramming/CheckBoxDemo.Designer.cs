﻿namespace WindowsProgramming
{
    partial class CheckBoxDemo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ckbOption1 = new System.Windows.Forms.CheckBox();
            this.ckbOption2 = new System.Windows.Forms.CheckBox();
            this.ckbOption3 = new System.Windows.Forms.CheckBox();
            this.btnClick = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // ckbOption1
            // 
            this.ckbOption1.AutoSize = true;
            this.ckbOption1.Location = new System.Drawing.Point(152, 66);
            this.ckbOption1.Name = "ckbOption1";
            this.ckbOption1.Size = new System.Drawing.Size(53, 17);
            this.ckbOption1.TabIndex = 0;
            this.ckbOption1.Text = "music";
            this.ckbOption1.UseVisualStyleBackColor = true;
            // 
            // ckbOption2
            // 
            this.ckbOption2.AutoSize = true;
            this.ckbOption2.Location = new System.Drawing.Point(152, 108);
            this.ckbOption2.Name = "ckbOption2";
            this.ckbOption2.Size = new System.Drawing.Size(59, 17);
            this.ckbOption2.TabIndex = 1;
            this.ckbOption2.Text = "movies";
            this.ckbOption2.UseVisualStyleBackColor = true;
            // 
            // ckbOption3
            // 
            this.ckbOption3.AutoSize = true;
            this.ckbOption3.Location = new System.Drawing.Point(152, 143);
            this.ckbOption3.Name = "ckbOption3";
            this.ckbOption3.Size = new System.Drawing.Size(57, 17);
            this.ckbOption3.TabIndex = 2;
            this.ckbOption3.Text = "games";
            this.ckbOption3.UseVisualStyleBackColor = true;
            // 
            // btnClick
            // 
            this.btnClick.Location = new System.Drawing.Point(230, 206);
            this.btnClick.Name = "btnClick";
            this.btnClick.Size = new System.Drawing.Size(170, 78);
            this.btnClick.TabIndex = 3;
            this.btnClick.Text = "Click me to see selected";
            this.btnClick.UseVisualStyleBackColor = true;
            this.btnClick.Click += new System.EventHandler(this.btnClick_Click);
            // 
            // CheckBoxDemo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnClick);
            this.Controls.Add(this.ckbOption3);
            this.Controls.Add(this.ckbOption2);
            this.Controls.Add(this.ckbOption1);
            this.Name = "CheckBoxDemo";
            this.Text = "CheckBoxDemo";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox ckbOption1;
        private System.Windows.Forms.CheckBox ckbOption2;
        private System.Windows.Forms.CheckBox ckbOption3;
        private System.Windows.Forms.Button btnClick;
    }
}