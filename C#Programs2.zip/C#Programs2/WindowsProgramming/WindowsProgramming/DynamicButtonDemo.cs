﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsProgramming
{
    public partial class DynamicButtonDemo : Form
    {
        public DynamicButtonDemo()
        {
            InitializeComponent();
        }

        private void DynamicButtonDemo_Load(object sender, EventArgs e)
        {
            CreateDynamicButton();
        }
        private void CreateDynamicButton()
        {
            Button dynamicButton = new Button();
            dynamicButton.Height = 40;
            dynamicButton.Width = 300;
            dynamicButton.BackColor = Color.PaleVioletRed;
            dynamicButton.ForeColor = Color.AliceBlue;
            dynamicButton.Location = new Point(20, 150);
            dynamicButton.Text = "Click me for terror";
            dynamicButton.Name = "Dynamic Button";
            dynamicButton.Font = new Font("Georgia", 16);

            dynamicButton.Click += new EventHandler(DynamicButton_Click);
            Controls.Add(dynamicButton);
        }
        private void DynamicButton_Click(object sender,EventArgs e)
        {
            MessageBox.Show("Dynamic Button is Clicked");
        }
    }
}
