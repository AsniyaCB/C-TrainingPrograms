﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsProgramming
{
    public partial class ListBoxDemo : Form
    {
        public ListBoxDemo()
        {
            InitializeComponent();
        }

        private void lstDays_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void ListBoxDemo_Load(object sender, EventArgs e)
        {
            lstDays.Items.Add("sunday");
            lstDays.Items.Add("monday");
            lstDays.Items.Add("tuesday");
            lstDays.Items.Add("wednesday");
            lstDays.Items.Add("thursday");
            lstDays.Items.Add("friday");
            lstDays.Items.Add("saturday");
            lstDays.SelectionMode = SelectionMode.MultiSimple;
        }

        private void btnShow1_Click(object sender, EventArgs e)
        {
            foreach (object obj in lstDays.SelectedItems)
            {
                MessageBox.Show(obj.ToString());
            }
        }

        private void btnShow2_Click(object sender, EventArgs e)
        {
            string items = "";
            foreach(var item in lstDays.SelectedItems)
            {
                items += item.ToString() + ",";
            }
            MessageBox.Show(items);
        }

        private void btnLoadMonths_Click(object sender, EventArgs e)
        {
            List<string> nList = new List<string>();
            nList.Add("january");
            nList.Add("february");
            nList.Add("march");
            nList.Add("april");
            nList.Add("may");
            nList.Add("june");
            nList.Add("july");
            nList.Add("august");
            nList.Add("september");
            nList.Add("october");
            nList.Add("november");
            nList.Add("december" + "");
            lstMonths.DataSource = nList;
         }
    }
}
