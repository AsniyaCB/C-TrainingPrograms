﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsProgramming
{
    public partial class MessageBoxDemo : Form
    {
        public MessageBoxDemo()
        {
            InitializeComponent();
        }

        private void MessageBoxDemo_Load(object sender, EventArgs e)
        {

        }

        private void btnClick1_Click(object sender, EventArgs e)
        {
            string message = "Do you want to close?";
            string title = "Close Window";
            MessageBoxButtons buttons = MessageBoxButtons.AbortRetryIgnore;
            DialogResult result = MessageBox.Show(message, title, buttons, MessageBoxIcon.Error);
            if (result == DialogResult.Abort)
            {
                MessageBox.Show("abort");
            }
            else if (result == DialogResult.Retry)
            {
                MessageBox.Show("retry");
            }
            else
            {
                MessageBox.Show("ignore");
            }
        }

        private void btnClick2_Click(object sender, EventArgs e)
        {
            string message = "hello"
  ; string title = "GREETINGS";
            MessageBox.Show(message,title);
        }
    }
}
