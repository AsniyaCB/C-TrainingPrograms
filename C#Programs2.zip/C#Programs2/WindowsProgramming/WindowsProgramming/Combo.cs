﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsProgramming
{
    public partial class cmbItems : Form
    {
        public cmbItems()
        {
            InitializeComponent();
        }

        private void cmbItems_Load(object sender, EventArgs e)
        {
            comboBox1.Items.Add("auto");
            comboBox1.Items.Add("pp");
            comboBox1.Items.Add("fff");
            comboBox1.Items.Add("eref");
            comboBox1.Text = "select";
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selected = comboBox1.Items[comboBox1.SelectedIndex].ToString();
            MessageBox.Show(selected);
        }

        private void comboBox1_SelectedValueChanged(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            dateTimePicker1.MinDate = new DateTime(2019, 1, 1);
            dateTimePicker1.MaxDate = DateTime.Today;
            dateTimePicker1.CustomFormat = "MMMMdd,yyyy-dddd";
            dateTimePicker1.Format = DateTimePickerFormat.Custom;
        }
    }
}
