﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsProgramming
{
    public partial class MiniCalculator : Form
    {
        public MiniCalculator()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int value1, value2, result;
            try
            {
                if (txtValue1.Text != " " && txtValue2.Text != "")
                {
                    value1 = Convert.ToInt32(txtValue1.Text.ToString());
                    value2 = Convert.ToInt32(txtValue1.Text.ToString());
                    result = value1 + value2;
                    txtResult.Text = result.ToString();
                    lblMessage.Text = "";
                }
                else
                {
                    lblMessage.Text = "Enter Both values";

                }
            }
            catch (Exception ex)
            {
                lblMessage.Text = ex.Message.ToString();
            }
        }

        private void MiniCalculator_Load(object sender, EventArgs e)
        {

        }

        private void txtValue1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnSub_Click(object sender, EventArgs e)
        {
            int value1, value2, result;
            try
            {
                if (txtValue1.Text != " " && txtValue2.Text != "")
                {
                    value1 = Convert.ToInt32(txtValue1.Text.ToString());
                    value2 = Convert.ToInt32(txtValue1.Text.ToString());
                    result = value1 - value2;
                    txtResult.Text = result.ToString();
                    lblMessage.Text = "";
                }
                else
                {
                    lblMessage.Text = "Enter Both values";

                }
            }
            catch (Exception ex)
            {
                lblMessage.Text = ex.Message.ToString();
            }
        }

        private void btnMul_Click(object sender, EventArgs e)
        {
            int value1, value2, result;
            try
            {
                if (txtValue1.Text != " " && txtValue2.Text != "")
                {
                    value1 = Convert.ToInt32(txtValue1.Text.ToString());
                    value2 = Convert.ToInt32(txtValue1.Text.ToString());
                    result = value1 * value2;
                    txtResult.Text = result.ToString();
                    lblMessage.Text = "";
                }
                else
                {
                    lblMessage.Text = "Enter Both values";

                }
            }
            catch (Exception ex)
            {
                lblMessage.Text = ex.Message.ToString();
            }
        }

        private void btnDiv_Click(object sender, EventArgs e)
        {
            int value1, value2, result;
            try
            {
                if (txtValue1.Text != " " && txtValue2.Text != "")
                {
                    value1 = Convert.ToInt32(txtValue1.Text.ToString());
                    value2 = Convert.ToInt32(txtValue1.Text.ToString());
                    result = value1 / value2;
                    txtResult.Text = result.ToString();
                    lblMessage.Text = "";
                }
                else
                {
                    lblMessage.Text = "Enter Both values";

                }
            }
            catch (Exception ex)
            {
                lblMessage.Text = ex.Message.ToString();
            }
        }

        private void txtValue2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
