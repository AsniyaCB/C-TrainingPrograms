﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsProgramming
{
    public partial class CheckBoxDemo : Form
    {
        public CheckBoxDemo()
        {
            InitializeComponent();
        }

        private void btnClick_Click(object sender, EventArgs e)
        {
            string selected = "";
            if (ckbOption1.Checked)
            {
                selected += ckbOption1.Text+"|";

            }
            if (ckbOption3.Checked)
            {
                selected += ckbOption2.Text+"|";


            }
            if (ckbOption3.Checked)
            {
                selected += ckbOption3.Text;

            }
            MessageBox.Show("Selected:" + selected);
        }
    }
}
