﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestApp2
{
    class ObsoleteDemo
    {
        public static void Main()
        {
            List<int> list = new List<int>();
            list.Add(10); list.Add(20); list.Add(30); list.Add(40); list.Add(50);
            int result1 = Calculator.Add(10, 20);
            int result2 = Calculator.Add(list);
            Console.WriteLine("Result 1:" + result1);
            Console.WriteLine("Result 2:" + result2);
            Console.ReadLine();
        }
    }
    [Obsolete("depricated Class")]
    class Calculator
    {
        [Obsolete("new method :int Add(List,int. numbers")]
        public static int Add(int value1, int value2)
        {
            return (value1 + value2);
        }
        public static int Add(List<int> numbers)

        {
            int sum = 0;
            foreach (int number in numbers)
            {
                sum += number;
            }
            return sum;
        }
    }
}
