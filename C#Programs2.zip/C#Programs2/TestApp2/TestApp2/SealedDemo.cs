﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestApp2
{
    class SealedDemo
    {
        class Util
        {
            public virtual void Calculate()
            {

            }
        }
        class Helper : Util
        {
            public sealed override void Calculate()
                
            {

            } 
        }
        class ABC : Helper
        {
            //public override void Calculate()
            //{
                
            //}
        }
    }
}
