﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestApp2
{
    class Matrix
    {
        int row, column;
        int[,] matrix;
        
        public static void Main(string[] args)
        {
            Matrix obj = new Matrix(2,2);
            Matrix obj1 = new Matrix(2, 2);
            Matrix obj3 = new Matrix(2, 2);
            //Matrix object4 = new Matrix(2, 2);
            obj.Read();            
            obj.Display();
            
            obj1.Read();
            obj1.Display();
            
            obj3.AddMatrix(obj,obj1);
            obj3.Display();          
            obj3.SubtractMatrix(obj, obj1);
            obj3.Display();            
            Console.ReadKey();
        }
        
        public Matrix(int r,int c)
        {
            row = r;
            column = c;
            matrix = new int[row, column];
          
        }
        public void Read()
        {
            
           
            Console.WriteLine("Enter the values for Matrix :");
            for (int i = 0; i < row; i++)
            {
                for (int j = 0; j < column; j++)
                {
                    matrix[i, j] = Convert.ToInt32(Console.ReadLine());
                }
            }
           

        }

        public void AddMatrix(Matrix array1,Matrix array2)
        {
           // matrix1 = new int[row, column];
           
            for (int i = 0; i < row; i++)
            {
                for (int j = 0; j < column; j++)
                {
                    matrix[i, j] = array1.matrix[i, j] + array2.matrix[i, j];
                }
            }
        }
        public void SubtractMatrix(Matrix array1, Matrix array2)
        {
           // matrix1 = new int[row, column];
            for (int i = 0; i < row; i++)
            {
                for (int j = 0; j < column; j++)
                {
                    matrix[i, j] = array1.matrix[i, j] - array2.matrix[i, j];
                }
            }
        }
        public void Display()
        {
            Console.WriteLine("MATRIX ");
            for (int i = 0; i < row; i++)
            {
                for (int j = 0; j < column; j++)
                {
                    Console.Write(matrix[i, j]+"\t"); 
                }
                Console.WriteLine();
            }
            
        }
    }
}
