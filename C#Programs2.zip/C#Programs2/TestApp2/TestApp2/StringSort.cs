﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestApp2
{
    class StringSort
    {
        string input;
        char[] array;
        char ch;
        
        public static void Main()
        {
            StringSort obj = new StringSort();
            obj.Read();
            obj.Sort();
            obj.Display();
            Console.ReadKey();
        }

        public void Read() {

            Console.Write("Enter the input the string : ");
            input = Console.ReadLine();
            
            array = input.ToCharArray(0, input.Length);
        }
        public void Sort() {

            for (int i = 1; i < input.Length; i++)
                for (int j = 0; j < input.Length - i; j++)

                    if (array[j].CompareTo(array[j + 1])>0)
                    {
                        ch = array[j];
                        array[j] = array[j + 1];
                        array[j + 1] = ch;
                    }
        }
        public void Display() {
            Console.Write("SORTED STRING : \n");
            foreach (char c in array)
            {
                ch = c;
                Console.Write("{0} ", ch);
            }
            Console.WriteLine("\n");

        
    }
}
}
