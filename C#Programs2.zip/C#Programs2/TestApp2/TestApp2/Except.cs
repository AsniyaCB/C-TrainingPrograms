﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestApp2
{
  class Except
    {
        public static int Read()
        {
            int value = 0; bool flag = true;
            do
            {
                try
                {
                    value = Convert.ToInt32(Console.ReadLine());
                    flag = false;
                }
                catch
                {
                    Console.WriteLine("WRONG VALUE \n Enter a Valid integer:");
                }
            } while (flag);
            return value;

        }
        public static void Main()
        {


            Except.Read();
            Console.ReadKey();
        }

    }
}
