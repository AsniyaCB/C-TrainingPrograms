﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestApp2
{
    class CarPark
    {
        int[] parkSlot = new int[10] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
        public void Park()
        {
            bool flag = true;
            for(int i= 0;i < parkSlot.Length;i++)
            {
                if (parkSlot[i] == 0)
                {
                    flag = false;
                    parkSlot[i] = 1;
                    Console.WriteLine("Car is parked at the slot {0} successfully", i + 1);
                    break;
                }
            }
                if (flag==false)
                {
                    Console.WriteLine("Already Occupied slot");
                }
            
        }
        public void Unpark()
        {
            int slot;
            Console.WriteLine("Enter the slot number:");
            slot = Convert.ToInt32(Console.ReadLine());
            if (parkSlot[slot] == 0)
            {
                Console.WriteLine("No car in the specified slot");
            }
            else
            {
                parkSlot[slot] = 0;
                Console.WriteLine("Car unparked successfully");
            }
        }
        public void View()
        {
            for(int val=0;val<parkSlot.Length;val++)
            {
                Console.WriteLine("slot {0} is {1}", val+1, parkSlot[val]);
            }
        }
        public static void Main(string[] args)
        {
            int option;
            CarPark obj = new CarPark();
            do
            {
                Console.WriteLine("1.PARKING\n 2.UNPARKING\n 3.VIEW SLOTS\n 4.EXIT \n ENTER YOUR OPTION:");
                option = Convert.ToInt32(Console.ReadLine());
                switch (option) {
                    case 1:
                        obj.Park();
                        break;
                    case 2:
                        obj.Unpark();
                        break;
                    case 3:
                        obj.View();
                        break;
                    case 4:
                        System.Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("!!!!!Enter Valid Option!!!!!");
                        break;
                }
            } while (true) ;

            }
            }

    }

