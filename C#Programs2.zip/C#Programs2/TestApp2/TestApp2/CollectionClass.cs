﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestApp2
{
    class CollectionClass
    {
        public static void Main()
        {
            //list of collection class
            List<String> names= new List<String>();
            names.Add("sonu");
            names.Add("ankit");
            names.Add("jawan");
            names.Add("peter");
            names.Add("irfan");
            names.Remove("peter");
            //  names.Add(123);
          //  names.Add(new Message());
          //names.RemoveAt(0);
          //names.RemoveRange(2,2);
          names.Reverse();
          //names.Sort();
            names.Insert(0, "gokul");
            
            foreach(var name in names)
            {
                Console.WriteLine(name);
            }
            Console.ReadKey();
        }
    }
}
