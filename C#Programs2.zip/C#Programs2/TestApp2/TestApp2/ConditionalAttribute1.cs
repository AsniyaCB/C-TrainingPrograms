﻿#define FOOL
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;

namespace TestApp2
{
    class ConditionalAttribute1
    {
        public static void Main()
        {
            Greet1.GreetDebug();
            Greet1.GreetTrace();
            Console.ReadKey();
        }
    }
    class Greet1
    {
        [Conditional("DEBUG")]
        public static void GreetDebug()
        {
            Console.WriteLine("Greeting from Debug");
        }
        [Conditional("FOOL")]
        public static void GreetTrace()
        {
            Console.WriteLine("Greeting from Trace");
        }
    }
}
