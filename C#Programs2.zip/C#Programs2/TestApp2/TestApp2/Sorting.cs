﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestApp2
{
    class Sorting
    {
        int limit;
        int[] values;
        int[] copyValues;
        static void Main(string[] args)
        {
            Sorting obj = new Sorting();
            obj.ReadData();
            obj.SortArray();
            obj.Display();
            Console.ReadKey();
        }
        public void ReadData()
        {
            
            Console.WriteLine("Enter the limit:");
            limit = Convert.ToInt32(Console.ReadLine());
            values = new int[limit];
            Console.WriteLine("Enter the values:");
            for (int i = 0; i < limit; i++)
            {
                values[i] = Convert.ToInt32(Console.ReadLine());
            }
            copyValues = new int[values.Length];
            for (int i = 0; i < values.Length; i++)
            {
                copyValues[i] = values[i];
            }
        }
        public void SortArray()
        {
            int temp;
            for(int i = 0; i < values.Length; i++)
            {
                for(int j = i + 1; j < values.Length; j++)
                {
                    if (values[i] > values[j])
                    {
                        temp = values[i];
                        values[i] = values[j];
                        values[j] = temp;
                    }
                }
            }
        }
        public void Display()
        {
            Console.WriteLine("UNSORTED ARRAY");
            for (int i = 0; i < limit; i++)
            {
                Console.WriteLine(copyValues[i]);
            }
            Console.WriteLine("SORTED ARRAY");
            for (int i = 0; i < limit; i++)
            {
                Console.WriteLine(values[i] );
            }
        }
    }
}
