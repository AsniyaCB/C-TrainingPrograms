﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestApp2
{
    class ArraySum
    {
        int limit,sum;
        int[] values=new int[5];
       // int[] values = new int[5] { 1 2 3 4 5 };  also possible
        static void Main(string[] args)
        {
            ArraySum obj = new ArraySum();
            obj.ReadData();
            obj.FindSum();
            obj.Display();
            Console.ReadKey();
        }
        public void ReadData()
        {

            Console.WriteLine("Enter the limit:");
            limit = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the values:");
            for(int i = 0; i < limit; i++)
            {
                values[i] = Convert.ToInt32(Console.ReadLine());
            }
        }
        public void FindSum()
        {
            for (int i = 0; i < values.Length; i++)
            {
                sum += values[i];
            }
        }
        public void Display()
        {
            Console.WriteLine("Sum=" + sum);
        }
    }
}
