﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestApp2
{
    class ExceptionHandling
    {
        public static void Main()
        {
            int a, b, c;
            a = 10;
            b = 5;
            c = 0;
            Console.WriteLine("Iam before catch");
            try
            {
                Console.WriteLine("A:"+a);
                Console.WriteLine("B:" + b);
                c = a / (b - 5);
                Console.WriteLine("NO PROBLEMS");           //if no problems within the try block then catch wont be executed
                Console.WriteLine("C:"+c);
            }
            catch(Exception e)
            {
                Console.WriteLine("Iam within catch ERROR:"+e.Message.ToString());
                Console.WriteLine("ANOTHER METHOD\n----------------------");
                c = a / b;
                Console.WriteLine("C:" + c);
            }
            Console.WriteLine("Iam after catch");
            Console.ReadKey();
        }
    }
}
