﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestApp2
{
    class BinarySearch
    {
        int key, limit,low,high, result;
        int[] array;
        int[] copyValues;

        public void Read()
        {
            Console.WriteLine("Enter the limit:");
            limit = Convert.ToInt32(Console.ReadLine());
            array = new int[limit];
            Console.WriteLine("Enter the values:");
            for (int i = 0; i < limit; i++)
            {
                array[i] = Convert.ToInt32(Console.ReadLine());
            }
            Console.WriteLine("Enter the key to be searched:");
            key = Convert.ToInt32(Console.ReadLine());
            
        }
        public void SortArray()
        {
            int temp;
            for (int i = 0; i < array.Length; i++)
            {
                for (int j = i + 1; j < array.Length; j++)
                {
                    if (array[i] > array[j])
                    {
                        temp = array[i];
                        array[i] = array[j];
                        array[j] = temp;
                    }
                }
              
            }
            copyValues = new int[array.Length];
            for (int i = 0; i < array.Length; i++)
            {
                copyValues[i] = array[i];
            }
            
        }
        public void Binary()
        {
            int mid;
            low = 0;
            high = limit- 1;
            Console.WriteLine("SORTED ARRAY");
            for (int i = 0; i < array.Length; i++)
            {
                Console.WriteLine(copyValues[i]);
            }
            while (low <= high)
            {
                mid = (low + high) / 2;


                if (key == array[mid])
                {
                    result = mid + 1;
                    Console.WriteLine("key is found at position:" + result);
                    break;

                }
                else if (key < array[mid])
                {
                    high = mid - 1;
                }
                else if(key>array[mid])
                {
                    low = mid + 1;
                }


            } 
            if(high<low)
            {
                Console.WriteLine("Key is not found in the array");
            }


        }
        public void Display()
        {
            Console.WriteLine("key is found at position" + result);
        }
       
        public static void Main()
        {
            BinarySearch obj = new BinarySearch();
            obj.Read();
            obj.SortArray();
            obj.Binary();
        //    obj.Display();
            Console.ReadKey();
        }
    }
}
