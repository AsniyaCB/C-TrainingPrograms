﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestApp2
{
    class Employee
    {
        public static void Main(string[] args)
        {
            // Employ emp = new Employ(101, "Rahul");
            // Console.WriteLine(emp);

            // Console.WriteLine("Enter the employee details:");
            Employ[] emp1 = new Employ[5];
            for (int i = 0; i < emp1.Length; i++) 
            {
                Console.WriteLine("Enter the employee {0} Details\n------------------------", (i + 1));
                emp1[i] = new Employ();
                emp1[i].Read();
                emp1[i].Calculate();
            }
            Console.WriteLine("Details of the employee are:\n----------------------------");
            for (int i = 0; i < emp1.Length; i++)
            {
                Console.WriteLine(emp1[i]);
            }
            Console.ReadKey();
        }
    }
    class Employ { 
        int ID, basicPay;
        double hre, da, pf;
        string name;
        public Employ() { }
        //public Employ(int ID,string name)
        //{
        //    this.ID = ID;
        //    this.name = name;
        //}
        public void Read()
        {
            Console.WriteLine("employee ID:");
            ID = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("employee name:\n-----------------------");
            name =Console.ReadLine();
            Console.WriteLine("employee basicPay:\n-----------------------");
            basicPay = Convert.ToInt32(Console.ReadLine());
        }
        public void Calculate()
        {
            hre = basicPay * 0.1;
            da = basicPay * 0.5;
            pf = basicPay * 1.2;
        }
        public override string ToString()
        {
            String output = "";
            Console.WriteLine("-----------------------\n");
            output +="ID:"+ID+"\n";
            output += "NAME:" + name + "\n";
            output += "BASIC PAY:" + basicPay + "\n";
            output += "HRE:" + hre + "\n";
            output += "DA:" + da + "\n";
            output += "PF:" + pf + "\n";
            Console.WriteLine("-----------------------\n");
            return output;
        }
    }
}
