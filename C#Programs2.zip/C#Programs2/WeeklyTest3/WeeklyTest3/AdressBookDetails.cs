﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace WeeklyTest4
{
    class AdressBookDetails
    {
        
        public static void Main()
        {
           
            //BinaryFormatter formatter = new BinaryFormatter();

            Books book = new Books();
           // AdressBookDetails abdObj = new AdressBookDetails();
            //formatter.Serialize(stream, abdObj);
            //stream.Close();
            Hashtable addressBook = null;
            var binformatter = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();

            int option;
            do
            {


                Console.WriteLine("****************************");
                Console.WriteLine("1.ADD CONTACTS");
                Console.WriteLine("2.SEARCH PARTICULAR CONTACT ");
                Console.WriteLine("3.DELETE CONTACT ");
                Console.WriteLine("4.VIEW ALL CONTACTS ");
                Console.WriteLine("5.EXIT ");
                Console.WriteLine("****************************");

                Console.WriteLine("Enter the option (1-5) ? ");
                Console.WriteLine("****************************");

                option = Convert.ToInt32(Console.ReadLine());


                switch (option)
                {

                    case 1:
                        FileStream stream = new FileStream("D:\\asniya\\WeeklyTest3\\AddressBook.txt", FileMode.OpenOrCreate);
                        addressBook = new Hashtable();
                        addressBook.Add("001", new Books { FullName = "akash", PhoneNumber = 9447582910, Address = "Italy" });
                        addressBook.Add("002", new Books { FullName = "hari", PhoneNumber = 8382849221, Address = "London" });
                        addressBook.Add("003", new Books { FullName = "hakka", PhoneNumber = 9437327553, Address = "America" });
                        addressBook.Add("004", new Books { FullName = "poppy", PhoneNumber = 9843473424, Address = "Canada" });
                        addressBook.Add("005", new Books { FullName = "dora", PhoneNumber = 7349439494, Address = "India" });
                        ICollection keyf = addressBook.Keys;


                        foreach (string k in keyf) {
                           // stream.WriteByte((byte)addressBook[k]);
                        }
                
                        Console.WriteLine("!!CONTACT ADDED SUCCESSFULLY!!");
                       

                        break;
                    case 2:
                        string keyName;
                        Console.WriteLine("Enter the name of the person to be searched:");
                        keyName = Console.ReadLine();

                        
                        if (addressBook == null)
                        {
                            Console.WriteLine("ADDRESS BOOK EMPTY!!");
                        }
                        else
                        {
                            bool flag = true;
                    ICollection keys = addressBook.Keys;
                    foreach (String k in keys)
                            {
                                book = ((Books)addressBook[k]);
                                if (book.FullName == keyName)
                                {
                                    flag = false;
                                    Console.WriteLine("==========================================================");
                                    Console.WriteLine("ID  |   NAME \t\t|    PHONE NUMBER \t| ADDRESS");
                                    Console.WriteLine("==========================================================");
                                    Console.WriteLine(k+" |   " +book.FullName + "\t\t|     " + book.PhoneNumber + "\t|  " + book.Address);
                                    Console.WriteLine("----------------------------------------------------------");
                                }
                                                                                 
                            }
                            if (flag == true)
                            {
                                Console.WriteLine("NO CONTACT FOUND IN THE GIVEN NAME!!");
                            }

                        }                                          
                    
                        break;
                    case 3:
                        bool flag1 = true;
                        string deleteKey;
                        Console.WriteLine("Enter the key to be deleted:");
                        deleteKey = Console.ReadLine();
                        ICollection key = addressBook.Keys;
                        foreach (String k in key)
                        {
                            book = ((Books)addressBook[k]);
                            if (k ==deleteKey)
                            {
                                flag1 = false;
                                addressBook.Remove(deleteKey);
                                Console.WriteLine("CONTACT DELETED");
                                Console.WriteLine("----------------------------------------------------------");
                                Console.WriteLine(k+"| "+book.FullName + "\t\t| " + book.PhoneNumber + "\t\t| " + book.Address);
                                Console.WriteLine("----------------------------------------------------------");
                                break;
                            }
                        }
                        if (flag1 == true)
                        {
                            Console.WriteLine("NO CONTACT FOUND WITH THE GIVEN KEY!!");

                        }

                        break;
                    case 4:
                        // read the data from the file
                        Hashtable vectorDeserialized = null;
                        using (var fs = File.Open("D:\\asniya\\WeeklyTest3\\AddressBook.txt", FileMode.Open))
                        {
                            vectorDeserialized = (Hashtable)binformatter.Deserialize(fs);
                        }
                        ICollection key1 = addressBook.Keys;
                        Console.WriteLine("==========================================================");

                        Console.WriteLine("ID  |  NAME \t\t|    PHONE NUMBER \t| ADDRESS");
                        Console.WriteLine("==========================================================");
                        foreach (String k in key1)
                        {
                            book = ((Books)addressBook[k]);
                          //  Console.WriteLine("==========================================================");
                           
                            Console.WriteLine(k+" |   " +book.FullName + "\t\t|   " + book.PhoneNumber + "\t\t|  " + book.Address);
                            Console.WriteLine("----------------------------------------------------------");
                        }

                        break;
                    case 5:
                        System.Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("INVALID OPTION!!! ENTER A VALID OPTION");
                        break;
                }
            } while (true);

        }
    }
    [Serializable]
    class Books
    {
        public string FullName { get; set; }
        public double PhoneNumber { get; set; }
        public string Address { get; set; }    

    }
}


