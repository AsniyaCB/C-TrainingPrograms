﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace WeeklyTest4
{
    class GenerateTable
    {
       
        int tableNumber;
        int sleep;
        public GenerateTable(int n, int sleepTime)
        {
            tableNumber = n;
            sleep = sleepTime;
        }
       
        public static void Main()
        {

            GenerateTable objGenerateTable1 = new GenerateTable(5, 10);
            Thread thread1 = new Thread(new ThreadStart(objGenerateTable1.CreateObj));
            GenerateTable objGenerateTable2 = new GenerateTable(10, 100);
            Thread thread2 = new Thread(new ThreadStart(objGenerateTable2.CreateObj));
            GenerateTable objGenerateTable3 = new GenerateTable(15, 1000);
            Thread thread3 = new Thread(new ThreadStart(objGenerateTable3.CreateObj));

            thread1.Start();
            thread2.Start();
            thread3.Start();

            Console.ReadKey();
        }
        public void CreateObj()
        {
            Table t = new Table();
            t.CreateTable(tableNumber);
        }



    }
    class Table
    {
        public void CreateTable(int n)
        {
            lock (this)
            {
                for (int index = 1; index <= 10; index++)
                {

                    Console.WriteLine("{0} * {1} = {2}", n, index, n * index);
                }
            }

        }
    }
}

