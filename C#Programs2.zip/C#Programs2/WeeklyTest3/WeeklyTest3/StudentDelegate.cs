﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WeeklyTest4
{
    public delegate bool PromotableDelegate(Student studentIndex);
    class StudentDelegate
    {
        public static void Main()
        {
            List<Student> studentList = new List<Student>();
            studentList.Add(new Student { ID = 101, Name = "Gopu", Mark = 40, Attendance = 74 });
            studentList.Add(new Student { ID = 102, Name = "Meenu", Mark = 60, Attendance = 75 });
            studentList.Add(new Student { ID = 103, Name = "Malu", Mark = 70, Attendance = 76 });
            studentList.Add(new Student { ID = 104, Name = "Priya", Mark = 30, Attendance = 78 });
            studentList.Add(new Student { ID = 105, Name = "Sharath", Mark = 90, Attendance = 82 });
            studentList.Add(new Student { ID = 106, Name = "Prashanth", Mark = 10, Attendance = 61 });
            Console.WriteLine("LIST OF STUDENTS ELIGIBLE FOR PROMOTION ARE:");
            PromotableDelegate delegateObject = new PromotableDelegate(PromotableStudentMethod);
            Student.GetPromotedList(studentList, delegateObject);
            Console.ReadKey();
        }
        public static bool PromotableStudentMethod(Student studentIndex)
        {
           
                bool eligible = false;
                if (studentIndex.Mark >= 45 && studentIndex.Attendance >= 75)
                {
                    eligible = true;
                }
                return eligible;
            }
    }

    public class Student
    {
        public int ID
        {
            get; set;
        }
        public string Name
        {
            get; set;
        }
        public int Mark
        {
            get; set;
        }
        public int Attendance
        {
            get; set;
        }

        public static void GetPromotedList(List<Student> studentsList, PromotableDelegate delegateObject)     //studentsList -list name
        {
            try
            {
                foreach (Student studentIndex in studentsList)     //studentIndex-index value
                {
                    if (delegateObject(studentIndex))
                    {
                        Console.WriteLine("=======================");
                        Console.WriteLine("STUDENT ID         : " + studentIndex.ID);
                        Console.WriteLine("STUDENT NAME       : " + studentIndex.Name);
                        Console.WriteLine("STUDENT MARK       : " + studentIndex.Mark);
                        Console.WriteLine("STUDENT ATTENDANCE : " + studentIndex.Attendance);

                    }
                }
                Console.WriteLine("=======================");
            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message.ToString());
            }
        }
    }

}