﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DatabaseWeek5.dto;
using System.Data.SqlClient;
using System.Data;
using DatabaseWeek5.bl;


namespace DatabaseWeek5.dao
{
    class Student_DAO
    {
        public static int StudentMarkINSERT(StudentMark studentMARK)
        {
            int output = 0;
            string sql = null;
            SqlConnection con = null;
            SqlCommand cmd = null;

            try
            {
                sql = " insert into student_mark(Id,name,mark1,mark2,mark3,total,result) VALUES (";
                sql = sql + "'" + studentMARK.StudentID + "',";
                sql = sql + "'" + studentMARK.StudentNAME + "',";
                sql = sql + studentMARK.Mark1 + ",";
                sql = sql + studentMARK.Mark2 + ",";
                sql = sql + studentMARK.Mark3 + ",";
                sql = sql + studentMARK.Total + ",";
                sql = sql + "'" + studentMARK.Result + "')";

                ////////////
                con = DBHelper.GetConnection();
                con.Open();
                cmd = new SqlCommand(sql, con);
                output = cmd.ExecuteNonQuery();

            }
            catch (Exception e3)
            {
                Console.Out.WriteLine(" inside catch-ERROR : student_DAO.cs " + e3.Message.ToString());


            }
            finally
            {
                con.Close();
                cmd.Dispose();
            }
            return output;
        }
        public static int StudentMarkUPDATE(StudentMark studentMARK)
        {
            int output = 0;
            string sql = null;
            SqlConnection con = null;
            SqlCommand cmd = null;

            try
            {
                sql = " update student_mark set ";
               
                sql = sql + "name='" + studentMARK.StudentNAME + "',";
                sql = sql + "mark1="+studentMARK.Mark1 + ",";
                sql = sql + "mark2=" + studentMARK.Mark2 + ",";
                sql = sql + "mark3=" + studentMARK.Mark3 + ",";
                sql = sql + "total=" + studentMARK.Total + ",";
                sql = sql + "result='" + studentMARK.Result + "' ";
                sql = sql + "where Id='" + studentMARK.StudentID + "'";

                ////////////
                con = DBHelper.GetConnection();
                con.Open();
                cmd = new SqlCommand(sql, con);
                output = cmd.ExecuteNonQuery();

            }
            catch (Exception e3)
            {
                Console.Out.WriteLine(" inside catch-ERROR : student_DAO.cs " + e3.Message.ToString());


            }
            finally
            {
                con.Close();
                cmd.Dispose();
            }
            return output;
        }
        public static DataSet GetStudentIDs()
        {
            String sql = "";
            SqlConnection con = null;
            SqlDataAdapter adapter = null;

            DataSet dsSTudents = null;

            try
            {
                sql = "select Id from student_mark";
                con = DBHelper.GetConnection();
                con.Open();
                dsSTudents = new DataSet();
                adapter = new SqlDataAdapter(sql, con);
                adapter.Fill(dsSTudents);
            }
            catch (Exception e3)
            {
                Console.Out.WriteLine(" inside catch-ERROR : student_DAO.cs " + e3.Message.ToString());


            }
            finally
            {
                con.Close();

            }
            return dsSTudents;
        }
        public static String GetLastStudentIDs()
        {
            String sql = "";
            SqlConnection con = null;
            SqlDataAdapter adapter = null;

            DataSet dsSTudents = null;

            string LastStudentID = null;
            object[] Data = null;

            try
            {
                sql = "select Id from student_mark order by Id desc";
                con = DBHelper.GetConnection();
                con.Open();
                dsSTudents = new DataSet();
                adapter = new SqlDataAdapter(sql, con);
                adapter.Fill(dsSTudents);

                if (dsSTudents.Tables[0].Rows.Count > 0)
                {
                    Data = dsSTudents.Tables[0].Rows[0].ItemArray;
                    LastStudentID = Data[0].ToString();
                }

            }
            catch (Exception e3)
            {
                Console.Out.WriteLine(" inside catch-ERROR : student_DAO.cs:GetLastStudentIDs() " + e3.Message.ToString());


            }
            finally
            {
                con.Close();

            }
            return LastStudentID;
        }
        public static DataSet GetStudents()
        {
            String sql = "";
            SqlConnection con = null;
            SqlDataAdapter adapter = null;

            DataSet dsSTudents = null;

            try
            {
                sql = "select * from student_mark";
                con = DBHelper.GetConnection();
                con.Open();
                dsSTudents = new DataSet();
                adapter = new SqlDataAdapter(sql, con);
                adapter.Fill(dsSTudents);
            }
            catch (Exception e3)
            {
                Console.Out.WriteLine(" inside catch-ERROR : student_DAO.cs :GetStudents()" + e3.Message.ToString());


            }
            finally
            {
                con.Close();

            }
            return dsSTudents;
        }
        public static DataSet GetStudentLike(string likeName)
        {
            String sql = "";
            SqlConnection con = null;
            SqlDataAdapter adapter = null;

            DataSet dsSTudents = null;

            try
            {
                sql = "select * from student_mark where name like '"+likeName+"%'";
                con = DBHelper.GetConnection();
                con.Open();
                dsSTudents = new DataSet();
                adapter = new SqlDataAdapter(sql, con);
                adapter.Fill(dsSTudents);
            }
            catch (Exception e3)
            {
                Console.Out.WriteLine(" inside catch-ERROR : student_DAO.cs :GetStudentLike()" + e3.Message.ToString());


            }
            finally
            {
                con.Close();

            }
            return dsSTudents;
        }
        public static StudentMark GetStudentByID(string studentId)
        {
            String sql = "";
            SqlConnection con = null;
            SqlDataAdapter adapter = null;

            DataSet dsSTudents = null;
            StudentMark studentMark = null;
            try
            {
                sql = "select * from student_mark where Id='"+studentId+"'";
                con = DBHelper.GetConnection();
                con.Open();
                dsSTudents = new DataSet();
                adapter = new SqlDataAdapter(sql, con);
                adapter.Fill(dsSTudents);

                Object[] Data = null;

                if (dsSTudents.Tables[0].Rows.Count > 0)
                {
                    //to retrieve all data from table for required ID

                    Data = dsSTudents.Tables[0].Rows[0].ItemArray;
                    studentMark = new StudentMark();
                    studentMark.StudentID=Data[0].ToString();
                    studentMark.StudentNAME = Data[1].ToString();
                    studentMark.Mark1 = Convert.ToInt32(Data[2].ToString());
                    studentMark.Mark2 = Convert.ToInt32(Data[3].ToString());
                    studentMark.Mark3 = Convert.ToInt32(Data[4].ToString());
                    studentMark.Total = Convert.ToInt32(Data[5].ToString());
                    studentMark.Result =Data[6].ToString();
                }
            }
            catch (Exception e3)
            {
                Console.Out.WriteLine(" inside catch-ERROR : student_DAO.cs: " + e3.Message.ToString());


            }
            finally
            {
                con.Close();

            }
            return studentMark;
        }
        public static int StudentMarkDELETE(String studentId) { 
            int output = 0;
            string sql = null;
            SqlConnection con = null;
            SqlCommand cmd = null;

            try
            {
                sql = "delete from student_mark where Id='" + studentId + "'";

                ////////////
                con = DBHelper.GetConnection();
                con.Open();
                cmd = new SqlCommand(sql, con);
                output = cmd.ExecuteNonQuery();

            }
            catch (Exception e3)
            {
                Console.Out.WriteLine(" inside catch-ERROR : student_DAO.cs " + e3.Message.ToString());


            }
            finally
            {
                con.Close();
                cmd.Dispose();
            }
            return output;
        }
    }
}
    