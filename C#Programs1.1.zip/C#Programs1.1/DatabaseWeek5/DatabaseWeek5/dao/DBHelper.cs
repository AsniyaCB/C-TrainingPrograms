﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
namespace DatabaseWeek5.dao
{
    class DBHelper
    {
        public static SqlConnection GetConnection()
        {
            SqlConnection con = null;
            string connectionstring = null;
            try
            {
                connectionstring = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=D:\\asniya\\DatabaseWeek5\\DatabaseWeek5\\StudentDB.mdf;Integrated Security=True";
                con = new SqlConnection(connectionstring); //connection with db
            }
            catch (Exception e3)
            {
                Console.Out.WriteLine(" inside catch-ERROR : DB_helper.cs " + e3.Message.ToString());
            }
            return con;
        }
    }
}
