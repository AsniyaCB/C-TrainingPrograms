﻿using DatabaseWeek5.bl;
using DatabaseWeek5.dto;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace DatabaseWeek5.student
{
    public partial class StudentMaster : Form
    {
        int countMark1 = 0;bool flagMark1=false;
        int countMark2 = 0; bool flagMark2 = false;
        int countMark3 = 0; bool flagMark3 = false;

        public StudentMaster()
        {
            InitializeComponent();
        }

        private void StudentMaster_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'studentDBDataSet.student_mark' table. You can move, or remove it, as needed.
            this.student_markTableAdapter.Fill(this.studentDBDataSet.student_mark);
            LoadSTudentIDs();
            LoadSTudents();

        }
        private void LoadSTudentIDs()
        {
            DataSet dsStudentID = null;
            try
            {
                dsStudentID = Student_Mark_BL.GetStudentIDs();
                if (dsStudentID != null)
                {
                    cmbID.DataSource = dsStudentID.Tables[0];


                    cmbID.ValueMember = "Id";
                    cmbID.DisplayMember = "Id";

                }
                else
                {
                    lblMessage.Text = "No students avialable";
                }
            }
            catch (Exception ex)
            {
                lblMessage.Text = ex.Message.ToString();

            }
        }
        private void LoadSTudents()
        {
            DataSet dsStudents = null;
            try
            {
                dsStudents = Student_Mark_BL.GetStudents();
                if (dsStudents != null)
                {
                    dgv.DataSource = dsStudents.Tables[0];

                }
                else
                {
                    lblMessage.Text = "No students avialable";
                }
            }
            catch (Exception ex)
            {
                lblMessage.Text = ex.Message.ToString();

            }
        }
        private void lblTitle_Click(object sender, EventArgs e)
        {

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
           

            int output = 0;
           

            StudentMark studentMARK = null;

            try
            {
                if (btnSave.Text == "NEW")
                {
                    btnSave.Text = "SAVE";
                    ClearControl();
                    txtID.Text = Student_Mark_BL.GetNewStudentIDs();

                    btnDelete.Enabled = false;
                    btnUpdate.Enabled = false;

                    btnClear.Text = "BACK";
                }
                else
                {
                    studentMARK = new StudentMark();
                    studentMARK.StudentID = txtID.Text;
                    studentMARK.StudentNAME = txtname.Text;
                    studentMARK.Mark1 = Convert.ToInt32(txtmark1.Text);
                    studentMARK.Mark2 = Convert.ToInt32(txtmark2.Text);
                    studentMARK.Mark3 = Convert.ToInt32(txtmark3.Text);
                    output = Student_Mark_BL.StudentMarkINSERT(studentMARK);

                    if (studentMARK.Mark1 < 0 || studentMARK.Mark1 > 100)
                    {
                        lblMessage.Text = "Enter a mark between 0-100";
                        txtmark1.Focus();
                    }
                    else
                    {

                        if (output > 0)

                        {
                            lblMessage.Text = "success";
                            LoadSTudents();
                            LoadSTudentIDs();
                            btnSave.Text = "NEW";
                            btnDelete.Enabled = true;
                            btnUpdate.Enabled = true;

                            btnClear.Text = "CLEAR";
                        }
                        else
                        {
                            lblMessage.Text = "fail";
                        }

                    }
                }
            }
            catch (Exception e4)
            {
                lblMessage.Text = e4.Message.ToString();
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void cmbID_SelectedIndexChanged(object sender, EventArgs e)
        {
            //MessageBox.Show(cmbID.Text);
            StudentMark studentMark = null;
            try
            {
                studentMark=Student_Mark_BL.GetStudentByID(cmbID.Text);

                if (studentMark != null)
                {
                    txtID.Text = studentMark.StudentID;
                    txtname.Text = studentMark.StudentNAME;
                    txtmark1.Text = studentMark.Mark1.ToString();
                    txtmark2.Text = studentMark.Mark2.ToString();
                    txtmark3.Text = studentMark.Mark3.ToString();
                }
            }
            
            catch(Exception ex)
            {
                lblMessage.Text = ex.Message.ToString();
                
            }
           
        }
        private void ClearControl()
        {
            txtmark1.Text = "";
            txtmark2.Text = "";
            txtmark3.Text = "";
            txtID.Text = "";
            txtname.Text = "";
            lblMessage.Text = "";
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            int output = 0;
            try
            {
                if (MessageBox.Show("Do you want to delete ?", "Confirm ", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    output = Student_Mark_BL.StudentMarkDELETE(cmbID.Text);
                    if (output > 0)
                    {
                        LoadSTudentIDs();
                        LoadSTudents();
                        lblMessage.Text = "student details deleted successfully";
                    }
                    else
                    {
                        lblMessage.Text = "Please try again later";
                    }
                }
                else
                {
                    lblMessage.Text = "Item not deleted";
                }
            }
            catch (Exception ex)
            {
                lblMessage.Text = ex.Message.ToString();
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            StudentMark studentMARK = null;
            int output = 0;
            try
            {
                studentMARK = new StudentMark();
                studentMARK.StudentID = txtID.Text;
                studentMARK.StudentNAME = txtname.Text;
                studentMARK.Mark1 = Convert.ToInt32(txtmark1.Text);
                studentMARK.Mark2 = Convert.ToInt32(txtmark2.Text);
                studentMARK.Mark3 = Convert.ToInt32(txtmark3.Text);
                

                if (studentMARK.Mark1 < 0 || studentMARK.Mark1 > 100)
                {
                    lblMessage.Text = "Enter a mark between 0-100";
                }
                else
                {
                    output = Student_Mark_BL.StudentMarkUPDATE(studentMARK);

                    if (output > 0)

                    {
                        LoadSTudentIDs();
                        LoadSTudents();
                        lblMessage.Text = "student details updated successfully";

                    }
                    else
                    {
                        lblMessage.Text = "Please try again later";
                    }

                }
            }
            catch (Exception e4)
            {
                lblMessage.Text = e4.Message.ToString();
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void txtname_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblName_Click(object sender, EventArgs e)
        {

        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            if (btnClear.Text == "BACK")
            {
                btnSave.Text = "NEW";
                btnDelete.Enabled = true;
                btnUpdate.Enabled = true;

                btnClear.Text = "CLEAR";
            }
            
            else{
                ClearControl();
            }
        }

        private void txtNameSearch_TextChanged(object sender, EventArgs e)
        {
           
                DataSet dsStudents = null;
                try
                {
                    dsStudents = Student_Mark_BL.GetStudentLike(txtNameSearch.Text);
                    if (dsStudents != null)
                    {
                        dgv.DataSource = dsStudents.Tables[0];

                    }
                    else
                    {
                        lblMessage.Text = "No students avialable";
                    }
                }
                catch (Exception ex)
                {
                    lblMessage.Text = ex.Message.ToString();

                }
            }

        private void txtmark1_KeyDown(object sender, KeyEventArgs e)
        {
            flagMark1 = false;
            if(!txtmark1.Text.Contains(".") && countMark1 > 0)
            {
                countMark1--;
            }
            if ((e.KeyCode >= Keys.D0 && e.KeyCode <= Keys.D9) ||
                (e.KeyCode >= Keys.NumPad0 && e.KeyCode <= Keys.NumPad9) || 
                ((e.KeyCode >= Keys.Decimal && e.KeyCode <= Keys.OemPeriod) && countMark1 < 1) ||
                e.KeyCode <= Keys.Back)
            {
                flagMark1 = true;
                if (e.KeyCode == Keys.Decimal || e.KeyCode == Keys.OemPeriod)
                    countMark1++;
            }
        }

        private void txtmark1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!flagMark1)
            {
                e.Handled = true;
            }
        }

        private void txtmark2_KeyDown(object sender, KeyEventArgs e)
        {
            flagMark2 = false;
            if (!txtmark2.Text.Contains(".") && countMark2 > 0)
            {
                countMark2--;
            }
            if ((e.KeyCode >= Keys.D0 && e.KeyCode <= Keys.D9) ||
                (e.KeyCode >= Keys.NumPad0 && e.KeyCode <= Keys.NumPad9) ||
                ((e.KeyCode >= Keys.Decimal && e.KeyCode <= Keys.OemPeriod) && countMark2 < 1) ||
                e.KeyCode <= Keys.Back)
            {
                flagMark2 = true;
                if (e.KeyCode == Keys.Decimal || e.KeyCode == Keys.OemPeriod)
                    countMark2++;
            }
        }

        private void txtmark2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!flagMark2)
            {
                e.Handled = true;
            }
        }

        private void txtmark3_KeyDown(object sender, KeyEventArgs e)
        {
            flagMark3 = false;
            if (!txtmark3.Text.Contains(".") && countMark3 > 0)
            {
                countMark3--;
            }
            if ((e.KeyCode >= Keys.D0 && e.KeyCode <= Keys.D9) ||
                (e.KeyCode >= Keys.NumPad0 && e.KeyCode <= Keys.NumPad9) ||
                ((e.KeyCode >= Keys.Decimal && e.KeyCode <= Keys.OemPeriod) && countMark3 < 1) ||
                e.KeyCode <= Keys.Back)
            {
                flagMark3 = true;
                if (e.KeyCode == Keys.Decimal || e.KeyCode == Keys.OemPeriod)
                    countMark3++;
            }
        }

        private void txtmark3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!flagMark3)
            {
                e.Handled = true;
            }
        }

        private void dgv_SelectionChanged(object sender, EventArgs e)
        {
            String studentId, student_name;
            int mark1, mark2, mark3;
            if (dgv.SelectedCells.Count > 0)
            {
                int selectedrowindex = dgv.SelectedCells[0].RowIndex;
                DataGridViewRow selectedRow = dgv.Rows[selectedrowindex];

                studentId = Convert.ToString(selectedRow.Cells["Id"].Value);
                student_name = Convert.ToString(selectedRow.Cells["name"].Value);
                mark1 = Convert.ToInt32(selectedRow.Cells["mark1"].Value);
                mark2 = Convert.ToInt32(selectedRow.Cells["mark2"].Value);
                mark3 = Convert.ToInt32(selectedRow.Cells["mark3"].Value);

                txtID.Text = studentId;
                txtname.Text = student_name;
                txtmark1.Text = mark1.ToString();
                txtmark2.Text = mark2.ToString();
                txtmark3.Text = mark3.ToString();


            }
        }

        private void dgv_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
    }
///SAVE
//SqlConnection connection = null;
//SqlCommand command = null;
//String ConnectionString = null;
//String sql = null;
//String student_id, student_name, result;
//int mark1, mark2, mark3, total;
//try
//{
//    ConnectionString = "Data Source = (LocalDB)\\MSSQLLocalDB; AttachDbFilename = C:\\Users\\1028289\\source\\repos\\DataBase\\DataBase\\data.mdf; Integrated Security = True";
//    connection = new SqlConnection(ConnectionString); //connection with db
//    student_id = txtid.Text;
//    student_name = txtname.Text;
//    mark1 = Convert.ToInt32(txtmark1.Text);
//    mark2 = Convert.ToInt32(txtmark2.Text);
//    mark3 = Convert.ToInt32(txtmark3.Text);
//    total = mark1 + mark2 + mark3;

//    if (mark1 < 50 || mark2<50)
//    {
//        result = "Fail";
//    }
//    else
//    {
//        result = "Pass";
//    }
//    sql = " insert into student_mark(id,student_name,mark1,mark2,mark3,total,result) VALUES (";
//    sql = sql + "'" + student_id + "',";
//    sql = sql + "'" + student_name + "',";
//    sql = sql + mark1 + ",";
//    sql = sql + mark2 + ",";
//    sql = sql + mark3 + ",";
//    sql = sql + total + ",";
//    sql = sql +"'"+ result + "')";



//    connection.Open();//db open

//    command = new SqlCommand(sql, connection);
//    output = command.ExecuteNonQuery();

//    if (output > 0)

//    {
//        labelmessage.Text = "success";

//    }
//    else
//    {
//        labelmessage.Text = "fail";
//    }
//}
//catch(Exception e1)
//{
//    labelmessage.Text = e1.Message.ToString();
//}
//finally
//{
//    connection.Close();

//    command.Dispose();


//}
