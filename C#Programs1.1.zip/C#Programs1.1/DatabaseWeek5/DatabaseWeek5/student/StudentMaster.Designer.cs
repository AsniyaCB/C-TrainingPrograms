﻿namespace DatabaseWeek5.student
{
    partial class StudentMaster
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblTitle = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.lblMessage = new System.Windows.Forms.Label();
            this.cmbID = new System.Windows.Forms.ComboBox();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.txtmark3 = new System.Windows.Forms.TextBox();
            this.txtmark2 = new System.Windows.Forms.TextBox();
            this.txtname = new System.Windows.Forms.TextBox();
            this.txtmark1 = new System.Windows.Forms.TextBox();
            this.txtID = new System.Windows.Forms.TextBox();
            this.lblMark3 = new System.Windows.Forms.Label();
            this.lblMark2 = new System.Windows.Forms.Label();
            this.lblMark1 = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.lblID = new System.Windows.Forms.Label();
            this.labelMessage = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.idDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mark1DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mark2DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mark3DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.totalDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.resultDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.studentmarkBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.studentDBDataSet = new DatabaseWeek5.StudentDBDataSet();
            this.student_markTableAdapter = new DatabaseWeek5.StudentDBDataSetTableAdapters.student_markTableAdapter();
            this.label1 = new System.Windows.Forms.Label();
            this.dgv = new System.Windows.Forms.DataGridView();
            this.lblNameSearch = new System.Windows.Forms.Label();
            this.txtNameSearch = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentmarkBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentDBDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).BeginInit();
            this.SuspendLayout();
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.BackColor = System.Drawing.Color.Transparent;
            this.lblTitle.Font = new System.Drawing.Font("Baskerville Old Face", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.lblTitle.Location = new System.Drawing.Point(64, 28);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(378, 43);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "STUDENT DETAILS";
            this.lblTitle.Click += new System.EventHandler(this.lblTitle_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.Controls.Add(this.btnUpdate);
            this.panel1.Controls.Add(this.btnDelete);
            this.panel1.Controls.Add(this.lblMessage);
            this.panel1.Controls.Add(this.cmbID);
            this.panel1.Controls.Add(this.btnClear);
            this.panel1.Controls.Add(this.btnSave);
            this.panel1.Controls.Add(this.txtmark3);
            this.panel1.Controls.Add(this.txtmark2);
            this.panel1.Controls.Add(this.txtname);
            this.panel1.Controls.Add(this.txtmark1);
            this.panel1.Controls.Add(this.txtID);
            this.panel1.Controls.Add(this.lblMark3);
            this.panel1.Controls.Add(this.lblMark2);
            this.panel1.Controls.Add(this.lblMark1);
            this.panel1.Controls.Add(this.lblName);
            this.panel1.Controls.Add(this.lblID);
            this.panel1.ForeColor = System.Drawing.Color.Black;
            this.panel1.Location = new System.Drawing.Point(12, 89);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(479, 453);
            this.panel1.TabIndex = 1;
            // 
            // btnUpdate
            // 
            this.btnUpdate.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btnUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdate.ForeColor = System.Drawing.Color.DarkBlue;
            this.btnUpdate.Location = new System.Drawing.Point(346, 370);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(75, 48);
            this.btnUpdate.TabIndex = 26;
            this.btnUpdate.Text = "UPDATE";
            this.btnUpdate.UseVisualStyleBackColor = false;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btnDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.ForeColor = System.Drawing.Color.DarkBlue;
            this.btnDelete.Location = new System.Drawing.Point(250, 370);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(75, 48);
            this.btnDelete.TabIndex = 25;
            this.btnDelete.Text = "DELETE";
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // lblMessage
            // 
            this.lblMessage.AutoSize = true;
            this.lblMessage.BackColor = System.Drawing.Color.Transparent;
            this.lblMessage.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMessage.ForeColor = System.Drawing.Color.Red;
            this.lblMessage.Location = new System.Drawing.Point(57, 13);
            this.lblMessage.Name = "lblMessage";
            this.lblMessage.Size = new System.Drawing.Size(0, 16);
            this.lblMessage.TabIndex = 24;
            // 
            // cmbID
            // 
            this.cmbID.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.cmbID.ForeColor = System.Drawing.Color.DarkBlue;
            this.cmbID.FormattingEnabled = true;
            this.cmbID.Location = new System.Drawing.Point(365, 19);
            this.cmbID.Name = "cmbID";
            this.cmbID.Size = new System.Drawing.Size(105, 21);
            this.cmbID.TabIndex = 23;
            this.cmbID.SelectedIndexChanged += new System.EventHandler(this.cmbID_SelectedIndexChanged);
            // 
            // btnClear
            // 
            this.btnClear.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btnClear.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear.ForeColor = System.Drawing.Color.DarkBlue;
            this.btnClear.Location = new System.Drawing.Point(148, 370);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(75, 48);
            this.btnClear.TabIndex = 22;
            this.btnClear.Text = "CLEAR";
            this.btnClear.UseVisualStyleBackColor = false;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btnSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.ForeColor = System.Drawing.Color.DarkBlue;
            this.btnSave.Location = new System.Drawing.Point(42, 370);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 48);
            this.btnSave.TabIndex = 21;
            this.btnSave.Text = "NEW";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // txtmark3
            // 
            this.txtmark3.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.txtmark3.ForeColor = System.Drawing.Color.DarkBlue;
            this.txtmark3.Location = new System.Drawing.Point(176, 288);
            this.txtmark3.Name = "txtmark3";
            this.txtmark3.Size = new System.Drawing.Size(294, 20);
            this.txtmark3.TabIndex = 20;
            this.txtmark3.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtmark3_KeyDown);
            this.txtmark3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtmark3_KeyPress);
            // 
            // txtmark2
            // 
            this.txtmark2.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.txtmark2.ForeColor = System.Drawing.Color.DarkBlue;
            this.txtmark2.Location = new System.Drawing.Point(176, 241);
            this.txtmark2.Name = "txtmark2";
            this.txtmark2.Size = new System.Drawing.Size(294, 20);
            this.txtmark2.TabIndex = 19;
            this.txtmark2.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtmark2_KeyDown);
            this.txtmark2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtmark2_KeyPress);
            // 
            // txtname
            // 
            this.txtname.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.txtname.ForeColor = System.Drawing.Color.DarkBlue;
            this.txtname.Location = new System.Drawing.Point(176, 130);
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(294, 20);
            this.txtname.TabIndex = 18;
            this.txtname.TextChanged += new System.EventHandler(this.txtname_TextChanged);
            // 
            // txtmark1
            // 
            this.txtmark1.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.txtmark1.ForeColor = System.Drawing.Color.DarkBlue;
            this.txtmark1.Location = new System.Drawing.Point(176, 183);
            this.txtmark1.Name = "txtmark1";
            this.txtmark1.Size = new System.Drawing.Size(294, 20);
            this.txtmark1.TabIndex = 17;
            this.txtmark1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtmark1_KeyDown);
            this.txtmark1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtmark1_KeyPress);
            // 
            // txtID
            // 
            this.txtID.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.txtID.ForeColor = System.Drawing.Color.DarkBlue;
            this.txtID.Location = new System.Drawing.Point(176, 77);
            this.txtID.Name = "txtID";
            this.txtID.ReadOnly = true;
            this.txtID.Size = new System.Drawing.Size(294, 20);
            this.txtID.TabIndex = 16;
            // 
            // lblMark3
            // 
            this.lblMark3.AutoSize = true;
            this.lblMark3.Font = new System.Drawing.Font("Baskerville Old Face", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMark3.ForeColor = System.Drawing.SystemColors.InfoText;
            this.lblMark3.Location = new System.Drawing.Point(27, 289);
            this.lblMark3.Name = "lblMark3";
            this.lblMark3.Size = new System.Drawing.Size(61, 18);
            this.lblMark3.TabIndex = 15;
            this.lblMark3.Text = "Mark 3";
            // 
            // lblMark2
            // 
            this.lblMark2.AutoSize = true;
            this.lblMark2.Font = new System.Drawing.Font("Baskerville Old Face", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMark2.ForeColor = System.Drawing.SystemColors.InfoText;
            this.lblMark2.Location = new System.Drawing.Point(27, 245);
            this.lblMark2.Name = "lblMark2";
            this.lblMark2.Size = new System.Drawing.Size(61, 18);
            this.lblMark2.TabIndex = 14;
            this.lblMark2.Text = "Mark 2";
            // 
            // lblMark1
            // 
            this.lblMark1.AutoSize = true;
            this.lblMark1.Font = new System.Drawing.Font("Baskerville Old Face", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMark1.ForeColor = System.Drawing.SystemColors.InfoText;
            this.lblMark1.Location = new System.Drawing.Point(27, 187);
            this.lblMark1.Name = "lblMark1";
            this.lblMark1.Size = new System.Drawing.Size(61, 18);
            this.lblMark1.TabIndex = 13;
            this.lblMark1.Text = "Mark 1";
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Font = new System.Drawing.Font("Baskerville Old Face", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblName.ForeColor = System.Drawing.SystemColors.InfoText;
            this.lblName.Location = new System.Drawing.Point(27, 130);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(110, 18);
            this.lblName.TabIndex = 12;
            this.lblName.Text = "Student Name";
            this.lblName.Click += new System.EventHandler(this.lblName_Click);
            // 
            // lblID
            // 
            this.lblID.AutoSize = true;
            this.lblID.Font = new System.Drawing.Font("Baskerville Old Face", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblID.ForeColor = System.Drawing.SystemColors.InfoText;
            this.lblID.Location = new System.Drawing.Point(27, 77);
            this.lblID.Name = "lblID";
            this.lblID.Size = new System.Drawing.Size(87, 18);
            this.lblID.TabIndex = 11;
            this.lblID.Text = "Student ID";
            // 
            // labelMessage
            // 
            this.labelMessage.AutoSize = true;
            this.labelMessage.Location = new System.Drawing.Point(287, 71);
            this.labelMessage.Name = "labelMessage";
            this.labelMessage.Size = new System.Drawing.Size(0, 13);
            this.labelMessage.TabIndex = 2;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ScrollBar;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn,
            this.nameDataGridViewTextBoxColumn,
            this.mark1DataGridViewTextBoxColumn,
            this.mark2DataGridViewTextBoxColumn,
            this.mark3DataGridViewTextBoxColumn,
            this.totalDataGridViewTextBoxColumn,
            this.resultDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.studentmarkBindingSource;
            this.dataGridView1.GridColor = System.Drawing.SystemColors.ControlText;
            this.dataGridView1.Location = new System.Drawing.Point(497, 139);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(699, 175);
            this.dataGridView1.TabIndex = 3;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // idDataGridViewTextBoxColumn
            // 
            this.idDataGridViewTextBoxColumn.DataPropertyName = "Id";
            this.idDataGridViewTextBoxColumn.HeaderText = "Id";
            this.idDataGridViewTextBoxColumn.Name = "idDataGridViewTextBoxColumn";
            // 
            // nameDataGridViewTextBoxColumn
            // 
            this.nameDataGridViewTextBoxColumn.DataPropertyName = "name";
            this.nameDataGridViewTextBoxColumn.HeaderText = "name";
            this.nameDataGridViewTextBoxColumn.Name = "nameDataGridViewTextBoxColumn";
            // 
            // mark1DataGridViewTextBoxColumn
            // 
            this.mark1DataGridViewTextBoxColumn.DataPropertyName = "mark1";
            this.mark1DataGridViewTextBoxColumn.HeaderText = "mark1";
            this.mark1DataGridViewTextBoxColumn.Name = "mark1DataGridViewTextBoxColumn";
            // 
            // mark2DataGridViewTextBoxColumn
            // 
            this.mark2DataGridViewTextBoxColumn.DataPropertyName = "mark2";
            this.mark2DataGridViewTextBoxColumn.HeaderText = "mark2";
            this.mark2DataGridViewTextBoxColumn.Name = "mark2DataGridViewTextBoxColumn";
            // 
            // mark3DataGridViewTextBoxColumn
            // 
            this.mark3DataGridViewTextBoxColumn.DataPropertyName = "mark3";
            this.mark3DataGridViewTextBoxColumn.HeaderText = "mark3";
            this.mark3DataGridViewTextBoxColumn.Name = "mark3DataGridViewTextBoxColumn";
            // 
            // totalDataGridViewTextBoxColumn
            // 
            this.totalDataGridViewTextBoxColumn.DataPropertyName = "total";
            this.totalDataGridViewTextBoxColumn.HeaderText = "total";
            this.totalDataGridViewTextBoxColumn.Name = "totalDataGridViewTextBoxColumn";
            // 
            // resultDataGridViewTextBoxColumn
            // 
            this.resultDataGridViewTextBoxColumn.DataPropertyName = "result";
            this.resultDataGridViewTextBoxColumn.HeaderText = "result";
            this.resultDataGridViewTextBoxColumn.Name = "resultDataGridViewTextBoxColumn";
            // 
            // studentmarkBindingSource
            // 
            this.studentmarkBindingSource.DataMember = "student_mark";
            this.studentmarkBindingSource.DataSource = this.studentDBDataSet;
            // 
            // studentDBDataSet
            // 
            this.studentDBDataSet.DataSetName = "StudentDBDataSet";
            this.studentDBDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // student_markTableAdapter
            // 
            this.student_markTableAdapter.ClearBeforeFill = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Baskerville Old Face", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.label1.Location = new System.Drawing.Point(697, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(340, 43);
            this.label1.TabIndex = 4;
            this.label1.Text = "STUDENT TABLE";
            // 
            // dgv
            // 
            this.dgv.BackgroundColor = System.Drawing.SystemColors.ScrollBar;
            this.dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv.Location = new System.Drawing.Point(497, 321);
            this.dgv.Name = "dgv";
            this.dgv.Size = new System.Drawing.Size(699, 221);
            this.dgv.TabIndex = 5;
            this.dgv.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_CellContentClick);
            this.dgv.SelectionChanged += new System.EventHandler(this.dgv_SelectionChanged);
            // 
            // lblNameSearch
            // 
            this.lblNameSearch.AutoSize = true;
            this.lblNameSearch.Font = new System.Drawing.Font("Baskerville Old Face", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNameSearch.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.lblNameSearch.Location = new System.Drawing.Point(546, 99);
            this.lblNameSearch.Name = "lblNameSearch";
            this.lblNameSearch.Size = new System.Drawing.Size(89, 14);
            this.lblNameSearch.TabIndex = 27;
            this.lblNameSearch.Text = "Name Search";
            // 
            // txtNameSearch
            // 
            this.txtNameSearch.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.txtNameSearch.ForeColor = System.Drawing.Color.DarkBlue;
            this.txtNameSearch.Location = new System.Drawing.Point(730, 98);
            this.txtNameSearch.Name = "txtNameSearch";
            this.txtNameSearch.Size = new System.Drawing.Size(294, 20);
            this.txtNameSearch.TabIndex = 27;
            this.txtNameSearch.TextChanged += new System.EventHandler(this.txtNameSearch_TextChanged);
            // 
            // StudentMaster
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gainsboro;
            this.BackgroundImage = global::DatabaseWeek5.Properties.Resources.yellow;
            this.ClientSize = new System.Drawing.Size(1208, 615);
            this.Controls.Add(this.txtNameSearch);
            this.Controls.Add(this.lblNameSearch);
            this.Controls.Add(this.dgv);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.labelMessage);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.lblTitle);
            this.ForeColor = System.Drawing.SystemColors.WindowText;
            this.Name = "StudentMaster";
            this.Text = " ";
            this.Load += new System.EventHandler(this.StudentMaster_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentmarkBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentDBDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox txtmark3;
        private System.Windows.Forms.TextBox txtmark2;
        private System.Windows.Forms.TextBox txtname;
        private System.Windows.Forms.TextBox txtmark1;
        private System.Windows.Forms.TextBox txtID;
        private System.Windows.Forms.Label lblMark3;
        private System.Windows.Forms.Label lblMark2;
        private System.Windows.Forms.Label lblMark1;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label lblID;
        private System.Windows.Forms.ComboBox cmbID;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Label labelMessage;
        private System.Windows.Forms.DataGridView dataGridView1;
        private StudentDBDataSet studentDBDataSet;
        private System.Windows.Forms.BindingSource studentmarkBindingSource;
        private StudentDBDataSetTableAdapters.student_markTableAdapter student_markTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn mark1DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn mark2DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn mark3DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn totalDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn resultDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label lblMessage;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.DataGridView dgv;
        private System.Windows.Forms.Label lblNameSearch;
        private System.Windows.Forms.TextBox txtNameSearch;
    }
}