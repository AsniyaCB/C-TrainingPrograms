﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data.SqlClient;
using System.Data;
using DatabaseWeek5.dto;
using DatabaseWeek5.dao;
using DatabaseWeek5.helper;

namespace DatabaseWeek5.bl
{
    class Student_Mark_BL
    {
        public static int StudentMarkINSERT(StudentMark studentMARK)
        {
            int output = 0;



            try
            {
                studentMARK.Total = studentMARK.Mark1 + studentMARK.Mark2 + studentMARK.Mark3;

                if (studentMARK.Mark1 < 50 || studentMARK.Mark2 < 50)
                {
                    studentMARK.Result = "Fail";
                }
                else
                {
                    studentMARK.Result = "Pass";
                }

                output = Student_DAO.StudentMarkINSERT(studentMARK);

            }
            catch (Exception e3)
            {
                Console.Out.WriteLine(" inside catch-ERROR : student_mark_BL.cs " + e3.Message.ToString());


            }

            return output;
        }
        public static DataSet GetStudentLike(string likeName)
        {
            DataSet dsSTudents = null;

            try
            {
                dsSTudents = Student_DAO.GetStudentLike(likeName);
            }
            catch (Exception e3)
            {
                Console.Out.WriteLine(" inside catch-ERROR : Student_Mark_BL.cs :GetStudentLike()" + e3.Message.ToString());


            }
           
            return dsSTudents;
        }
        public static DataSet GetStudentIDs()
        {
            //String sql = "";

            DataSet dsSTudents = null;

            try
            {

                dsSTudents = Student_DAO.GetStudentIDs();


            }
            catch (Exception e3)
            {
                Console.Out.WriteLine(" inside catch-ERROR : student_mark_BL.cs " + e3.Message.ToString());


            }

            return dsSTudents;
        }
        public static DataSet GetStudents()
        {
            //String sql = "";

            DataSet dsSTudents = null;

            try
            {

                dsSTudents = Student_DAO.GetStudents();


            }
            catch (Exception e3)
            {
                Console.Out.WriteLine(" inside catch-ERROR : student_mark_BL.cs: GetStudents" + e3.Message.ToString());


            }

            return dsSTudents;
        }
        public static int StudentMarkUPDATE(StudentMark studentMARK)
        {
            int output = 0;
           

            try
            {
                studentMARK.Total = studentMARK.Mark1 + studentMARK.Mark2 + studentMARK.Mark3;

                if (studentMARK.Mark1 < 50 || studentMARK.Mark2 < 50)
                {
                    studentMARK.Result = "Fail";
                }
                else
                {
                    studentMARK.Result = "Pass";
                }

                
                output = Student_DAO.StudentMarkUPDATE(studentMARK);

            }
            catch (Exception e3)
            {
                Console.Out.WriteLine(" inside catch-ERROR : student_Mark_BL.cs:StudentMarkUpdate " + e3.Message.ToString());


            }
            
            return output;
            
        }


        public static String GetNewStudentIDs()
        {
           
            string LastStudentID = null;
            string newStudentID = null;

            try
            {
                    LastStudentID = Student_DAO.GetLastStudentIDs();

                if (LastStudentID != null)
                {
                    newStudentID=UtilityHelper.GenerateID(LastStudentID);
                }
                else
                {
                    newStudentID = "STU101";
                }
            }

            
            catch (Exception e3)
            {
                Console.Out.WriteLine(" inside catch-ERROR : Student_Mark_BL.cs:GetLastStudentIDs() " + e3.Message.ToString());


            }
       
            return newStudentID;
        }


        public static StudentMark GetStudentByID(string studentId)
        {
           
            StudentMark studentMark = null;
            try
            {
                studentMark = Student_DAO.GetStudentByID(studentId);
            }
            catch (Exception e3)
            {
                Console.Out.WriteLine(" ERROR : student_Mark_Bl.cs:GetStudentById() " + e3.Message.ToString());


            }
         
            return studentMark;
        }
        public static int StudentMarkDELETE(string studentId)
        {
            int output = 0;
           
            try
            {
                output = Student_DAO.StudentMarkDELETE(studentId);

            }
            catch (Exception e3)
            {
                Console.Out.WriteLine(" ERROR :Student_DAO.cs:StudentMarkDELETE: " + e3.Message.ToString());


            }
         
            return output;
        }
    }
}
    
