﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class DistanceOpOver
    {
        int feet, inches;
        public DistanceOpOver()
        {

        }
        public DistanceOpOver(int feet,int inches)
        {
            this.feet = feet;
            this.inches = inches;
        }
        public void DisplayDistance()
        {
            Console.WriteLine("feet:{0} Inches:{1}", feet, inches);
        }
        public void ReadDistance()
        {
            Console.WriteLine("Enter the value of feet:");
            feet = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter the value of inches:");
            inches = Convert.ToInt32(Console.ReadLine());
        }
        public void AddDistance(DistanceOpOver objDistance1, DistanceOpOver objDistance2)
        {
            feet = objDistance1.feet + objDistance2.feet;
            inches = objDistance1.inches + objDistance2.inches;
            if (inches >= 12)
            {
                feet++;
                inches %= 12;
            }
        }
        public static void Main()
        {
            DistanceOpOver distance1 = new DistanceOpOver();
            DistanceOpOver distance2 = new DistanceOpOver();
            DistanceOpOver distance3 = new DistanceOpOver();
            DistanceOpOver distance4;
            DistanceOpOver distance5;
            Console.WriteLine("Enter the value of Distance1:");
            Console.WriteLine("********************");
            distance1.ReadDistance();
            Console.WriteLine("Enter the value of Distance2:");
            Console.WriteLine("********************");
            distance2.ReadDistance();
            distance3.AddDistance(distance1, distance2);
            Console.WriteLine(" Distance1:");
            Console.WriteLine("***********");
            distance1.DisplayDistance();
            Console.WriteLine(" Distance2:");
            Console.WriteLine("***********");
            distance2.DisplayDistance();
            Console.WriteLine(" Distance3:");
            Console.WriteLine("***********");
            distance3.DisplayDistance();
            distance4 = distance1.AddDistance(distance2);
            Console.WriteLine(" Distance4:");
            Console.WriteLine("***********");
            distance4.DisplayDistance();
            distance5 = distance1 + distance2;
            Console.WriteLine(" Distance5:");
            Console.WriteLine("***********");
            distance5.DisplayDistance();
            DistanceOpOver distance6;

               
            distance6 = distance1 - distance2;
            Console.WriteLine(" DIFFERENCE");
            Console.WriteLine("***********");
            
          
            distance6.DisplayDistance();
            Console.ReadKey();
          

        }
        public static DistanceOpOver operator+(DistanceOpOver d1,DistanceOpOver d2)
        {
            DistanceOpOver d = new DistanceOpOver();
            d.feet = d1.feet + d2.feet;
            d.inches = d1.inches + d2.inches;
            if (d.inches >= 12)
            {
                d.feet++;
                d.inches %= 12;
            }
            return d;
        }
        private DistanceOpOver AddDistance(DistanceOpOver distance2)
        {
            DistanceOpOver d1 = new DistanceOpOver();
            d1.feet = feet + distance2.feet;
            d1.inches = inches + distance2.inches;
            if (d1.inches >= 12)
            {
                d1.feet++;
                d1.inches %= 12;
            }
            return d1;
        }
        public static DistanceOpOver operator -(DistanceOpOver d1,DistanceOpOver d2)
        {
            DistanceOpOver objd = new DistanceOpOver();
            int dist1, dist2, dist;
            dist1 = (d1.feet * 12) + d1.inches;
            dist2 = (d2.feet * 12) + d2.inches;
            if (dist1 >= dist2)
            {
                dist = dist1 - dist2;

            }
            else
            {
                dist = dist2 - dist1;
            }
            objd.feet = dist / 12;
            objd.inches = dist % 12;
            return objd;
        }
    }
}

