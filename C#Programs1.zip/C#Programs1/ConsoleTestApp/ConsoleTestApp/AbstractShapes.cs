﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    abstract class AbstractShapes
    {
        public double area;
        
        public abstract void FindArea();
        public void Display()
        {
            Console.WriteLine("Area of the given shape is \t"+area);
           
        }
        public static void Main(string[] args)
        {
            Circle1 obj = new Circle1(4.5);
            Triangle obj1=new Triangle(2,4);
            Square obj2 = new Square(3);
           // obj.ReadData();
            obj.FindArea();
            obj.Display1();
            obj.Display();
           // obj1.ReadData();
            obj1.FindArea();
            obj1.Display1();
            obj1.Display();
            
            //  obj2.ReadData();
            obj2.FindArea();
            obj2.Display1();
            obj2.Display();

            Console.ReadKey();
        }
    }
        
  class Circle1 : AbstractShapes{
      
       double radius;
      
       const double PI = 3.14159;
        public Circle1() { }
        public Circle1(double r)
        {
            radius = r;
        }
        public void ReadData()
        {
            Console.WriteLine("Enter the radius:");
            radius = Convert.ToInt32(Console.ReadLine());
        }
     
        public override void FindArea()
       {
           area =PI*radius*radius;
       }
        public void Display1()
        {
            Console.WriteLine("The radius of the circle is\t" + radius);
        }
   }
   class Triangle : AbstractShapes
   {
        int basetr, height;
        public Triangle() { }
        public Triangle(int b,int h)
        {
            basetr = b;
            height = h;
        }
        public void ReadData()
       {
           Console.WriteLine("Enter the base of the triangle:");
           basetr = Convert.ToInt32(Console.ReadLine());
           Console.WriteLine("Enter the height of the triangle:");
           height = Convert.ToInt32(Console.ReadLine());
       }
       public override void FindArea()
       {
           area = 0.5 * basetr * height;
       }
        public void Display1()
        {
            Console.WriteLine("The base and height of the \ntriangle is \t\t\t{0} and {1}",basetr,height);
        }
    }
   class Square : AbstractShapes
   {
        int side;
        public Square() { }
        public Square(int s)
        {
            side = s;
        }
        public void ReadData()
       {
           Console.WriteLine("Enter the side of the square:");
           side = Convert.ToInt32(Console.ReadLine());
       }
       public override void FindArea()
       {
           area =side*side;
       }
        public void Display1()
        {
            Console.WriteLine("The side of the square is\t" + side);
        }
    }
    
    
}
