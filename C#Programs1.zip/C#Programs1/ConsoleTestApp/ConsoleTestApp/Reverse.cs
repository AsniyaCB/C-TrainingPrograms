﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class Reverse
    {
        int n, reverse;

        public void ReadData()
        {
            Console.WriteLine("Enter the number to be reversed:");
            n = Convert.ToInt32(Console.ReadLine());
        }
        public void FindReverse()
        {
            int number = n;
            int lastDigit;
            reverse = 0;
            while (number > 0)
            {
                lastDigit = number % 10;
                reverse = reverse * 10 + lastDigit;
                number /= 10;
            }
        }
        public void Display()
        {
            Console.WriteLine("the reverse of the number {0} is {1}", n, reverse);

        }
        public static void Main()
        {
            Reverse obj = new Reverse();
            obj.ReadData();
            obj.FindReverse();
            obj.Display();
            Console.ReadKey();
        }

    }
}