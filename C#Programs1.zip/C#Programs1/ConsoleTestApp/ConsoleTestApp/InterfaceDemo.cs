﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class InterfaceDemo
    {
        public static void Main()
        {
            Sub s1 = new Sub();
            s1.Display();
            s1.display1();
            Console.ReadKey();
        }
    }
    interface Base1
    {
        void Display();
    }
    interface base2
    {
        void display1();
        
    }
    class QWE
    {
        public void display2() {
            Console.WriteLine("From class");
        }

    }
    class Sub : QWE ,Base1, base2
    {
        public void Display()
        {
            Console.WriteLine("From base1");
        }
        public void display1()
        {
            Console.WriteLine("From base2");
        }

    }

}
