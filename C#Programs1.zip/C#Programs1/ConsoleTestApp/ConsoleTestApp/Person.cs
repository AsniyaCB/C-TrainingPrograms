﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class Person
    {
        public int id;
        public string name;

        public void ReadData()
        {
            Console.WriteLine("Enter the id of the person:");
            id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the name of the person:");
            name = Console.ReadLine();
        }

        public void Display()
        {
            Console.WriteLine("ID:"+ id);
            Console.WriteLine("NAME:"+ name);
        }
        public static void Main()
        {
            Student1 obj1 = new Student1();
            obj1.ReadData();
            
            obj1.ReadData1();
            obj1.FindResult();
            obj1.Display();
            obj1.Display1();
            Console.ReadKey();
        }
    }
    class Student1 : Person
    {
        int mark1, mark2, mark3, total = 0;
        static int passMark=135;
        string result;
        public  void ReadData1()
        {
            Console.WriteLine("Enter the mark1 out of 100:");
            mark1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the mark2 out of 100:");
            mark2 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the mark3 out of 100:");
            mark3 = Convert.ToInt32(Console.ReadLine());
        }
        public void FindResult()
        {
            total = mark1 + mark2 + mark3;
            if (total >= passMark)
            {
                result = "PASSED";
            }
            else
            {
                result = "FAILED";
            }
        }
        public void Display1()
        {
            Console.WriteLine("Mark 1 of the student is:" + mark1);
            Console.WriteLine("Mark 2 of the student is:" + mark2);
            Console.WriteLine("Mark 3 of the student is:" + mark3);
            Console.WriteLine("Total Mark of the student out of 300 is:" + total);
            Console.WriteLine(result);
        }
        
    }

}
