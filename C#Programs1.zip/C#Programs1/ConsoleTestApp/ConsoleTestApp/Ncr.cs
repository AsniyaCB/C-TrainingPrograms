﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class Ncr
    {
        int n, r,factn=1,factr=1, fact=1,ncr;
        public void ReadData()
        {

            Console.WriteLine("Enter the the value for n:");
            n = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the the value for r:");
            r = Convert.ToInt32(Console.ReadLine());
        }
        public void FindNcr()
        {
            int i;
            for (i = n; i > 0; i--)
            {
                factn = factn * i;
            }
            for (i = r; i > 0; i--)
            {
                fact = fact * i;
            }
            for (i = (n-r); i > 0; i--)
            {
                factr = factr * i;
            }
            ncr = factn / (factr*fact);
        }
        public void Display()
        {
            Console.WriteLine("Ncr of the given number {0} and {1} is {2}", n,r, ncr);
        }
        public static void Main(string[] args)
        {
            Ncr obj = new Ncr();
            obj.ReadData();
            obj.FindNcr();
            obj.Display();
            Console.ReadKey();
        }
    }
}
