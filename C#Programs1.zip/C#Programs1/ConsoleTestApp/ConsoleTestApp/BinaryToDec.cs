﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class BinaryToDec
    {
        int binaryNo,decimalNo=0;
         int lastDigit, i = 0;
        public BinaryToDec()
        {

        }
        public BinaryToDec(int binaryNo)
        {
            this.binaryNo = binaryNo;
        }
        public void BtoD()
        {
           
            int n = binaryNo;

            do
           
            {
                lastDigit = n % 10;
                decimalNo=decimalNo+ (lastDigit*(int)Math.Pow(2,i));
                n /= 10;
                i++;
            } while (n > 0) ;
        }
        public void Display()
        {
            Console.WriteLine("the decimal value of the binary number {0} is {1}",binaryNo,decimalNo);
        }
        public static void Main(string[] args)
        {
            BinaryToDec obj = new BinaryToDec(1010);
            obj.BtoD();
            obj.Display();
            Console.ReadKey();
        }
    }
}
