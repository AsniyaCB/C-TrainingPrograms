﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{

    class DecimalToBinary
    {
        string result;
        int decimalNumber;
        public void ReadData()
        {
            Console.Write("Enter the Decimal number: ");
            decimalNumber = Convert.ToInt32(Console.ReadLine());
        }
        public void DtoB()
        {
            int remainder;

            while (decimalNumber > 0)
            {
                remainder = decimalNumber % 2;
                decimalNumber /= 2;
                result = result + remainder.ToString() ;
            }
        }
        public void Display()
        {

            Console.WriteLine("Binary:  {0}", result);
        }

        public static void Main(string[] args)
        {
            DecimalToBinary obj = new DecimalToBinary();
            obj.ReadData();
            obj.DtoB();
            obj.Display();

            Console.ReadKey();
        }
    }
}
        

