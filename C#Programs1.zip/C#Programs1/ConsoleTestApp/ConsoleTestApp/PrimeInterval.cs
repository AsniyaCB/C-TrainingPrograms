﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class PrimeInterval
    {
        int low, high;
      //  string result;

        public void ReadData()
        {
            Console.WriteLine("Enter the lower limit:");
            low = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the upper limit:");
            high = Convert.ToInt32(Console.ReadLine());
        }
        public void FindPrime()
        {
            int i;
            Console.WriteLine("Prime numbers between interval {0} and {1} are:", low, high);
            for (i = low; i < high; i++)
            {
                bool flag = true;
                for (int num = 2; num < i; num++)
                {
                    if (i% num == 0)
                    {
                        flag = false;
                        break;
                    }
                }
                if (flag)
                {
                    Console.WriteLine(i);
                }
            }
        }
            public static void Main()
            {
            PrimeInterval obj = new PrimeInterval();
            obj.ReadData();
            obj.FindPrime();
            Console.ReadKey();
            }
        
    }
}
