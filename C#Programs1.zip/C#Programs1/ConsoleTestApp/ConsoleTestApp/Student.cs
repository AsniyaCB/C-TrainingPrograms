﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class Student
    {
        int id;
        string name, result;
        static int minMark=0,maxMark=100,passMark=45;
        public void ReadData()
        {
            Console.WriteLine("Enter the ID of the student:");
            id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the name of the student:");
            name = Console.ReadLine();

        }
        public void CheckResult()
        {
            int mark;
         
            bool flag=false;
            do
            {
                Console.WriteLine("Enter the mark of the student:");
                mark = Convert.ToInt32(Console.ReadLine());
                if(mark<minMark || mark > maxMark)
                {
                    flag = true;
                    Console.WriteLine("INVALID MARK\n Enter between 1 and 100");
                }
                else
                {
                    if (mark >= passMark)
                    {
                        result = "YEYYY!!CONGRATULATIONS \nYOU ARE PASSED";
                    }
                    else
                    {
                        result = "OOPS!! \nYOU ARE FAILED";
                    }
                }
            } while (flag==true);
        }
        public void Display()
        {
            Console.WriteLine(result);
        }

        public static void Main(string[] args)
        {
            Student obj = new Student();
            obj.ReadData();
            obj.CheckResult();
            obj.Display();
            Console.ReadKey();
        }
    }
}
