﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibrary;

namespace ConsoleTestApp
{
    class TestLibrary
    {
        public static void Main()
        {
            CalculatorClassLib.Display();
            Console.ReadKey();
        }
    }
}
