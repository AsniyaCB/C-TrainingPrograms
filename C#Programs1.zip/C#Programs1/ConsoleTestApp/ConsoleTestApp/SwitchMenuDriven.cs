﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class SwitchMenuDriven
    {
        public static void Main(string[] args) {
            do
            {
                int option;
                Console.WriteLine("************\n 1. DIGIT SUM\n 2. CHECK PRIME\n 3. EXIT\n *************\n Enter the option :");
                option = Convert.ToInt32(Console.ReadLine());
                switch (option)
                {
                    case 1:
                        DigitSum obj1 = new DigitSum();
                        obj1.ReadData();
                        obj1.FindSum();
                        obj1.DisplayData();
                        Console.ReadKey();
                        break;
                    case 2:
                        Prime obj = new Prime();
                        obj.ReadData();
                        obj.FindPrime();
                        obj.Display();
                        Console.ReadKey();
                        break;
                    case 3:
                        System.Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("Invalid Option");
                        break;

                }
            } while (true);
    }
}
}
