﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class AbstractDemo
    {
        public static void Main()
        {
            XYZ xyz = new XYZ();
            xyz.Check();
            xyz.Display();
            xyz.Print();
            ABC.FindSum(2,3);
            Console.ReadLine();

        }

    }
    abstract class ABC
    {
       // int val1;         
       // const double PI = 3.14;
        public abstract void Display(); //public void Display(){ }
        public static int FindSum(int v1, int v2)
        {
         
            return (v1 + v2);
           


        }
        public void Print()
        {
            Console.WriteLine("In print method");
        }
    }
    class XYZ : ABC
    {
        //int val3;
        public void Check()
        {
            Console.WriteLine("In check method");
            
        }
        public override void Display()
        {
           // throw new NotImplementedException();
            Console.WriteLine("In display mehod");
        }
    }
}
