﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class Shapes
    {

        public static void Display(double radius)
        {
            
            const double PI = 3.1415;
            double r = radius;
            double area =   PI * radius * radius;
            Console.WriteLine("area of circle:" + area);
        }
        public static void Display(int length,int breadth)
        {
            
            int l = length;
            int b = breadth;
            int area = l*b;
            Console.WriteLine("area of rectangle:" + area);
        }
        public static void Display(int side)
        {
            
            int s= side;
            int area=side*side;
            Console.WriteLine("area of square:" + area);
        

        }
        public static void Main()
        {
            Display(3.2);
            Display(3,4);
            Display(3);
            Console.ReadKey();
        }
    
    }

}







   
  
