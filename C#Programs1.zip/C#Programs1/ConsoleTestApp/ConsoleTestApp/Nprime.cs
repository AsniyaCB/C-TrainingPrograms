﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class Nprime
    {
        int limit;
        public void ReadData()
        {
            Console.WriteLine("Enter the limit:");
            limit = Convert.ToInt32(Console.ReadLine());
        }
        public void FindPrime()
        {
            int i,j=2, count = limit;
            while (count !=0)
            {
                //  Console.WriteLine("Prime numbers are:", );
                for ( i = 1;i<=count ; i++) {
                    bool flag = true;
                                          
                        for (int num = 2; num < j; num++)
                        {
                            if (j % num == 0)
                            {
                                flag = false;
                                break;
                            }
                        }
                    

                        if (flag)
                        {
                        count--;
                        Console.WriteLine(j);
                        }
                    j++;
                    }
            }
            
        }
        public static void Main()
        {
            Nprime obj = new Nprime();
            obj.ReadData();
            obj.FindPrime();
            Console.ReadKey();
        }
    }
}
