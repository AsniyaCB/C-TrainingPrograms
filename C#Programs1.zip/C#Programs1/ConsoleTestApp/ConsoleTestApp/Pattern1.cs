﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class Pattern1
    {
        public static void Main(string[] args)
        {
            for(int i=0;i<=5;i++)
            {
                Console.WriteLine("*");
                Console.WriteLine("\n");
                Console.ReadKey();
            }
        }
        
    }
}
