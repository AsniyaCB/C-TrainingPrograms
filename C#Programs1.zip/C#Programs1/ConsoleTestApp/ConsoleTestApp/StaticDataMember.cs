﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class StaticDataMember
    {
        int i=10;
        static int j=10;
        public void Display()
        {
           
            Console.WriteLine("int i:" + i);
            Console.WriteLine("static int j:" + j);
            i++;
            j++;
        }
        public static void Main()
        {
            StaticDataMember obj = new StaticDataMember();
            StaticDataMember obj1 = new StaticDataMember();

            StaticDataMember obj2 = new StaticDataMember();

            StaticDataMember obj3= new StaticDataMember();
            StaticDataMember.j = 100;               //not necessary to call with classname,works othewise also bcz static data member in static method
            obj.i = 100;        //works only if called using object or else shows error
            obj.Display();
            obj1.Display();
            obj2.Display();
            obj3.Display();
            Console.ReadKey();

        }
    }
}
