﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class Fibanocci
    {
        int number,a,b,c;
        public void ReadData()
        {
            Console.WriteLine("Enter the limit:");
            number = Convert.ToInt32(Console.ReadLine());
        }
        public void FindFib()
        {
            a = 0;
            b = 1;
            if (number == 1)
            {
                Console.WriteLine(a);
            }
            else if (number == 2)
            {
                Console.WriteLine(a);
                Console.WriteLine(b);
            }
            else
            {
                Console.WriteLine(a);
                Console.WriteLine(b);
                for (int i = 3; i <= number; i++)
                {
                    c = a + b;
                    Console.WriteLine(c);
                    a = b;
                    b = c;
                }
            }
        }
        public static void Main()
        {
            Fibanocci obj = new Fibanocci();
            obj.ReadData();
            obj.FindFib();
            Console.ReadKey();
        }
    }
}
