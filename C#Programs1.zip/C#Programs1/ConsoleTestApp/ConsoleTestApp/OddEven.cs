﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class OddEven
    {
        int n;
        public void ReadData()
        {
            Console.WriteLine("Enter the integer:");
            n = Convert.ToInt32(Console.ReadLine());
        }
        public void DisplayData()
        {
            if (n % 2 == 0)
            {
                Console.WriteLine("even");
            }
            else
            {
                Console.WriteLine("odd");
            }
        }
 
        public static void Main(string[] args)
        {
            OddEven obj = new OddEven();
            obj.ReadData();
            obj.DisplayData();
            Console.ReadKey();
        }
    }
}
