﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class EvenOddInterval
    {
        int low, high,i;
        public void ReadData()
        {
            Console.WriteLine("Enter the lower limit:");
            low = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the upper limit:");
            high = Convert.ToInt32(Console.ReadLine());
        }
        public void Display()
        {
            Console.WriteLine("\nEVEN");
            for (i = low; i <= high; i++)
            {
                if (i % 2 == 0)
                {
                    Console.WriteLine( i);
                }
            }
            Console.WriteLine("\nODD");
            for (i = low; i <= high; i++)
            {
                if (i % 2 != 0)
                {
                    Console.WriteLine(i);
                }
            }
        }
        public static void Main(string[] args)
        {
            EvenOddInterval obj = new EvenOddInterval();
            obj.ReadData();
            obj.Display();
            Console.ReadKey();
        }
    }
}
