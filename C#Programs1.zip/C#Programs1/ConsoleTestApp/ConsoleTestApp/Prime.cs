﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class Prime
    {
        int n,i;
        String result;
        public void ReadData()
        {
            Console.WriteLine("Enter the integer:");
            n = Convert.ToInt32(Console.ReadLine());
            
        }
        public void FindPrime()
        {
            bool flag = true;
            
            for (i = 2; i < n; i++)
            {                
                if (n % i == 0)
                {
                    flag = false;
                    break;
                }
            }
            
                 if (flag)
                 {
                    result = "PRIME";
                 }
                 else
                 {
                    result = "NOT PRIME";
                 }
        }
        public void Display()
        {

            if (n == 1)
            {
                result = "NEITHER PRIME NOR COMPOSITE";
            }
            Console.WriteLine("The given number {0} is {1}", n, result);
            
        }
        public static void Main(string[] args)
        {
            Prime obj = new Prime();
            obj.ReadData();
            obj.FindPrime();
            obj.Display();
            Console.ReadKey();
        }
    }
}
