﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class PallindromeNum
    {
        int n, reverse;
        string result;

        public void ReadData()
        {
            Console.WriteLine("Enter the number to be checked:");
            n = Convert.ToInt32(Console.ReadLine());
        }
        public void FindReverse()
        {
            int number = n;
            int lastDigit;
            reverse = 0;
            while (number > 0)
            {
                lastDigit = number % 10;
                reverse = reverse * 10 + lastDigit;
                number /= 10;
            }
            if (n == reverse)
            {
                result = "PALLINDROME";
            }
            else
            {
                result = "NOT PALLINDROME";
            }
        }
        public void Display()
        {
            Console.WriteLine(result);
            
        }
        public static void Main()
        {
            PallindromeNum obj = new PallindromeNum();
            obj.ReadData();
            obj.FindReverse();
            obj.Display();
            Console.ReadKey();
        }

    }
}