﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class SingleDigitSum
    {
        int number, digitSum;
        public SingleDigitSum() { }
        public SingleDigitSum(int n)
        {
            number = n;
        }
        public void FindSum()
        {
            int temp = number;
            int lastDigit;


            while (temp > 0)
            {
                lastDigit = temp % 10;
                digitSum += lastDigit;
                temp /= 10;
            }
        }
        public void SingleDigit()
        {

            while (digitSum > 9)
            {
                     FindSum();
                    }
                 }
        
        public void DisplayData()
        {
            Console.WriteLine("The single Digit sum of {0} is {1}", number, digitSum);
        }

        public static void Main(string[] args)
        {
            SingleDigitSum obj = new SingleDigitSum(4508);

            obj.FindSum();
            obj.SingleDigit();
            obj.DisplayData();
           
            Console.ReadKey();
        }
    }
}