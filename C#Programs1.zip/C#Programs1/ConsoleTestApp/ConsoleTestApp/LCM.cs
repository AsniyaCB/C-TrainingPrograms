﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class LCM
    {
            int num1, num2;
            public void ReadData()
            {
                Console.WriteLine("enter the first number");
                num1 = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("enter the second number");
                num2 = Convert.ToInt32(Console.ReadLine());
            }
            public void Check()
            {

                int x = num1;
                int y = num2;
                int lcm;
                while (num1 != num2)
                {
                    if (num1 > num2)
                    {
                        num1 = num1 - num2;

                    }
                    if (num2 > num1)
                    {
                        num2 = num2 - num1;
                    }
                }
                lcm = (x * y) / num1;
                Console.WriteLine("lcm is" + lcm);
            }
            public static void Main()
            {
                LCM l = new LCM();
                l.ReadData();
                l.Check();
                Console.ReadKey();
            }
        }
    }

