﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class Circle
    {
        double radius, area, circumference;
        const double pi = 3.1415;
        public void ReadData()
        {
           
            Console.WriteLine("Enter the radius of the circle:");
            radius = Convert.ToInt32(Console.ReadLine());
        }
        public void Area()
        {
            area = pi * radius * radius;

        }
        public void Circum()
        {
            circumference = 2 * pi * radius;
        }
        public void Display()
        {
            Console.WriteLine("Area of the circle is=" + area);
            Console.WriteLine("Circumference of the circle is=" + circumference);
        }
        public static void Main(string[] args)
        {
            Circle obj = new Circle();
            obj.ReadData();
            obj.Area();
            obj.Circum();
            obj.Display();
            Console.ReadKey();
        }
    }
}
