﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class Armstrong
    {
        int number;
        string result;
        double sum;
      
        public void ReadData()
        {
            Console.WriteLine("Enter the number:");
            number = Convert.ToInt32(Console.ReadLine());
        }
        public void FindSum()
        {
            int digit=0;
            int copy1 = number;
            int n = number;
            int lastDigit;
           
            while (n > 0)       //to find digits
            {
                lastDigit = n % 10;
                digit += 1;
                n /= 10;
            }
            while (copy1 > 0)       //sum of each of the digits raised to the power of the total no of digits
            {
                lastDigit = copy1 % 10;
                copy1 /= 10;
                double pow = Math.Pow(lastDigit, digit);
                sum = sum +pow;
            }

        }
        public void CheckArmstrong()
        {
            if (sum == number)
            {
                result = "ARMSTRONG";
            }
            else
            {
                result = "NOT ARMSTRONG ";
            }
        }
        public void Display()
        {
          //  Console.WriteLine("digits:" + digit);

            Console.WriteLine(result);

        }
        public static void Main()
        {
            Armstrong obj = new Armstrong();
            obj.ReadData();
            obj.FindSum();
            obj.CheckArmstrong();
            obj.Display();
            Console.ReadKey();
        }
    }
}
