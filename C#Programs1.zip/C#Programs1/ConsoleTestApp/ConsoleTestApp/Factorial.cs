﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class Factorial
    {
        int number, i, factorial = 1;
        public void ReadData()
        {

            Console.WriteLine("Enter the number:");
            number = Convert.ToInt32(Console.ReadLine());
        }
        public void FindFactorial()
        {

            for (i = number; i > 0; i--)
            {
                factorial = factorial * i;


            }
        }
        public void Display()
        {
            Console.WriteLine("Factorial of {0} numbers are {1}", number, factorial);
        }
        public static void Main(string[] args)
        {
            Factorial obj = new Factorial();
            obj.ReadData();
            obj.FindFactorial();
            obj.Display();
            Console.ReadKey();
        }

    }
}

