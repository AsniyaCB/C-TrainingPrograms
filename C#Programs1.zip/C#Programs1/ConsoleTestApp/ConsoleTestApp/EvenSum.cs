﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class EvenSum
    {
        int number, i,sum,c=0;
        public void ReadData()
        {

            Console.WriteLine("Enter the number:");
            number = Convert.ToInt32(Console.ReadLine());
        }
        public void FindEven()
        {
            i = 0;
            while(c<number)
            {
                sum += i;
                i = i + 2;
                c++;
            }
        }
        public void Display()
         {
            Console.WriteLine("Sum of {0} even numbers are {1}", number, sum);
         }
        public static void Main(string[] args)
        {
            EvenSum obj = new EvenSum();
            obj.ReadData();
            obj.FindEven();
            obj.Display();
            Console.ReadKey();
        }

    }
}
