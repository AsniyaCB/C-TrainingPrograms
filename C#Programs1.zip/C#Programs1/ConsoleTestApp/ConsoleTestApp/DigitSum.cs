﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class DigitSum
    {
        int number,digitSum;
        public DigitSum()
        {

        }
        public DigitSum(int number)
        {
            this.number = number;
        }
        public void ReadData() {
            Console.WriteLine("Enter the integer:");
            number = Convert.ToInt32(Console.ReadLine());
        }
        public void DisplayData()
        {
            Console.WriteLine("The digit sum of the given number {0} is {1}",number,digitSum);
        }
        public void FindSum()
        {
            int n = number;
            int lastDigit;
            do
            {
                lastDigit = n % 10;
                digitSum += lastDigit;
                n /= 10;
            } while (n > 0);
        }
        public static void Main(string[] args)
        {
            DigitSum obj = new DigitSum(4508);
            //obj.ReadData();
            obj.FindSum();
            obj.DisplayData();
           // Console.ReadKey();
            DigitSum obj1 = new DigitSum();
            obj1.ReadData();
            obj1.FindSum();
            obj1.DisplayData();
            Console.ReadKey();
        }
    }
}
