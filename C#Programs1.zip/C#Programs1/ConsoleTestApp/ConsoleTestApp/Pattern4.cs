﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class Pattern4
    {
        int i, j;
        int space = 5;
        int max = 10;
        public void PrintPattern()
        {
            for (i = 0; i <= max; i++)
            {
                for (j = 0; j < space; j++)
                {
                    Console.Write(" ");
                }
                for (j = 0; j < i; j++)
                {
                    Console.Write("* ");
                }
                Console.Write("\n");
                space--;
                max--;
            }
        }
        public static void Main()
        {
            Pattern4 obj = new Pattern4();
            obj.PrintPattern();
            Console.ReadKey();

        }
    }
}
