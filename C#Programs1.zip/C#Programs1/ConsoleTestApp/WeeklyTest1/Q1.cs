﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WeeklyTest1
{
    public class Q1
    {

        public static void Main(string[] args)
        {
            int option;
            Console.WriteLine("1.CHECK PRIME \n 2.GENERATE PRIME BETWEEN 2 INTERVALS\n 3.GENERATE N PRIME NUMBERS\n 4.EXIT\n Enter your Option:");
            option = Convert.ToInt32(Console.ReadLine());
            do
            {
                switch (option)
                {
                    case 1:
                        PrimeCheck p1 = new PrimeCheck();
                        p1.ReadData1();
                        p1.CheckPrime();
                        p1.Display1();
                        break;
                    //case 2:
                    //    break;
                    //case 3:
                    //    break;
                    case 4:
                        System.Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("INVALID OPTION");
                        break;
                }
            } while (true);
        }
        class PrimeCheck
        {
            int number;
            string result;
            public void ReadData1()
            {
                Console.WriteLine("Enter the number to be checked:");
                number = Convert.ToInt32(Console.ReadLine());
            }

            public void CheckPrime()
            {        
                bool flag = true;
                for (int i = 2; i < number; i++)
                {

                    if (number % i == 0)
                    {
                        flag = false;
                        break;
                    }
                }
                if (flag)
                {
                    result="PRIME";
                }
                else
                {
                    result = "NOT PRIME";
                }
            }
            public void Display1()
            {
                Console.WriteLine(result);
            }

        }
    }
}

