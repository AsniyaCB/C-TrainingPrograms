﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class CalculatorClassLib
    {
        public static void Display()
        {
            Console.WriteLine("iam within library DLL project");
        }
    }

}
