﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AddressBookBL.BL;
using AddressBookDTO.DTO;

namespace AddressBookSolution1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            AddressBook addressBook = null;
            AddressBLL.AddressInsert(addressBook);
        }

        private void lblTitle_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dataSqlDataSet.AddressTable' table. You can move, or remove it, as needed.
            this.addressTableTableAdapter.Fill(this.dataSqlDataSet.AddressTable);
            LoadContacts();
            LoadContactIDs();
        }
        private void LoadContacts()
        {
            DataSet dsStudents = null;
            try
            {
                dsStudents = AddressBLL.GetContacts();
                if (dsStudents != null)
                {
                    dgv.DataSource = dsStudents.Tables[0];
                }
                else
                {
                    lblMessage.Text = "No contacts avialbale";
                }
            }
            catch (Exception ex)
            {
                lblMessage.Text = ex.Message.ToString();

            }
        }
        private void LoadContactIDs()
        {
            DataSet dsStudentID = null;
            try
            {
                dsStudentID = AddressBLL.GetContactIDs();
                if (dsStudentID != null)
                {
                    cmbID.DataSource = dsStudentID.Tables[0];


                    cmbID.ValueMember = "Id";
                    cmbID.DisplayMember = "Id";

                }
                else
                {
                    lblMessage.Text = "No contacts avialable";
                }
            }
            catch (Exception ex)
            {
                lblMessage.Text = ex.Message.ToString();

            }
        }
        private void btnSave_Click(object sender, EventArgs e)
        {
            int output = 0;
            AddressBook addressBook = null;
            try
            {
                if (btnSave.Text == "NEW")
                {
                    btnSave.Text = "SAVE";
                    ClearControl();
                    txtId.Text = AddressBLL.GetNewContactIDs();

                    btnDelete.Enabled = false;
                    btnUpdate.Enabled = false;

                    btnClear.Text = "BACK";
                }
                else
                {
                    if (txtId.Text == string.Empty || txtName.Text == string.Empty || cmbState.Text == string.Empty ||
                        txtEmail.Text == string.Empty || txtMobile.Text == string.Empty || txtAddress.Text == string.Empty)
                    {
                        lblMessage.Text = "Enter all the details";
                        foreach (Control control in this.Controls)
                        {
                            if (!Validate())
                            {
                                DialogResult = DialogResult.None;
                                return;
                            }
                        }
                    }
                    else
                    {

                        addressBook = new AddressBook();
                        addressBook.ContactId = txtId.Text;
                        addressBook.ContactName = txtName.Text;
                        addressBook.DOb = dtpDOB.Value.ToString("dd-MM-yyyy");
                        addressBook.Address = txtAddress.Text;

                        addressBook.Email = txtEmail.Text;
                        if (cmbState.SelectedIndex == -1)
                        {
                            lblMessage.Text = "Please select a state !!!";
                            return;
                        }
                        else
                        {
                            addressBook.State = cmbState.Text;
                        }
                        if (txtEmail.Text == string.Empty || (!txtEmail.Text.Contains('@')) || (!txtEmail.Text.Contains('.')))
                        {
                            lblMessage.Text = "Enter a valid email id !!!";
                            return;
                        }
                        else
                        {
                            addressBook.Email = txtEmail.Text;
                        }
                        if (txtMobile.Text == string.Empty || txtMobile.Text.Length != 10 && (txtMobile.Text.StartsWith("0")))
                        {
                            lblMessage.Text = "Enter a valid mobile number !!!";
                            return;
                        }
                        else
                        {
                            addressBook.Mobnumber = Convert.ToInt64(txtMobile.Text);
                        }
                        if (!rdbMale.Checked && !rdbFemale.Checked)
                        {
                            lblMessage.Text = "Please Select gender !!!";
                            return;
                        }

                        else if (rdbMale.Checked)
                        {
                            addressBook.Gender = "Male";
                        }
                        else
                        {
                            addressBook.Gender = "Female";
                        }


                        output = AddressBLL.AddressInsert(addressBook);
                        if (output > 0)

                        {
                            lblMessage.Text = "successfully added";
                            LoadContacts();

                            LoadContactIDs();
                            btnSave.Text = "NEW";
                            btnDelete.Enabled = true;
                            btnUpdate.Enabled = true;

                            btnClear.Text = "CLEAR";


                        }
                        else
                        {
                            lblMessage.Text = "failed to insert";
                        }
                    }

                }
            }
            catch (Exception e1)
            {
                lblMessage.Text = e1.Message.ToString();
            }
        }
        private void ClearControl()
        {
            txtId.Text = "";
            txtName.Text = "";
            txtMobile.Text = "";
            txtEmail.Text = "";
            txtAddress.Text = "";
            cmbState.Text = "";
            dtpDOB.Text = "";
            rdbFemale.Text = "";
            rdbMale.Text = "";
        }
        private void btnDelete_Click(object sender, EventArgs e)
        {

            int output = 0;
            try
            {
                if (MessageBox.Show("Do you want to delete ?", "Confirm ", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    output = AddressBLL.AddressDelete(cmbID.Text);
                    if (output > 0)
                    {
                        LoadContactIDs();
                        LoadContacts();
                        lblMessage.Text = "contact details deleted successfully";
                    }
                    else
                    {
                        lblMessage.Text = "Please try again later";
                    }
                }
                else
                {
                    lblMessage.Text = "Item not deleted";
                }
            }
            catch (Exception ex)
            {
                lblMessage.Text = ex.Message.ToString();
            }
        }

        private void cmbID_SelectedIndexChanged(object sender, EventArgs e)
        {
            AddressBook addressBook = null;
            try
            {
                addressBook = AddressBLL.GetContactByID(cmbID.Text);

                if (addressBook != null)
                {
                    txtId.Text = addressBook.ContactId;
                    txtName.Text = addressBook.ContactName;
                    txtMobile.Text = addressBook.Mobnumber.ToString();
                    txtEmail.Text = addressBook.Email;
                    
                }
            }

            catch (Exception ex)
            {
                lblMessage.Text = ex.Message.ToString();

            }

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            AddressBook addressBook = null;
            int output = 0;
            try
            {
                addressBook = new AddressBook();
                addressBook.ContactId = txtId.Text;
                addressBook.ContactName = txtName.Text;

                addressBook.DOb = dtpDOB.Value.ToString("dd-MM-yyyy");
                if (rdbMale.Checked)
                {
                    addressBook.Gender = "Male";
                }
                else
                {
                    addressBook.Gender = "Female";
                }
                addressBook.Address = txtAddress.Text;
                addressBook.State = cmbState.Text;
                addressBook.Email = txtEmail.Text;
                addressBook.Mobnumber = Convert.ToInt64(txtMobile.Text);
                addressBook.Email = txtEmail.Text;
             


                    output = AddressBLL.AddressUpdate(addressBook);

                    if (output > 0)

                    {
                    LoadContactIDs();
                    LoadContacts();
                        lblMessage.Text = "contacts details updated successfully";

                    }
                    else
                    {
                        lblMessage.Text = "Please try again later";
                    }

                
            }
            catch (Exception e4)
            {
                lblMessage.Text = e4.Message.ToString();
            }
        }

        private void lblAddress_Click(object sender, EventArgs e)
        {

        }

        private void txtAddress_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtId_Validating(object sender, CancelEventArgs e)
        {
            if (txtId.Text == string.Empty)
            {
                eP.SetError(txtId, "ID is required !");
            }
            else
            {
                eP.SetError(txtId, string.Empty);
            }
        }

        private void txtName_Validating(object sender, CancelEventArgs e)
        {
            if (txtName.Text == string.Empty)
            {
                eP.SetError(txtName, "Name is required !");
            }
            else
            {
                eP.SetError(txtName, string.Empty);
            }

        }

        private void txtAddress_Validating(object sender, CancelEventArgs e)
        {
            if (txtAddress.Text == string.Empty)
            {
                eP.SetError(txtAddress, "Address is required !");
            }
            else
            {
                eP.SetError(txtAddress, string.Empty);
            }
        }

        private void cmbState_Validating(object sender, CancelEventArgs e)
        {
            if (cmbState.Text == string.Empty)
            {
                eP.SetError(cmbState, "State is required !");
            }
            else
            {
                eP.SetError(cmbState, string.Empty);
            }
        }

        private void txtEmail_Validating(object sender, CancelEventArgs e)
        {

            if (txtEmail.Text == string.Empty )
            {
                eP.SetError(txtEmail, "Email id is required !");
            }
            else
            {
                eP.SetError(txtEmail, string.Empty);
            }
        }

        private void txtMobile_Validating(object sender, CancelEventArgs e)
        {
            if (txtMobile.Text == string.Empty)
            {
                eP.SetError(txtMobile, "Mobile number is required !");
            }
            else
            {
                eP.SetError(txtMobile, string.Empty);
            }
        }

        private void dgv_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            if (btnClear.Text == "BACK")
            {
                btnSave.Text = "NEW";
                btnDelete.Enabled = true;
                btnUpdate.Enabled = true;

                btnClear.Text = "CLEAR";
            }

            else
            {
                ClearControl();
            }
        }
    }
}
