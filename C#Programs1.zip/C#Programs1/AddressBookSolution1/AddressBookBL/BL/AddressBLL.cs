﻿using System;
using System.Collections.Generic;
using System.Text;
using AddressBookDSL.AddressDL;
using AddressBookDTO.DTO;
using System.Data;
using System.Data.SqlClient;


namespace AddressBookBL.BL
{
    public class AddressBLL
    {
        public static int AddressInsert(AddressBook addressBook)
        {
            int output = 0;

            try
            {
                output = AddressDSL.AddressInsert(addressBook);
            }

            catch (Exception e3)
            {
                Console.Out.WriteLine(" inside catch-ERROR : AddressBLL.cs " + e3.Message.ToString());
            }


            return output;



    }

        public static int AddressDelete(string contactId)
        {
            int output = 0;

            try
            {
                output = AddressDSL.AddressDelete(contactId);

            }
            catch (Exception e3)
            {
                Console.Out.WriteLine(" ERROR :addressDSL.cs:AddressDelete: " + e3.Message.ToString());


            }

            return output;
        }
        public static int AddressUpdate(AddressBook addressBook)
        {
            int output = 0;


            try
            {
                

                output = AddressDSL.AddressUpdate(addressBook);

            }
            catch (Exception e3)
            {
                Console.Out.WriteLine(" inside catch-ERROR : AddressBL.cs:AddressUpdate " + e3.Message.ToString());


            }

            return output;

        }

        public static DataSet GetContacts()
    {
        //String sql = "";

        DataSet dsContacts = null;

        try
        {

            dsContacts = AddressDSL.GetContacts();


        }
        catch (Exception e3)
        {
            Console.Out.WriteLine(" inside catch-ERROR : AdressBLL.cs :GetContacts()" + e3.Message.ToString());


        }

        return dsContacts;
    }
        public static DataSet GetContactIDs()
        {
            //String sql = "";

            DataSet dsContacts = null;

            try
            {

                dsContacts = AddressDSL.GetContactIDs();


            }
            catch (Exception e3)
            {
                Console.Out.WriteLine(" inside catch-ERROR : AddressBL.cs " + e3.Message.ToString());


            }

            return dsContacts;
        }
        public static AddressBook GetContactByID(string contactId)
        {

            AddressBook addressBook = null;
            try
            {
                addressBook = AddressDSL.GetContactByID(contactId);
            }
            catch (Exception e3)
            {
                Console.Out.WriteLine(" ERROR : AddressBL.cs:GetContactById() " + e3.Message.ToString());


            }

            return addressBook;
        }
        public static String GetNewContactIDs()
        {

            string LastContactID = null;
            string newContactID = null;

            try
            {
                LastContactID = AddressDSL.GetLastContactIDs();

                if (LastContactID != null)
                {
                    newContactID = UtilityHelper.GenerateID(LastContactID);
                }
                else
                {
                    newContactID = "PH101";
                }
            }


            catch (Exception e3)
            {
                Console.Out.WriteLine(" inside catch-ERROR : Contact_Mark_BL.cs:GetLastContactIDs() " + e3.Message.ToString());


            }

            return newContactID;
        }

    }
}
