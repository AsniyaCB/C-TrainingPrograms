﻿using System;

namespace AddressBookBL
{
    public class Class1
    {
    }
}
