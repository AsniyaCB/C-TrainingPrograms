﻿using System;

namespace AddressBookDTO
{
    public class Class1
    {
    }
}
