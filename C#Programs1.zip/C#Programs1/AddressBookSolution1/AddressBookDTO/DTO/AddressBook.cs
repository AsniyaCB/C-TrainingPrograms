﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AddressBookDTO.DTO
{
    public class AddressBook
    {
        private string contactId;
        public String ContactId
        {
            get { return contactId; }
            set { contactId = value; }
        }


        private string contactName;
        public String ContactName
        {
            get { return contactName; }
            set { contactName = value; }
        }

        private string dob;
        public String DOb
        {
            get { return dob; }
            set { dob = value; }
        }

        private string email;
        public String Email
        {
            get { return email; }
            set { email = value; }

        }

        private double mobnumber;
        public double Mobnumber
        {
            get { return mobnumber; }
            set { mobnumber = value; }

        }
        private string state;
        public string State
        {
            get { return state; }
            set { state = value; }

        }
        private string address;
        public string Address
        {
            get { return address; }
            set { address = value; }

        }
        private string gender;
        public string Gender
        {
            get { return gender; }
            set { gender = value; }

        }


    }
}
