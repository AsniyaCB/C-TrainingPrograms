﻿using System;
using System.Collections.Generic;
using System.Text;
using AddressBookDTO.DTO;
using AddressBookDSL.Helper;
using System.Data;
using System.Data.SqlClient;

namespace AddressBookDSL.AddressDL
{
    public class AddressDSL
    {
        public static int AddressInsert(AddressBook addressBook)
        {
            int output = 0;
            string sql = null;
            SqlConnection con = null;
            SqlCommand cmd = null;

            try
            {
                sql = " insert into AddressTable(Id,contactname,mobilenumber,email,Gender,state,DOB,adress) VALUES (";
                sql = sql + "'" + addressBook.ContactId + "',";
                sql = sql + "'" + addressBook.ContactName + "',";
                sql = sql + addressBook.Mobnumber + ",";
                sql = sql + "'" + addressBook.Email + "',";
                sql = sql + "'" + addressBook.Gender + "',";
                sql = sql + "'" + addressBook.State + "',";
                sql = sql + "'" + addressBook.DOb + "',";
                sql = sql + "'" + addressBook.Address + "')";


                con = DBHelper.GetConnection();
                con.Open();
                cmd = new SqlCommand(sql, con);
                output = cmd.ExecuteNonQuery();
            }
            catch (Exception e3)
            {
                Console.Out.WriteLine(" inside catch-ERROR :AddressDSL.cs " + e3.Message.ToString());


            }
            finally
            {
                con.Close();
                cmd.Dispose();
            }
            return output;
        }
        public static int AddressDelete(String contactId)
        {
            int output = 0;
            string sql = null;
            SqlConnection con = null;
            SqlCommand cmd = null;

            try
            {
                sql = "delete from AddressTable where Id='" + contactId + "'";

                ////////////
                con = DBHelper.GetConnection();
                con.Open();
                cmd = new SqlCommand(sql, con);
                output = cmd.ExecuteNonQuery();

            }
            catch (Exception e3)
            {
                Console.Out.WriteLine(" inside catch-ERROR : AddressDSL.cs " + e3.Message.ToString());


            }
            finally
            {
                con.Close();
                cmd.Dispose();
            }
            return output;
        }
        public static int AddressUpdate(AddressBook addressBook)
        {
            int output = 0;
            string sql = null;
            SqlConnection con = null;
            SqlCommand cmd = null;

            try
            {
                sql = " update AddressTable set ";

                sql = sql + "contactname='" + addressBook.ContactName + "',";
                sql = sql + "mobilenumber=" + addressBook.Mobnumber + ",";
                sql = sql + "email='" + addressBook.Email + "',";
                sql = sql + "Gender='" + addressBook.Gender + "',";
                sql = sql + "state='" + addressBook.State + "',";
                sql = sql + "DOB='" + addressBook.DOb + "',";
                sql = sql + "adress='" + addressBook.Address + "'";

                sql = sql + "where Id='" + addressBook.ContactId + "'";
                

                ////////////
                con = DBHelper.GetConnection();
                con.Open();
                cmd = new SqlCommand(sql, con);
                output = cmd.ExecuteNonQuery();

            }
            catch (Exception e3)
            {
                Console.Out.WriteLine(" inside catch-ERROR : AddressDSL.cs " + e3.Message.ToString());


            }
            finally
            {
                con.Close();
                cmd.Dispose();
            }
            return output;
        }
        public static DataSet GetContactIDs()
        {
            String sql = "";
            SqlConnection con = null;
            SqlDataAdapter adapter = null;

            DataSet dsContacts = null;

            try
            {
                sql = "select Id from AddressTable";
                con = DBHelper.GetConnection();
                con.Open();
                dsContacts = new DataSet();
                adapter = new SqlDataAdapter(sql, con);
                adapter.Fill(dsContacts);
            }
            catch (Exception e3)
            {
                Console.Out.WriteLine(" inside catch-ERROR : AddressDSL.cs " + e3.Message.ToString());


            }
            finally
            {
                con.Close();

            }
            return dsContacts;
        }

        public static DataSet GetContacts()
        {
            String sql = "";
            SqlConnection con = null;
            SqlDataAdapter adapter = null;

            DataSet dsContacts = null;

            try
            {
                sql = "select * from AddressTable";
                con = DBHelper.GetConnection();
                con.Open();
                dsContacts = new DataSet();
                adapter = new SqlDataAdapter(sql, con);
                adapter.Fill(dsContacts);
            }
            catch (Exception e3)
            {
                Console.Out.WriteLine(" inside catch-ERROR : AddressDSL.cs " + e3.Message.ToString());


            }
            finally
            {
                con.Close();

            }
            return dsContacts;
        }
        public static AddressBook GetContactByID(string contactId)
        {
            String sql = "";
            SqlConnection con = null;
            SqlDataAdapter adapter = null;

            DataSet dsContacts = null;
            AddressBook addressBook = null;
            try
            {
                sql = "select * from AddressTable where Id='" + contactId + "'";
                con = DBHelper.GetConnection();
                con.Open();
                dsContacts = new DataSet();
                adapter = new SqlDataAdapter(sql, con);
                adapter.Fill(dsContacts);

                Object[] Data = null;

                if (dsContacts.Tables[0].Rows.Count > 0)
                {
                    //to retrieve all data from table for required ID

                    Data = dsContacts.Tables[0].Rows[0].ItemArray;
                    addressBook = new AddressBook();
                    addressBook.ContactId = Data[0].ToString();
                    addressBook.ContactName = Data[1].ToString();
                    addressBook.Mobnumber = Convert.ToInt64(Data[2].ToString());
                    addressBook.Email =Data[3].ToString();
                    addressBook.Gender = Data[4].ToString();
                    addressBook.State = Data[5].ToString();
                    addressBook.DOb = Data[6].ToString();
                    addressBook.Address = Data[7].ToString();


                }
            }
            catch (Exception e3)
            {
                Console.Out.WriteLine(" inside catch-ERROR : AddressDSL.cs: " + e3.Message.ToString());


            }
            finally
            {
                con.Close();

            }
            return addressBook;
        }
        public static String GetLastContactIDs()
        {
            String sql = "";
            SqlConnection con = null;
            SqlDataAdapter adapter = null;

            DataSet dsContacts = null;

            string LastContactID = null;
            object[] Data = null;

            try
            {
                sql = "select Id from AddressBook order by Id desc";
                con = DBHelper.GetConnection();
                con.Open();
                dsContacts = new DataSet();
                adapter = new SqlDataAdapter(sql, con);
                adapter.Fill(dsContacts);

                if (dsContacts.Tables[0].Rows.Count > 0)
                {
                    Data = dsContacts.Tables[0].Rows[0].ItemArray;
                    LastContactID = Data[0].ToString();
                }

            }
            catch (Exception e3)
            {
                Console.Out.WriteLine(" inside catch-ERROR : AddressDSL.cs:GetLastContactIDs() " + e3.Message.ToString());


            }
            finally
            {
                con.Close();

            }
            return LastContactID;
        }
    }
}
