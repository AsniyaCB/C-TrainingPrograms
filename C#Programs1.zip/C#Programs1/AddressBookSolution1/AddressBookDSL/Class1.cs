﻿using System;

namespace AddressBookDSL
{
    public class Class1
    {
    }
}
