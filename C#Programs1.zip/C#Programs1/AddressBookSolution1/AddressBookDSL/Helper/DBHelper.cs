﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace AddressBookDSL.Helper
{
    class DBHelper
    {
         public static SqlConnection GetConnection()
        {
            SqlConnection con = null;
           //string connectionstring = null;
       
            try
            {
                String connectionstring = ConfigurationManager.ConnectionStrings["AddressBookSolution1.Properties.Settings.DataSqlConnectionString"].ConnectionString;
                //String connectionstring = ConfigurationManager.ConnectionStrings["AddressBookPL.Properties.Settings.DatasqlConnectionString"].ConnectionString;
                //connectionstring = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=D:\\asniya\\AddressBookSolution1\\AddressBookDSL\\Data\\DataSql.mdf;Integrated Security=True";
                con = new SqlConnection(connectionstring); //connection with db
            }
            catch (Exception e3)
            {
                Console.Out.WriteLine(" inside catch-ERROR : DBHelper.cs " + e3.Message.ToString());
            }
            return con;

        }
    }
}

