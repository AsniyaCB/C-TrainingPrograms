﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;

namespace PocketMoneyDSL.Helper
{
    class DBHelper
    {
        public static SqlConnection GetConnection()
        {
            SqlConnection con = null;
           // string connectionstring = null;

            try
            {
                String connectionstring = ConfigurationManager.ConnectionStrings["PocketMoneySolution.Properties.Settings.DatabaseConnectionString"].ConnectionString;
               
                //connectionstring = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=D:\\asniya\\PocketMoneySolution\\PocketMoneyDL\\Data\\Database.mdf;Integrated Security=True";
                con = new SqlConnection(connectionstring); //connection with db
            }
            catch (Exception e3)
            {
                Console.Out.WriteLine(" inside catch-ERROR : DBHelper.cs " + e3.Message.ToString());
            }
            return con;

        }
    }
}
