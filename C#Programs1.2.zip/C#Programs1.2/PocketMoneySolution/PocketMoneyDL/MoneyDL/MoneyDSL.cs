﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using PocketMoneyDTO.DTO;
using PocketMoneyDSL.Helper;

namespace PocketMoneyDSL.MoneyDL
{
    public class MoneyDSL
    {
        public static DataSet GetProducts()
        {
            String sql = "";
            SqlConnection con = null;
            SqlDataAdapter adapter = null;

            DataSet dsProducts = null;

            try
            {
                sql = "select * from PocketMoneyTable";
                con = DBHelper.GetConnection();
                con.Open();
                dsProducts = new DataSet();
                adapter = new SqlDataAdapter(sql, con);
                adapter.Fill(dsProducts);
            }
            catch (Exception e3)
            {
                Console.Out.WriteLine(" inside catch-ERROR : moneydsl.cs " + e3.Message.ToString());


            }
            finally
            {
                con.Close();

            }
            return dsProducts;
        }
        public static DataSet GetProductIDs()
        {
            String sql = "";
            SqlConnection con = null;
            SqlDataAdapter adapter = null;

            DataSet dsProducts = null;

            try
            {
                sql = "select Id from PocketMoneyTable";
                con = DBHelper.GetConnection();
                con.Open();
                dsProducts = new DataSet();
                adapter = new SqlDataAdapter(sql, con);
                adapter.Fill(dsProducts);
            }
            catch (Exception e3)
            {
                Console.Out.WriteLine(" inside catch-ERROR : moneydsl.cs " + e3.Message.ToString());


            }
            finally
            {
                con.Close();

            }
            return dsProducts;
        }
        public static DataSet GetProductLike(string likeName)
        {
            String sql = "";
            SqlConnection con = null;
            SqlDataAdapter adapter = null;

            DataSet dsProducts = null;

            try
            {
                sql = "select * from PocketMoneyTable where Product_Description like '" + likeName + "%'";
                con = DBHelper.GetConnection();
                con.Open();
                dsProducts = new DataSet();
                adapter = new SqlDataAdapter(sql, con);
                adapter.Fill(dsProducts);
            }
            catch (Exception e3)
            {
                Console.Out.WriteLine(" inside catch-ERROR : money dsl.cs :GetproductLike()" + e3.Message.ToString());


            }
            finally
            {
                con.Close();

            }
            return dsProducts;
        }
        public static DataSet GetTypeLike(string likeType)
        {
            String sql = "";
            SqlConnection con = null;
            SqlDataAdapter adapter = null;

            DataSet dsProducts = null;

            try
            {
                sql = "select * from PocketMoneyTable where Type_of_transaction like '" + likeType + "%'";
                con = DBHelper.GetConnection();
                con.Open();
                dsProducts = new DataSet();
                adapter = new SqlDataAdapter(sql, con);
                adapter.Fill(dsProducts);
            }
            catch (Exception e3)
            {
                Console.Out.WriteLine(" inside catch-ERROR : money dsl.cs :GettypeLike()" + e3.Message.ToString());


            }
            finally
            {
                con.Close();

            }
            return dsProducts;
        }
        public static DataSet GetDateLike(string likeDate)
        {
            String sql = "";
            SqlConnection con = null;
            SqlDataAdapter adapter = null;

            DataSet dsProducts = null;

            try
            {
                sql = "select * from PocketMoneyTable where Date like '" + likeDate + "%'";
                con = DBHelper.GetConnection();
                con.Open();
                dsProducts = new DataSet();
                adapter = new SqlDataAdapter(sql, con);
                adapter.Fill(dsProducts);
            }
            catch (Exception e3)
            {
                Console.Out.WriteLine(" inside catch-ERROR : money dsl.cs :GetDateLike()" + e3.Message.ToString());


            }
            finally
            {
                con.Close();

            }
            return dsProducts;
        }

        public static PocketMoney GetProductByID(string serialNumber)
        {
            String sql = "";
            SqlConnection con = null;
            SqlDataAdapter adapter = null;

            DataSet dsProducts = null;
            PocketMoney pocketMoney = null;
            try
            {
                sql = "select * from PocketMoneyTable where Id='" + serialNumber + "'";
                con = DBHelper.GetConnection();
                con.Open();
                dsProducts = new DataSet();
                adapter = new SqlDataAdapter(sql, con);
                adapter.Fill(dsProducts);

                Object[] Data = null;

                if (dsProducts.Tables[0].Rows.Count > 0)
                {
                    //to retrieve all data from table for required ID

                    Data = dsProducts.Tables[0].Rows[0].ItemArray;
                    pocketMoney = new PocketMoney();
                    pocketMoney.SerialNo = Convert.ToInt32(Data[0].ToString());
                    pocketMoney.ProductDescription = Data[1].ToString();
                    pocketMoney.TypeOfTransaction = Data[2].ToString();
                   
                    pocketMoney.Amount = Convert.ToInt32(Data[3].ToString());
                    pocketMoney.Date = Data[4].ToString();


                }
            }
            catch (Exception e3)
            {
                Console.Out.WriteLine(" inside catch-ERROR : moneydsl.cs: " + e3.Message.ToString());


            }
            finally
            {
                con.Close();

            }
            return pocketMoney;
        }
        public static int Insert(PocketMoney pocketMoney)
        {
            int output = 0;
            string sql = null;
            SqlConnection con = null;
            SqlCommand cmd = null;

            try
            {
                sql = " insert into PocketMoneyTable(Id,Product_Description,Type_of_transaction,Amount,Date) VALUES (";
                sql = sql + pocketMoney.SerialNo + ",";
                sql = sql + "'" + pocketMoney.ProductDescription + "',";
                sql = sql + "'"+pocketMoney.TypeOfTransaction + "',";
                sql = sql + pocketMoney.Amount + ",";
                sql = sql + "'" + pocketMoney.Date + "')";
              


                con = DBHelper.GetConnection();
                con.Open();
                cmd = new SqlCommand(sql, con);
                output = cmd.ExecuteNonQuery();
            }
            catch (Exception e3)
            {
                Console.Out.WriteLine(" inside catch-ERROR :moneydsl.cs " + e3.Message.ToString());


            }
            finally
            {
                con.Close();
                cmd.Dispose();
            }
            return output;
        }
        public static int Delete(String serialNumber)
        {
            int output = 0;
            string sql = null;
            SqlConnection con = null;
            SqlCommand cmd = null;

            try
            {
                sql = "delete from PocketMoneyTable where Id='" + serialNumber + "'";

                ////////////
                con = DBHelper.GetConnection();
                con.Open();
                cmd = new SqlCommand(sql, con);
                output = cmd.ExecuteNonQuery();

            }
            catch (Exception e3)
            {
                Console.Out.WriteLine(" inside catch-ERROR : moneydsl.cs " + e3.Message.ToString());


            }
            finally
            {
                con.Close();
                cmd.Dispose();
            }
            return output;
        }
        public static int Update(PocketMoney pocketMoney)
        {
            int output = 0;
            string sql = null;
            SqlConnection con = null;
            SqlCommand cmd = null;

            try
            {
                sql = " update PocketMoneyTable set ";

                sql = sql + "Product_Description='" + pocketMoney.ProductDescription + "',";              
                sql = sql + "Type_of_transaction='" + pocketMoney.TypeOfTransaction + "',";
                sql = sql + "Amount=" + pocketMoney.Amount + ",";
                sql = sql + "Date='" + pocketMoney.Date + "'";
               

                sql = sql + "where Id='" + pocketMoney.SerialNo + "'";


                ////////////
                con = DBHelper.GetConnection();
                con.Open();
                cmd = new SqlCommand(sql, con);
                output = cmd.ExecuteNonQuery();

            }
            catch (Exception e3)
            {
                Console.Out.WriteLine(" inside catch-ERROR : money dsl.cs " + e3.Message.ToString());


            }
            finally
            {
                con.Close();
                cmd.Dispose();
            }
            return output;
        }


    }
}
