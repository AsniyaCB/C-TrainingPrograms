﻿using System;

namespace PocketMoneyDL
{
    public class Class1
    {
    }
}
