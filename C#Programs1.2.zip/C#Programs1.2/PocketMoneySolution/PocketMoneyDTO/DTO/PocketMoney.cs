﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PocketMoneyDTO.DTO
{
    public class PocketMoney
    {
        private int serialNo;
        public int SerialNo
        {
            get { return serialNo; }
            set { serialNo = value; }
        }

        private string productDescription;
        public String ProductDescription
        {
            get { return productDescription; }
            set { productDescription = value; }
        }

        private string typeOfTransaction;
        public String TypeOfTransaction
        {
            get { return typeOfTransaction; }
            set { typeOfTransaction = value; }
        }
        private int amount;
        public int Amount
        {
            get { return amount; }
            set { amount = value; }
        }

        private string date;
        public String Date
        {
            get { return date; }
            set { date = value; }
        }

    }
}
