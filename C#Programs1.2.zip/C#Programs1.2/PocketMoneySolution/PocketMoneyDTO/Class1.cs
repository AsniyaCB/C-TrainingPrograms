﻿using System;

namespace PocketMoneyDTO
{
    public class Class1
    {
    }
}
