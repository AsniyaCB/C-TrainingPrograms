﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PocketMoneyDTO.DTO;
using PocketMoneyBL.BL;

namespace PocketMoneySolution
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();        
            PocketMoney pocketMoney = null;
            MoneyBLL.Insert(pocketMoney);
        }

        private void lblProduct_Click(object sender, EventArgs e)
        {

        }

        private void lblTitle_Click(object sender, EventArgs e)
        {

        }
        private void LoadProducts()
        {
            DataSet dsProducts = null;
            try
            {
                dsProducts = MoneyBLL.GetProducts();
                if (dsProducts != null)
                {
                    dgvProducts.DataSource = dsProducts.Tables[0];
                }
                else
                {
                    lblMessage.Text = "No products available";
                }
            }
            catch (Exception ex)
            {
                lblMessage.Text = ex.Message.ToString();

            }
        }
        private void LoadProductIDs()
        {
            DataSet dsProductID = null;
            try
            {
                dsProductID = MoneyBLL.GetProductIDs();
                if (dsProductID != null)
                {
                    cmbID.DataSource = dsProductID.Tables[0];


                    cmbID.ValueMember = "Id";
                    cmbID.DisplayMember = "Id";

                }
                else
                {
                    lblMessage.Text = "No products avialable";
                }
            }
            catch (Exception ex)
            {
                lblMessage.Text = ex.Message.ToString();

            }
        }
        private void btnSave_Click(object sender, EventArgs e)
        {
            int output = 0;
            PocketMoney pocketMoney= null;
            try
            {
                if (txtSerialNo.Text == string.Empty || cmbProductDescription.Text == string.Empty || txtAmount.Text == string.Empty)
                {
                    lblMessage.Text = "Enter all the details";
                    foreach (Control control in this.Controls)
                    {
                        if (!Validate())
                        {
                            DialogResult = DialogResult.None;
                            return;
                        }
                    }
                }
                else
                {

                    pocketMoney = new PocketMoney();
                    pocketMoney.SerialNo = Convert.ToInt32(txtSerialNo.Text);
                    
                    pocketMoney.Amount = Convert.ToInt32(txtAmount.Text);

                   
                    pocketMoney.Date = dtpDate.Value.ToString("dd-MM-yyy");
                    dtpDate.MaxDate = DateTime.Today;
                    dtpDate.Format = DateTimePickerFormat.Custom;


                    if (cmbProductDescription.SelectedIndex == -1)
                    {
                        lblMessage.Text = "Please select a Product Description !!!";
                        return;
                    }
                    else
                    {
                        pocketMoney.ProductDescription = cmbProductDescription.Text;
                    }
                    if (!rdbCredit.Checked && !rdbDebit.Checked)
                    {
                        lblMessage.Text = "Please Select a Type of Transaction !!!";
                        return;
                    }

                    else if (rdbDebit.Checked)
                    {
                        pocketMoney.TypeOfTransaction = "Debit";
                    }
                    else
                    {
                        pocketMoney.TypeOfTransaction = "Credit";
                    }


                    output = MoneyBLL.Insert(pocketMoney);
                    if (output > 0)

                    {
                        lblMessage.Text = "successfully added";
                        LoadProducts();
                        LoadProductIDs();
                    }
                    else
                    {
                        lblMessage.Text = "failed to insert";
                    }
                }
            }
            catch (Exception ex)
            {
                lblMessage.Text = ex.Message.ToString();
            }

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'databaseDataSet.PocketMoneyTable' table. You can move, or remove it, as needed.
            this.pocketMoneyTableTableAdapter.Fill(this.databaseDataSet.PocketMoneyTable);
            LoadProducts();
            LoadProductIDs();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            int output = 0;
            try
            {
                if (MessageBox.Show("Do you want to delete ?", "Confirm ", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    output = MoneyBLL.Delete(cmbID.Text);
                    if (output > 0)
                    {

                        LoadProducts();
                        LoadProductIDs();
                        lblMessage.Text = "products transaction details deleted successfully";
                    }
                    else
                    {
                        lblMessage.Text = "Please try again later";
                    }
                }
                else
                {
                    lblMessage.Text = "Item not deleted";
                }
            }
            catch (Exception ex)
            {
                lblMessage.Text = ex.Message.ToString();
            }
        }


        private void cmbID_SelectedIndexChanged(object sender, EventArgs e)
        {
            PocketMoney pocketMoney = null;
            try
            {
                pocketMoney = MoneyBLL.GetProductByID(cmbID.Text);

                if (pocketMoney != null)
                {
                    txtSerialNo.Text = pocketMoney.SerialNo.ToString();
                    cmbProductDescription.Text = pocketMoney.ProductDescription;
                    txtAmount.Text = pocketMoney.Amount.ToString();
                    dtpDate.Text = pocketMoney.Date;
                    if (pocketMoney.TypeOfTransaction=="Debit")
                    {
                        rdbDebit.Checked = true;
                    }
                    else
                    {
                        rdbCredit.Checked = true;
                    }
                }
            }

            catch (Exception ex)
            {
                lblMessage.Text = ex.Message.ToString();

            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            PocketMoney pocketMoney = null;
            int output = 0;
            try
            {
                pocketMoney = new PocketMoney();
                pocketMoney.SerialNo = Convert.ToInt32(txtSerialNo.Text);
                pocketMoney.ProductDescription = cmbProductDescription.Text;

                pocketMoney.Date = dtpDate.Value.ToString("dd-MM-yyyy");
                if (rdbCredit.Checked)
                {
                    pocketMoney.TypeOfTransaction = "Credit";
                }
                else
                {
                    pocketMoney.TypeOfTransaction = "Debit";
                }
             
                pocketMoney.Amount = Convert.ToInt32(txtAmount.Text);
               



                output = MoneyBLL.Update(pocketMoney);

                if (output > 0)

                {
                    LoadProductIDs();
                    LoadProducts();
                    lblMessage.Text = "product transaction details updated successfully";

                }
                else
                {
                    lblMessage.Text = "Please try again later";
                }


            }
            catch (Exception e4)
            {
                lblMessage.Text = e4.Message.ToString();
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {

            if (btnClear.Text == "BACK")
            {
                btnSave.Text = "NEW";
                btnDelete.Enabled = true;
                btnUpdate.Enabled = true;

                btnClear.Text = "CLEAR";
            }

            else
            {
                ClearControl();
            }
        }
        private void ClearControl()
        {
            txtSerialNo.Text = "";
            cmbProductDescription.Text = "";
            
            txtAmount.Text = "";
            dtpDate.Text = "";
            lblMessage.Text = "";
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            DataSet dsProducts = null;
            try
            {
                dsProducts = MoneyBLL.GetProductLike(txtSearch.Text);
                if (dsProducts != null)
                {
                    dgvProducts.DataSource = dsProducts.Tables[0];

                }
                else
                {
                    lblMessage.Text = "No product transaction available";
                }
            }
            catch (Exception ex)
            {
                lblMessage.Text = ex.Message.ToString();

            }
        }

        private void txtTypeSearch_TextChanged(object sender, EventArgs e)
        {
            DataSet dsProducts = null;
            try
            {
                dsProducts = MoneyBLL.GetTypeLike(txtTypeSearch.Text);
                if (dsProducts != null)
                {
                    dgvProducts.DataSource = dsProducts.Tables[0];

                }
                else
                {
                    lblMessage.Text = "No transaction available";
                }
            }
            catch (Exception ex)
            {
                lblMessage.Text = ex.Message.ToString();

            }
        }

        private void txtDateSearch_TextChanged(object sender, EventArgs e)
        {
            DataSet dsProducts = null;
            try
            {
                dsProducts = MoneyBLL.GetDateLike(txtDateSearch.Text);
                if (dsProducts != null)
                {
                    dgvProducts.DataSource = dsProducts.Tables[0];

                }
                else
                {
                    lblMessage.Text = "No transaction available";
                }
            }
            catch (Exception ex)
            {
                lblMessage.Text = ex.Message.ToString();

            }
        }

        private void txtSerialNo_Validating(object sender, CancelEventArgs e)
        {

            if (txtSerialNo.Text == string.Empty)
            {
                eP.SetError(txtSerialNo, "ID is required !");
            }
            else
            {
                eP.SetError(txtSerialNo, string.Empty);
            }
        }

        private void cmbProductDescription_Validating(object sender, CancelEventArgs e)
        {

            if (cmbProductDescription.Text == string.Empty)
            {
                eP.SetError(cmbProductDescription, "Description is required !");
            }
            else
            {
                eP.SetError(cmbProductDescription, string.Empty);
            }
        }

        private void rdbCredit_Validating(object sender, CancelEventArgs e)
        {

        }

        private void txtAmount_Validating(object sender, CancelEventArgs e)
        {
            if (txtAmount.Text == string.Empty)
            {
                eP.SetError(txtAmount, "Amount is required !");
            }
            else
            {
                eP.SetError(txtAmount, string.Empty);
            }
        }
    }
}
