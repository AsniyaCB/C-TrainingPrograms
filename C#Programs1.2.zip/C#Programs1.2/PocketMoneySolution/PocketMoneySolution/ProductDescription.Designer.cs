﻿namespace PocketMoneySolution
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblSerialNo = new System.Windows.Forms.Label();
            this.lblProduct = new System.Windows.Forms.Label();
            this.lblTypeOfTransaction = new System.Windows.Forms.Label();
            this.lblDate = new System.Windows.Forms.Label();
            this.lblAmount = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.cmbID = new System.Windows.Forms.ComboBox();
            this.lblMessage = new System.Windows.Forms.Label();
            this.dtpDate = new System.Windows.Forms.DateTimePicker();
            this.rdbDebit = new System.Windows.Forms.RadioButton();
            this.rdbCredit = new System.Windows.Forms.RadioButton();
            this.cmbProductDescription = new System.Windows.Forms.ComboBox();
            this.txtAmount = new System.Windows.Forms.TextBox();
            this.txtSerialNo = new System.Windows.Forms.TextBox();
            this.dgvProducts = new System.Windows.Forms.DataGridView();
            this.idDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.productDescriptionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.typeoftransactionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.amountDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pocketMoneyTableBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.databaseDataSet = new PocketMoneySolution.DatabaseDataSet();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.pocketMoneyTableTableAdapter = new PocketMoneySolution.DatabaseDataSetTableAdapters.PocketMoneyTableTableAdapter();
            this.btnProductSearch = new System.Windows.Forms.Label();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.btnTypeSearch = new System.Windows.Forms.Label();
            this.txtTypeSearch = new System.Windows.Forms.TextBox();
            this.lblDateSearch = new System.Windows.Forms.Label();
            this.txtDateSearch = new System.Windows.Forms.TextBox();
            this.eP = new System.Windows.Forms.ErrorProvider(this.components);
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProducts)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pocketMoneyTableBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.databaseDataSet)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.eP)).BeginInit();
            this.SuspendLayout();
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("NSimSun", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Location = new System.Drawing.Point(271, 18);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(476, 48);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "TRANSACTION DETAILS";
            this.lblTitle.Click += new System.EventHandler(this.lblTitle_Click);
            // 
            // lblSerialNo
            // 
            this.lblSerialNo.AutoSize = true;
            this.lblSerialNo.Font = new System.Drawing.Font("Microsoft Uighur", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSerialNo.Location = new System.Drawing.Point(61, 59);
            this.lblSerialNo.Name = "lblSerialNo";
            this.lblSerialNo.Size = new System.Drawing.Size(187, 26);
            this.lblSerialNo.TabIndex = 1;
            this.lblSerialNo.Text = "SERIAL NO                                   :";
            // 
            // lblProduct
            // 
            this.lblProduct.AutoSize = true;
            this.lblProduct.Font = new System.Drawing.Font("Microsoft Uighur", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProduct.Location = new System.Drawing.Point(61, 103);
            this.lblProduct.Name = "lblProduct";
            this.lblProduct.Size = new System.Drawing.Size(188, 26);
            this.lblProduct.TabIndex = 2;
            this.lblProduct.Text = "PRODUCT DESCRIPTION       :";
            this.lblProduct.Click += new System.EventHandler(this.lblProduct_Click);
            // 
            // lblTypeOfTransaction
            // 
            this.lblTypeOfTransaction.AutoSize = true;
            this.lblTypeOfTransaction.Font = new System.Drawing.Font("Microsoft Uighur", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTypeOfTransaction.Location = new System.Drawing.Point(61, 146);
            this.lblTypeOfTransaction.Name = "lblTypeOfTransaction";
            this.lblTypeOfTransaction.Size = new System.Drawing.Size(186, 26);
            this.lblTypeOfTransaction.TabIndex = 3;
            this.lblTypeOfTransaction.Text = "TYPE OF TRANSACTION        :";
            // 
            // lblDate
            // 
            this.lblDate.AutoSize = true;
            this.lblDate.Font = new System.Drawing.Font("Microsoft Uighur", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDate.Location = new System.Drawing.Point(61, 188);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(185, 26);
            this.lblDate.TabIndex = 4;
            this.lblDate.Text = "DATE                                             :";
            // 
            // lblAmount
            // 
            this.lblAmount.AutoSize = true;
            this.lblAmount.Font = new System.Drawing.Font("Microsoft Uighur", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAmount.Location = new System.Drawing.Point(61, 225);
            this.lblAmount.Name = "lblAmount";
            this.lblAmount.Size = new System.Drawing.Size(185, 26);
            this.lblAmount.TabIndex = 5;
            this.lblAmount.Text = "AMOUNT                                     :";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.cmbID);
            this.panel1.Controls.Add(this.lblMessage);
            this.panel1.Controls.Add(this.dtpDate);
            this.panel1.Controls.Add(this.rdbDebit);
            this.panel1.Controls.Add(this.rdbCredit);
            this.panel1.Controls.Add(this.cmbProductDescription);
            this.panel1.Controls.Add(this.txtAmount);
            this.panel1.Controls.Add(this.txtSerialNo);
            this.panel1.Controls.Add(this.lblSerialNo);
            this.panel1.Controls.Add(this.lblAmount);
            this.panel1.Controls.Add(this.lblProduct);
            this.panel1.Controls.Add(this.lblDate);
            this.panel1.Controls.Add(this.lblTypeOfTransaction);
            this.panel1.Location = new System.Drawing.Point(22, 104);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(725, 269);
            this.panel1.TabIndex = 6;
            // 
            // cmbID
            // 
            this.cmbID.FormattingEnabled = true;
            this.cmbID.Location = new System.Drawing.Point(365, 17);
            this.cmbID.Name = "cmbID";
            this.cmbID.Size = new System.Drawing.Size(109, 21);
            this.cmbID.TabIndex = 13;
            this.cmbID.Text = "(Select serial No)";
            this.cmbID.SelectedIndexChanged += new System.EventHandler(this.cmbID_SelectedIndexChanged);
            // 
            // lblMessage
            // 
            this.lblMessage.AutoSize = true;
            this.lblMessage.ForeColor = System.Drawing.Color.Red;
            this.lblMessage.Location = new System.Drawing.Point(63, 20);
            this.lblMessage.Name = "lblMessage";
            this.lblMessage.Size = new System.Drawing.Size(0, 13);
            this.lblMessage.TabIndex = 12;
            // 
            // dtpDate
            // 
            this.dtpDate.Location = new System.Drawing.Point(365, 187);
            this.dtpDate.Name = "dtpDate";
            this.dtpDate.Size = new System.Drawing.Size(310, 20);
            this.dtpDate.TabIndex = 11;
            // 
            // rdbDebit
            // 
            this.rdbDebit.AutoSize = true;
            this.rdbDebit.Location = new System.Drawing.Point(471, 151);
            this.rdbDebit.Name = "rdbDebit";
            this.rdbDebit.Size = new System.Drawing.Size(57, 17);
            this.rdbDebit.TabIndex = 10;
            this.rdbDebit.TabStop = true;
            this.rdbDebit.Text = "DEBIT";
            this.rdbDebit.UseVisualStyleBackColor = true;
            // 
            // rdbCredit
            // 
            this.rdbCredit.AutoSize = true;
            this.rdbCredit.Location = new System.Drawing.Point(365, 151);
            this.rdbCredit.Name = "rdbCredit";
            this.rdbCredit.Size = new System.Drawing.Size(65, 17);
            this.rdbCredit.TabIndex = 9;
            this.rdbCredit.TabStop = true;
            this.rdbCredit.Text = "CREDIT";
            this.rdbCredit.UseVisualStyleBackColor = true;
            this.rdbCredit.Validating += new System.ComponentModel.CancelEventHandler(this.rdbCredit_Validating);
            // 
            // cmbProductDescription
            // 
            this.cmbProductDescription.FormattingEnabled = true;
            this.cmbProductDescription.Items.AddRange(new object[] {
            "Stationaries",
            "Food Items",
            "Petrol",
            "LPG",
            "Movie Tickets",
            "Clothes",
            "Offers",
            "Discounts",
            "GooglePay"});
            this.cmbProductDescription.Location = new System.Drawing.Point(365, 108);
            this.cmbProductDescription.Name = "cmbProductDescription";
            this.cmbProductDescription.Size = new System.Drawing.Size(310, 21);
            this.cmbProductDescription.TabIndex = 8;
            this.cmbProductDescription.Text = "(Select Product Description)";
            this.cmbProductDescription.Validating += new System.ComponentModel.CancelEventHandler(this.cmbProductDescription_Validating);
            // 
            // txtAmount
            // 
            this.txtAmount.Location = new System.Drawing.Point(365, 232);
            this.txtAmount.Name = "txtAmount";
            this.txtAmount.Size = new System.Drawing.Size(310, 20);
            this.txtAmount.TabIndex = 7;
            this.txtAmount.Validating += new System.ComponentModel.CancelEventHandler(this.txtAmount_Validating);
            // 
            // txtSerialNo
            // 
            this.txtSerialNo.Location = new System.Drawing.Point(365, 61);
            this.txtSerialNo.Name = "txtSerialNo";
            this.txtSerialNo.Size = new System.Drawing.Size(310, 20);
            this.txtSerialNo.TabIndex = 6;
            this.txtSerialNo.Validating += new System.ComponentModel.CancelEventHandler(this.txtSerialNo_Validating);
            // 
            // dgvProducts
            // 
            this.dgvProducts.AutoGenerateColumns = false;
            this.dgvProducts.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvProducts.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn,
            this.productDescriptionDataGridViewTextBoxColumn,
            this.typeoftransactionDataGridViewTextBoxColumn,
            this.amountDataGridViewTextBoxColumn,
            this.dateDataGridViewTextBoxColumn});
            this.dgvProducts.DataSource = this.pocketMoneyTableBindingSource;
            this.dgvProducts.Location = new System.Drawing.Point(204, 460);
            this.dgvProducts.Name = "dgvProducts";
            this.dgvProducts.Size = new System.Drawing.Size(543, 150);
            this.dgvProducts.TabIndex = 7;
            // 
            // idDataGridViewTextBoxColumn
            // 
            this.idDataGridViewTextBoxColumn.DataPropertyName = "Id";
            this.idDataGridViewTextBoxColumn.HeaderText = "Id";
            this.idDataGridViewTextBoxColumn.Name = "idDataGridViewTextBoxColumn";
            // 
            // productDescriptionDataGridViewTextBoxColumn
            // 
            this.productDescriptionDataGridViewTextBoxColumn.DataPropertyName = "Product_Description";
            this.productDescriptionDataGridViewTextBoxColumn.HeaderText = "Product_Description";
            this.productDescriptionDataGridViewTextBoxColumn.Name = "productDescriptionDataGridViewTextBoxColumn";
            // 
            // typeoftransactionDataGridViewTextBoxColumn
            // 
            this.typeoftransactionDataGridViewTextBoxColumn.DataPropertyName = "Type_of_transaction";
            this.typeoftransactionDataGridViewTextBoxColumn.HeaderText = "Type_of_transaction";
            this.typeoftransactionDataGridViewTextBoxColumn.Name = "typeoftransactionDataGridViewTextBoxColumn";
            // 
            // amountDataGridViewTextBoxColumn
            // 
            this.amountDataGridViewTextBoxColumn.DataPropertyName = "Amount";
            this.amountDataGridViewTextBoxColumn.HeaderText = "Amount";
            this.amountDataGridViewTextBoxColumn.Name = "amountDataGridViewTextBoxColumn";
            // 
            // dateDataGridViewTextBoxColumn
            // 
            this.dateDataGridViewTextBoxColumn.DataPropertyName = "Date";
            this.dateDataGridViewTextBoxColumn.HeaderText = "Date";
            this.dateDataGridViewTextBoxColumn.Name = "dateDataGridViewTextBoxColumn";
            // 
            // pocketMoneyTableBindingSource
            // 
            this.pocketMoneyTableBindingSource.DataMember = "PocketMoneyTable";
            this.pocketMoneyTableBindingSource.DataSource = this.databaseDataSet;
            // 
            // databaseDataSet
            // 
            this.databaseDataSet.DataSetName = "DatabaseDataSet";
            this.databaseDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.btnClear);
            this.panel2.Controls.Add(this.btnUpdate);
            this.panel2.Controls.Add(this.btnDelete);
            this.panel2.Controls.Add(this.btnSave);
            this.panel2.Location = new System.Drawing.Point(22, 379);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(725, 75);
            this.panel2.TabIndex = 8;
            // 
            // btnClear
            // 
            this.btnClear.BackColor = System.Drawing.Color.FloralWhite;
            this.btnClear.Font = new System.Drawing.Font("Microsoft Uighur", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear.Location = new System.Drawing.Point(580, 11);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(85, 53);
            this.btnClear.TabIndex = 15;
            this.btnClear.Text = "CLEAR";
            this.btnClear.UseVisualStyleBackColor = false;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnUpdate
            // 
            this.btnUpdate.BackColor = System.Drawing.Color.FloralWhite;
            this.btnUpdate.Font = new System.Drawing.Font("Microsoft Uighur", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdate.Location = new System.Drawing.Point(415, 11);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(85, 53);
            this.btnUpdate.TabIndex = 14;
            this.btnUpdate.Text = "UPDATE";
            this.btnUpdate.UseVisualStyleBackColor = false;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.BackColor = System.Drawing.Color.FloralWhite;
            this.btnDelete.Font = new System.Drawing.Font("Microsoft Uighur", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.Location = new System.Drawing.Point(238, 11);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(85, 53);
            this.btnDelete.TabIndex = 13;
            this.btnDelete.Text = "DELETE";
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.FloralWhite;
            this.btnSave.Font = new System.Drawing.Font("Microsoft Uighur", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Location = new System.Drawing.Point(77, 11);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(85, 53);
            this.btnSave.TabIndex = 12;
            this.btnSave.Text = "SAVE";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // pocketMoneyTableTableAdapter
            // 
            this.pocketMoneyTableTableAdapter.ClearBeforeFill = true;
            // 
            // btnProductSearch
            // 
            this.btnProductSearch.AutoSize = true;
            this.btnProductSearch.Font = new System.Drawing.Font("Microsoft Uighur", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProductSearch.Location = new System.Drawing.Point(801, 88);
            this.btnProductSearch.Name = "btnProductSearch";
            this.btnProductSearch.Size = new System.Drawing.Size(156, 26);
            this.btnProductSearch.TabIndex = 9;
            this.btnProductSearch.Text = "SEARCH BY CATEGORY";
            // 
            // txtSearch
            // 
            this.txtSearch.Location = new System.Drawing.Point(805, 129);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(152, 20);
            this.txtSearch.TabIndex = 10;
            this.txtSearch.TextChanged += new System.EventHandler(this.txtSearch_TextChanged);
            // 
            // btnTypeSearch
            // 
            this.btnTypeSearch.AutoSize = true;
            this.btnTypeSearch.Font = new System.Drawing.Font("Microsoft Uighur", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTypeSearch.Location = new System.Drawing.Point(764, 185);
            this.btnTypeSearch.Name = "btnTypeSearch";
            this.btnTypeSearch.Size = new System.Drawing.Size(233, 26);
            this.btnTypeSearch.TabIndex = 11;
            this.btnTypeSearch.Text = "SEARCH BY TYPE OF TRANSACTION";
            // 
            // txtTypeSearch
            // 
            this.txtTypeSearch.Location = new System.Drawing.Point(805, 231);
            this.txtTypeSearch.Name = "txtTypeSearch";
            this.txtTypeSearch.Size = new System.Drawing.Size(152, 20);
            this.txtTypeSearch.TabIndex = 12;
            this.txtTypeSearch.TextChanged += new System.EventHandler(this.txtTypeSearch_TextChanged);
            // 
            // lblDateSearch
            // 
            this.lblDateSearch.AutoSize = true;
            this.lblDateSearch.Font = new System.Drawing.Font("Microsoft Uighur", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDateSearch.Location = new System.Drawing.Point(764, 292);
            this.lblDateSearch.Name = "lblDateSearch";
            this.lblDateSearch.Size = new System.Drawing.Size(237, 26);
            this.lblDateSearch.TabIndex = 13;
            this.lblDateSearch.Text = "SEARCH BY DATE OF TRANSACTION";
            // 
            // txtDateSearch
            // 
            this.txtDateSearch.Location = new System.Drawing.Point(805, 341);
            this.txtDateSearch.Name = "txtDateSearch";
            this.txtDateSearch.Size = new System.Drawing.Size(152, 20);
            this.txtDateSearch.TabIndex = 14;
            this.txtDateSearch.TextChanged += new System.EventHandler(this.txtDateSearch_TextChanged);
            // 
            // eP
            // 
            this.eP.ContainerControl = this;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Cornsilk;
            this.ClientSize = new System.Drawing.Size(1012, 622);
            this.Controls.Add(this.txtDateSearch);
            this.Controls.Add(this.lblDateSearch);
            this.Controls.Add(this.txtTypeSearch);
            this.Controls.Add(this.btnTypeSearch);
            this.Controls.Add(this.txtSearch);
            this.Controls.Add(this.btnProductSearch);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.dgvProducts);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.lblTitle);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProducts)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pocketMoneyTableBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.databaseDataSet)).EndInit();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.eP)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblSerialNo;
        private System.Windows.Forms.Label lblProduct;
        private System.Windows.Forms.Label lblTypeOfTransaction;
        private System.Windows.Forms.Label lblDate;
        private System.Windows.Forms.Label lblAmount;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DateTimePicker dtpDate;
        private System.Windows.Forms.RadioButton rdbDebit;
        private System.Windows.Forms.RadioButton rdbCredit;
        private System.Windows.Forms.ComboBox cmbProductDescription;
        private System.Windows.Forms.TextBox txtAmount;
        private System.Windows.Forms.TextBox txtSerialNo;
        private System.Windows.Forms.DataGridView dgvProducts;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnSave;
        private DatabaseDataSet databaseDataSet;
        private System.Windows.Forms.BindingSource pocketMoneyTableBindingSource;
        private DatabaseDataSetTableAdapters.PocketMoneyTableTableAdapter pocketMoneyTableTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn productDescriptionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn typeoftransactionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn amountDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dateDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label lblMessage;
        private System.Windows.Forms.ComboBox cmbID;
        private System.Windows.Forms.Label btnProductSearch;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.Label btnTypeSearch;
        private System.Windows.Forms.TextBox txtTypeSearch;
        private System.Windows.Forms.Label lblDateSearch;
        private System.Windows.Forms.TextBox txtDateSearch;
        private System.Windows.Forms.ErrorProvider eP;
    }
}

