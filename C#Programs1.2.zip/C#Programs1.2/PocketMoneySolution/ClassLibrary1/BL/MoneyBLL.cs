﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using PocketMoneyDSL.MoneyDL;
using PocketMoneyDTO.DTO;

namespace PocketMoneyBL.BL
{
    public class MoneyBLL
    {
        public static DataSet GetProducts()
        {
            //String sql = "";

            DataSet dsProducts = null;

            try
            {

                dsProducts = MoneyDSL.GetProducts();


            }
            catch (Exception e3)
            {
                Console.Out.WriteLine(" inside catch-ERROR : moneybll.cs :getproducts()" + e3.Message.ToString());


            }

            return dsProducts;
        }
        public static DataSet GetProductIDs()
        {
            //String sql = "";

            DataSet dsProducts = null;

            try
            {

                dsProducts = MoneyDSL.GetProductIDs();


            }
            catch (Exception e3)
            {
                Console.Out.WriteLine(" inside catch-ERROR : moneybl.cs " + e3.Message.ToString());


            }

            return dsProducts;
        }
        public static PocketMoney GetProductByID(string serialNum)
        {

            PocketMoney pocketMoney = null;
            try
            {
                pocketMoney = MoneyDSL.GetProductByID(serialNum);
            }
            catch (Exception e3)
            {
                Console.Out.WriteLine(" ERROR : moneybl.cs:getproductbyid() " + e3.Message.ToString());


            }

            return pocketMoney;
        }

        public static DataSet GetProductLike(string likeName)
        {
            DataSet dsProducts = null;

            try
            {
                dsProducts = MoneyDSL.GetProductLike(likeName);
            }
            catch (Exception e3)
            {
                Console.Out.WriteLine(" inside catch-ERROR : money bll.cs :GetProductLike()" + e3.Message.ToString());


            }

            return dsProducts;
        }
        public static DataSet GetTypeLike(string likeType)
        {
            DataSet dsProducts = null;

            try
            {
                dsProducts = MoneyDSL.GetTypeLike(likeType);
            }
            catch (Exception e3)
            {
                Console.Out.WriteLine(" inside catch-ERROR : money bll.cs :GetTypeLike()" + e3.Message.ToString());


            }

            return dsProducts;
        }
        public static DataSet GetDateLike(string likeDate)
        {
            DataSet dsProducts = null;

            try
            {
                dsProducts = MoneyDSL.GetDateLike(likeDate);
            }
            catch (Exception e3)
            {
                Console.Out.WriteLine(" inside catch-ERROR : money bll.cs :GetDateLike()" + e3.Message.ToString());


            }

            return dsProducts;
        }
        public static int Insert(PocketMoney pocketMoney)
        {
            int output = 0;

            try
            {
                output = MoneyDSL.Insert(pocketMoney);
            }

            catch (Exception e3)
            {
                Console.Out.WriteLine(" inside catch-ERROR : moneybll.cs " + e3.Message.ToString());
            }


            return output;
        }

        public static int Delete(string serialNumber)
        {
            int output = 0;

            try
            {
                output = MoneyDSL.Delete(serialNumber);

            }
            catch (Exception e3)
            {
                Console.Out.WriteLine(" ERROR :moneydsl.cs:Delete: " + e3.Message.ToString());


            }

            return output;
        }
        public static int Update(PocketMoney pocketMoney)
        {
            int output = 0;


            try
            {


                output = MoneyDSL.Update(pocketMoney);

            }
            catch (Exception e3)
            {
                Console.Out.WriteLine(" inside catch-ERROR : moneybl.cs:Update " + e3.Message.ToString());


            }

            return output;

        }
    }
}
